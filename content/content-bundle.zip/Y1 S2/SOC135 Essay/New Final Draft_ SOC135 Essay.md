You may have heard that automation and more broadly technological advancements are going to cause job loss. While that is true the factor that is being overlooked in that statement is that the advancements that will cause the job loss will also create jobs. As Paul Allen said, In my essay, I will outline how automation and AI will impact the future of work.
the majority of my sources say that the situation isn't as dire as the alarmist views would have you think, about 1/3 of those sources say that they predict that in the long run there will be more jobs that are better. Some of my sources refer to AI but none of them make direct predictions. According to Kevin Scott, LinkedIn data says that demand for AI skills increased by 190 percent between 2015 and 2017.

In my research, I couldn't find any numbers that refer to the direct impacts of AI. Myself, I didn't think that AI would have as large an impact as automaton would have on jobs. In his TED talk, Anthony Goldbloom cites challenges that his company Kaggle put to their community. One algorithm graded high school papers and another one where algorithm looked at X-rays to diagnose an eye disease called diabetic retinopathy. Both contests had an entry that matched the result from either the doctor or teacher. He also quotes an Oxford study that says almost 1 in 2 jobs have a high risk of being replaced. Also in a TED talk, Kevin Kelly (Founder of The Whole Internet Review and founding executive editor of Wired magazine) said: 
    - "The best medical diagnostician is not a doctor, it's not an AI, it's the team. We're going to be working with these AIs, and I think you'll be paid in the future by how well you work with these bots".
Automation specifically would be the thing that impacts the most people and their jobs. One reason that automation most likely wouldn't completely displace all jobs even in environments that only a small of jobs would be 100% automatable, According to Booking, jobs "with greater than 90 percent automation potential over the next two to three decades represented only 4 percent of U.S. employment in 2016. Job tasks projected to be 100 percent automatable represent only half of one percent of the workforce (740,000 jobs)". All of my academic sources (Bookings, McKinsey and, Harvard Business Review) conclude something to the tune of "The study paints a picture of automation today that does not support the most alarmist views" (HBR). See the conclusions of each paper (in the order of McKinsey, HBR and, Bookings).
    - 	Our research suggests that, in a midpoint scenario, around 3 percent of the global workforce will need to change occupational categories by 2030, though scenarios range from about 0 to 14 percent. Some of these shifts will happen within companies and sectors, but many will occur across sectors and even geographies.
    - 	The study paints a picture of automation today that does not support the most alarmist views. The burden that automation places on workers is less than the burden created by mass layoffs and plant closings that arise from things like declining demand or bankruptcies. Nevertheless, the burden placed on affected workers is substantial, and existing safety net programs are not providing these workers with much economic security. And, of course, the impact of automation might worsen in the future.  Further research will show what happens to net employment after automation, and to the workers hired after the automation event.
    - While this report concludes that the future may not be as dystopian as the most dire voices claim, plenty of people and places will be affected by automation, and much will need to be done to mitigate the coming disruptions. The authors offer five recommendations for federal, state, and local policymakers: 1) embrace growth and technology; 2) promote a constant learning mindset; 3) facilitate smoother adjustment; 4) reduce hardships for workers who are struggling, and 5) mitigate harsh local impacts.
	
In an opinion piece in Wired, Kevin Scott talks about why in his view automation and AI are creating jobs in the US. He also gives an example of how other countries have taken advantage of automation and AI to create jobs and benefit their economies. Here's an excerpt from the article making an example of how Germany did:
    - Look no further than Germany’s so-called Mittelstand. These are small- and medium-sized enterprises generating less than 50 million euros in revenue annually. Collectively, it accounts for 99.6 percent of German companies, 60 percent of jobs, and over half of Germany’s gross domestic product. These companies are ingenious at finding narrow but valuable markets to serve, then using highly skilled labor and advanced automation to efficiently produce high-quality products. My friend Hugh E’s employer would be in the Mittelstand, along with 3.3 million others. The US should study and improve upon Germany’s model.
	
Even though there will most likely be net job creation due to these advancements that don't specifically mean that people who lose their jobs still may not get new jobs due to education in emerging fields. Overall this issue needs to be addressed, there are a few ways to implement current and future practices to address them. Providing re-education programs for displaced workers, implementing a Universal Basic Income would decrease the burden on displaced workers and, adjusting how the education system educates kids would allow students to focus on STEM education. 
Finding a way to efficiently reeducate workers who were laid-off due to these advancements would be an important first step. that's because those workers would eventually need to get a new job likely in an industry that they don't have experience in.
Implementing a UBI would help because it would give people who are out of work access to enough money the cover living expenses. Research shows that didn't directly lead to job creation but people were happier. Here's a table that shows a bunch of examples of UBI that have been implemented around the world:
 
 **Summary of the Negative Income Tax Experiments in the U.S. & Canada**
 
**Name** | **Location(s)** | **Data collection** | **Sample size: Initial (final)** | **Sample Characteristics** | **Guarantee level** | **marginal tax rate**
------------|-----------|------------|------------|------------|------------|------------
The New Jersey Graduated Work Incentive Experiment (NJ) | New Jersey & Pennsylvania | 1968-19721, | 216 (983)| Black, white, and Latino, 2-parent families in urban areas with a male head aged 18-58 and income below 150% of the poverty line. | 0.5<br>0.75<br>1.0<br>1.25 | 0.3<br>0.5<br>0.7
The Rural Income-Maintenance Experiment (RIME) | Iowa & North | 1970-1972 | 809 (729) | Both 2-parent families and female-headed households in rural areas with income below 150% of poverty line. | 0.5<br>0.75<br>1.00 | 0.3<br>0.5<br>0.7
The Seattle/Denver Income-Maintenance Experiments (SIME/DIME) | Seattle & Denver | 1970-1976 (some to 1980) | 4,800 | Black, white, and Latino families with at least one dependant and incomes below $11,00 for single parents, $13,000 for two parent families. | 0.75<br>1.26,<br>1.48 | 0.5<br>0.7,<br>0.7-.025y,<br>08-.025y
The Gary, Indiana Experiment (Gary) | Gary, Indiana | 1971-1974 | 1,799 (967) | Black households, primarily female-headed, head 18-58, income below 240% of poverty line. | 0.75<br>1.0 | 0.4<br>0.6
 The Manitoba Basic Annual Income Experiment (Mincome) | Winnipeg and Dauphin, Manitoba | 1975-1978 | 1,300 | Families with, head younger than 58 and income below $13,000 for a family of four. | C$3,800<br>C$4,800<br>C$5,800 | 0.35<br>0.5<br>0.75

**Summary of findings of work reduction effect**

-tr-
| First Header  | Second Header | Third Header |
| ------------ | :-----------: | -----------: |
| Content       |          *Long Cell*        | |
|Content       |   **Cell**    |         Cell |
| New section   |     More      |         Data |
| And more      | With an escaped  '\|'       | 


```markdown
Stage | Direct Products | ATP Yields
----: | --------------: | ---------:
Glycolysis | 2 ATP ||
^^ | 2 NADH | 3--5 ATP |
Pyruvaye oxidation | 2 NADH | 5 ATP |
Citric acid cycle | 2 ATP ||
^^ | 6 NADH | 15 ATP |
^^ | 2 FADH2 | 3 ATP |
**30--32** ATP |||
```

