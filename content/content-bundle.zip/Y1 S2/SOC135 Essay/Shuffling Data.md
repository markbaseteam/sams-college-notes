 Shuffling Data
    - **Thesis**
        - Technological innovation has its costs. You may have heard that automation and more broadly technological advancements are going to cause job loss.
    - **Intro**
        - You may have heard that automation and more broadly technological advancements are going to cause job loss. While that is true the factor that is being overlooked in that statement is that the advancements that will cause the job loss will also create jobs. In my essay, I will outline how automation and AI will impact the future of work.
    - **Paragraph 1: Broud impacts**
        - the majority of my sources say that the situation isn't as dire as the alarmist views would have you think, about 1/3 of those sources say that they predict that in the long run there will be more jobs that are better. 
        - Some of my sources refer to AI but none of them make direct predictions. According to Kevin Scott LinkedIn data says that demand for AI skills increased 190 percent between 2015 and 2017.
    - **Paragraph 2: AI**
        - In my research, I couldn't find any numbers that refer to the direct impacts of AI.
        - I didn't think that AI would have as large an impact as automaton and due to the lack of stats I'd assume that prediction is correct.
        - In his TED talk, Anthony Goldbloom cites challenges that his company Kaggle put to their community. One algorithm graded high school papers and another one where the algorithm looked at X-rays to diagnose an eye disease called diabetic retinopathy. Both contests had an entry that matched the result from either the doctor or teacher. He also quotes an Oxford study that says almost 1 in 2 jobs have a high risk of being replaced. Also in a TED talk, Kevin Kelly (Founder of The Whole Internet Review and founding executive editor of Wired magazine) said: "The best medical diagnostician is not a doctor, it's not an AI, it's the team. We're going to be working with these AIs, and I think you'll be paid in the future by how well you work with these bots".
  ### Paragraph 3: Automation
- Automation specifically would be the thing that impacts the most.
- ### [[1st Final Draft | Kevin Scott article]]
	- As Kevin Scott mentions in his article there are examples in the US and abroad of jobs being created by automation. 
		- to quote the article "Look no further than Germany’s so-called Mittelstand. These are small- and medium-sized enterprises generating less than 50 million euros in revenue annually. Collectively, it accounts for 99.6 percent of German companies, 60 percent of jobs, and over half of Germany’s gross domestic product. These companies are ingenious at finding narrow but valuable markets to serve, then using highly skilled labor and advanced automation to efficiently produce high-quality products. My friend Hugh E’s employer would be in the Mittelstand, along with 3.3 million others. The US should study and improve upon Germany’s model."
    - **Paragraph 4
More Stats**
        - 
    - **Paragraph 5
Solutions intro**
        - There would likely be some impacts but there are defiantly ways that we could combat those impacts
        - education
        - basic income
        - reeducation programs for workers that lost their jobs due to automation
    - **Paragraph 6
Changing education**
        - 
    - **Paragraph 7
Basic Income**
        - to account for job loss
        - would make everyone 15 and up eligible for a small payment from the government unless you're employed and making a certain amount of money
        - Studies
            - Between 1974 and 1979, Canada ran a randomized controlled trial in the province of **Manitoba**
                -  there was a decline in doctor visits and an 8.5 percent reduction in the rate of hospitalization — and high school graduation rates improved, too
            - In 2017, the Finnish government decided to see what would happen 
                - if it chose 2,000 unemployed citizens at random and gave them a check of 560 euros ($635) every month for two years.
                - As it turned out, the income didn’t help them get jobs, but it did make them feel happier and less stressed.
            - In 2017, Spain’s “B-MINCOME” experiment started offering a minimum guaranteed income to 1,000 households randomly selected from some of **Barcelona**’s poorest districts. Under the two-year randomized controlled trial, households could receive up to 1,675 euros ($1,968) per month. There was also a control group of 383 households.
                - [Preliminary results](https://ajuntament.barcelona.cat/dretssocials/sites/default/files/arxius-documents/results_bmincome_eng.pdf) showed that the effects varied a bit depending on the different modalities. But across the board, the basic income boosted life satisfaction and mental health while making participants neither more likely nor less likely to find employment.
            - Between 2011 and 2012, a pilot project in the state of **Madhya Pradesh** gave a basic income to some 6,000 Indians. The project, coordinated by the Self-Employed Women’s Association and funded by Unicef, included two studies.
                - In the first study, every man, woman, and child in eight villages received a monthly payment: 200 rupees ($2.80) for adults and 100 rupees for each child (paid to the guardian). After one year, the payments increased to 300 and 150 rupees, respectively. Meanwhile, 12 similar villages received no basic income, acting as a control group.
                - In the second study, one tribal village received an income of 300 rupees per adult and 150 rupees per child for the entire trial. Another tribal village acted as a control.
                - The [results](https://www.amazon.com/Basic-Income-Transformative-Policy-India/dp/1472583116?ascsubtag=[]vx[e]20876611[t]w[d]D): Receiving a basic income led to improved sanitation, nutrition, and school attendance.
    - **Paragraph 8
Re-education**
        - 
    - **Conclusion**
        - 