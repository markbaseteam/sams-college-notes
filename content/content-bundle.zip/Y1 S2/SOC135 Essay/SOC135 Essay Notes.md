- Research
  
## Thesis
You may have heard that automation and more broadly technological advancements are going to cause job loss. While that is true the factor that’s being overlooked in that statement is that the advancements that will cause the job loss will also create jobs.
## Intro (convert to sentences)
* Technological innovation has its costs. 
* You may have heard that automation and more broadly technological advancements are going to cause job loss.
* While that is true the factor that’s being overlooked in that statement is that the advancements that will cause the job loss will also create jobs.
* ## Paragraph
* Technological innovation has its costs. You may have heard that automation and more broadly technological advancements are going to cause job loss

## Questions
* What and how much impact will technological innovation have on jobs?
	* How much of an impact will automation have jobs?
		* the majority of my sources say that the situation isn't as dire as the alarmist views would have you think. about 1/3 of those sources say that they predict that in the long run there will be more jobs that are better. 
	* Will AI have an impact on jobs?
		* Some of my sources refer to AI but none of them make direct predictions. According to Kevin Scott LinkedIn data says that demand for AI skills increased 190 percent between 2015 and 2017. 
* How will it be dealt with
	* education
	* basic income
	* reeducation programs for workers that lost their jobs due to automation

- ## Examples
	* Take the steel industry. It lost 400,000 people, 75 percent of its work force, between 1962 and 2005. ([NY Times](((SZvH8ap2R))))
	* Automation May Take Jobs—but AI Will Create Them
		* Opinion in Wired by Kevin Scott, CTO and executive vice president of AI and research at Microsoft
		* Germany’s Mittelstand
			* 99.6% of German companies 60 percent of jobs, and over 1/2 of Germany's GDP
			* German small-medium sized companies that serve narrow markets that take advantage of highly skilled labor and advanced automation to efficiently produce high-quality products.
		* according to LinkedIn data demand for AI skills increased 190 percent between 2015 and 2017
- AI, automation, and the future of work: Ten things to solve for - McKinsey
            30 percent of the activities in 60 percent of all occupations could be automated
            fastest scenario = 30 percent, or 800 million workers displaced
            slowest adoption scenario = 10 million jobs displaced
            scenarios showed a range of additional labor demand of between 21 percent to 33 percent of the global workforce (555 million and 890 million jobs) to 2030, more than offsetting the numbers of jobs lost.
            Our research suggests that, in a midpoint scenario, around 3 percent of the global workforce will need to change occupational categories by 2030, though scenarios range from about 0 to 14 percent. Some of these shifts will happen within companies and sectors, but many will occur across sectors and even geographies.
- Statcan Article
	- ## The Data Says
		- Highest level of Education
			- no certificate, diploma or degree = 33.4%
			- high school diploma = 24.1%
			-  BS or better less than 4% each
		- field of study
			- Maths and Sciences = under 7%
			- Business = over 12%
	- Overall, 10.6% of Canadian workers were at high risk (probability of 70% or higher) of automation-related job transformation in 2016, while 29.1% were at moderate risk (probability of between 50% and 70%). Several groups had a relatively higher share of workers who were at high risk, including those who were older (55 or above).
	- Office support occupations and the manufacturing sector are at highest risk
- Research: Automation Affects High-Skill Workers More Often, but Low-Skill Workers More Deeply - Harvard Business Review
	- We found that automation does indeed affect many workers. Each year, about 9% of the workers in the sample are employed at firms that make major investments in automation. Yet relatively few workers are adversely affected. Only about 2% of tenured workers at automating firms leave the year of the automation event as a result of automation; after five years, 8.5% will have left
	- Surprisingly, this burden falls more frequently on highly-educated and highly-paid workers. Contrary to conventional wisdom, they are more likely to leave as a result of automation, although they also seem to find new jobs faster. In other words, highly-paid workers are more commonly affected, but the effects are more severe for less well-paid workers.
	-  only 0.7% of all workers on average leave their employers each year due to automation
	- In contrast, in the Netherlands, about 3.5%-7.2% lose their jobs each year in mass layoffs, typically defined as a layoff of 30% or more of the workforce.  (The comparable rate is 4.4% in the U.S.)
	- The real impact of automation is on income and time spent unemployed. 
		- The data show that after a spike, tenured workers cumulatively lose about 3,800 Euros in wage and salary earnings over five years on average (about 9% of one year’s income).  More recent hires also experience a negative impact, but only about 3% of one year’s income, which perhaps reflects their adaptability and flexibility as newer hires.
		- Conditional on leaving, incumbent workers are employed 43 fewer days over five years following the automation event. Only about 12% of these losses are made up by unemployment, welfare, or disability payments, which is comparable to what workers receive after a mass layoff.
	- Conclusion
		- The study paints a picture of automation today that does not support the most alarmist views. The burden that automation places on workers is less than the burden created by mass layoffs and plant closings that arise from things like declining demand or bankruptcies. Nevertheless, the burden placed on affected workers is substantial, and existing safety net programs are not providing these workers much economic security. And, of course, the impact of automation might worsen in the future.  Further research will show what happens to net employment after automation, and to the workers hired after the automation event.
- New Brookings report forecasts automation’s sizable impacts on the American workforce through 2030 - Bookings
	- ## Key findings include:
	- Demographic variation: Young people, men, and underrepresented groups, particularly Hispanics and blacks, will face pronounced difficulties as a result of automation’s disruptions — an underexplored viewpoint in current coverage of automation.
	- Geographic unevenness: Some places will do much better than others in dealing with the coming transitions. Places such as Las Vegas, Louisville, Ky., and Toledo, Ohio are among the most susceptible to the automation of job tasks, while the list of least susceptible places includes coastal giants such as Washington, D.C., the Bay Area, New York City, and Boston.
	- Varying levels of occupational susceptibility: By 2030, some 25 percent of U.S. employment will have experienced high exposure to automation, while another 36 percent of U.S. employment will experience medium exposure, and another 39 percent will experience low exposure. Those with greater than 90 percent automation potential over the next two to three decades represented only 4 percent of U.S. employment in 2016. Job tasks projected to be 100 percent automatable represent only half of one percent of the workforce (740,000 jobs).
	- Education helps combat automation: Occupations not requiring a bachelor’s degree are a staggering 229 percent more susceptible to automation compared to occupations requiring at least a bachelor’s degree. Just 6 percent of workers with a four-year degree or more are employed in jobs with a high potential for automation
	- ## Conclusion
		- While this report concludes that the future may not be as dystopian as the most dire voices claim, plenty of people and places will be affected by automation, and much will need to be done to mitigate the coming disruptions. The authors offer five recommendations for federal, state, and local policymakers: 1) embrace growth and technology; 2) promote a constant learning mindset; 3) facilitate smoother adjustment; 4) reduce hardships for workers who are struggling, and 5) mitigate harsh local impacts.
        - The jobs we'll lose to machines -- and the ones we won't | Anthony Goldbloom - TED Talk
            - 2013 Oxford study on future of work
                - almost 1 in 2 jobs have high risk of being replaced
            - machine learning is the source of most of that
            - In 2013, Kaggle challenged its community to write algorithms to grade high school papers and the winner was able to match the grades
            - then in 2015, Kaggle challenged its community to write algorithms to diagnose 
an eye disease called diabetic retinopathy again the winner was able to match humans
        - How AI can bring on a second Industrial Revolution | Kevin Kelly - TED Talk
            - we have tendencies
            - Inteligence isn't a single note but more like a symphany 
            - we're trying to make as many types of thinking as possible
                - So in general, what we're trying to do is make as many different types of thinking as we can. We're going to populate the space of all the different possible types, or species, of thinking. And there actually may be some problems that are so difficult in business and science that our own type of human thinking may not be able to solve them alone. We may need a two-step program, which is to invent new kinds of thinking that we can work alongside of to solve these really large problems,  say, like dark energy or quantum gravity. What we're doing is making alien intelligences. You might even think of this as, sort of, artificial aliens in some senses.
            - We're also going to learn that we're going to work with these AIs because they think differently than us. When Deep Blue beat the world's best chess champion, people thought it was the end of chess. But actually, it turns out that today, the best chess champion in the world is not an AI. And it's not a human. It's the team of a human and an AI. The best medical diagnostician is not a doctor, it's not an AI, it's the team. We're going to be working with these AIs, and I think you'll be paid in the future by how well you work with these bots.
        - What will future jobs look like? | Andrew McAfee - TED Talk
            - Now, for about 200 years, people have been saying exactly what I'm telling you --the age of technological unemployment is at hand —starting with the Luddites smashing looms in Britain just about two centuries ago, and they have been wrong. Our economies in the developed world have coasted along on something pretty close to full employment.
            - Why is this time different, if it really is? The reason it's different is that, just in the past few years, our machines have started demonstrating skills they have never, ever had before: understanding, speaking, hearing, seeing, answering, writing, and they're still acquiring new skills.
                - For example, mobile humanoid robots
                    - are still incredibly primitive, but the research arm of the Defense Department just launched a competition to have them do things like this, and if the track record is any guide, this competition is going to be successful.
            - And we're creating a world where there is going to be more and more technology and fewer and fewer jobs. It's a world that Erik Brynjolfsson and I are calling "the new machine age." 
                - The thing to keep in mind is that this is absolutely great news. This is the best economic news on the planet these days. Not that there's a lot of competition, right? This is the best economic news we have these days for two main reasons.
                    - The first is, technological progress is what allows us to continue this amazing recent run that we're on where output goes up over time, while at the same time, prices go down, and volume and quality just continue to explode. Now, some people look at this and talk about shallow materialism, but that's absolutely the wrong way to look at it.  This is abundance, which is exactly what we want our economic system to provide.
                    - The second reason that the new machine age Is such great news is that, once the androids start doing jobs, we don't have to do them anymore, and we get freed up from drudgery and toil.\
    - ## Quotes
        - The first rule of any technology used in a business is that automation applied to an efficient operation will magnify the efficiency. The second is that automation applied to an inefficient operation will magnify the inefficiency.

 - Bill Gates
        - Well, you can say there is a self-driving car. I'm seeing the automation of vehicles. Really, computer-assisted driving. I think that is really interesting to us because we are taking all of the sensors technologies and putting them in cars and making people safer.

 - Tony Fadell
        - The job market of the future will consist of those jobs that robots cannot perform. Our blue-collar work is pattern recognition, making sense of what you see. Gardeners will still have jobs because every garden is different. The same goes for construction workers. The losers are white-collar workers, low-level accountants, brokers, and agents. 

 - Michio Kaku
        - When the manufacturing decline began in earnest in 2001, the main culprits were the offshoring of jobs to China, with which we have no trade deal, and automation.

 - William M. Daley
        - Automation is going to cause unemployment, and we need to prepare for it.

 - Mark Cuban
        - There's a lot of automation that can happen that isn't a replacement of humans but of mind-numbing behavior.

 - Stewart Butterfield
        - As technology advances, it reverses the characteristics of every situation again and again. The age of automation is going to be the age of 'do it yourself.'

 - Marshall McLuhan
        - The promise of artificial intelligence and computer science generally vastly outweighs the impact it could have on some jobs in the same way that, while the invention of the airplane negatively affected the railroad industry, it opened a much wider door to human progress.

 - Paul Allen
        - Americans want students to get the best education possible. We want schools to prepare children to become good citizens and members of a prosperous American economy.

 - Bill Gates
        - We are living in a global world - but most schools and books still tell us only parochial histories of one particular country or culture. The truth is that there are no longer any independent countries in the world.

 - Yuval Noah Harari
        - I believe e-courses will eventually change people's attitude toward learning. Education will play an increasingly dominant role in people's lives. For people of all ages and all geographies.
 
- Sebastian Thrun
        - I really believe that we have to work hard to make online education better and better, and eventually it's going to be really great. But like most of these things, it takes time to improve, to understand and to make things really good. 

 - Sebastian Thrun
        - I had a good experience in college, but I don't think interdisciplinary education is something that's stressed very much at all. It's generally considered to be something of a bad idea. 

 - Peter Thiel
        - Technology's always taken jobs out of the system, and what you hope is that technology's going to put those jobs back in, too. That's what we call productivity. 

 - Marc Benioff
        - Nothing is more important, certainly during these times of artificial intelligence, than our public education. And as it continues to grow and evolve, I think you and I know this is going to be critical that we are constantly training and retraining and creating these next-generation jobs. 

 - Marc Benioff
        - To create a new standard, it takes something that's not just a little bit different; it takes something that's really new and really captures people's imagination, and the Macintosh, of all the machines I've ever seen, is the only one that meets that standard. 

 - Bill Gates
        - Artificial intelligence... I've been following that since I was in high school. 

 - Paul Allen
        - “The emphasis needs to be placed[ on skills](http://www.weforum.org/events/world-economic-forum-annual-meeting-2016/sessions/the-transformation-of-tomorrow),” said Satya Nadella, CEO of Microsoft, at the panel session the Transformation of Tomorrow. “We will have to spend the money to educate our people – not just the children, but also people getting misplaced mid-career – so that they can find new jobs.”
    - ## Key Terms and References
    - ## Subject Matter Experts (SMEs)
        - Kevin Scott,
CTO and EVP of AI and research 
Microsoft
        - Kevin Kelly
        - Andrew McAfee
        - Anthony Goldbloom

- [[New Final Draft: SOC135 Essay]]
