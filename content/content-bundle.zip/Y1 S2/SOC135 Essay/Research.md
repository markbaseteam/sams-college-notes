  * [[September 24th, 2020]]
		* Pew Article
			* Many studies have determined that jobs are at thousands of jobs at risk from automation
			* A recent study by labor economists found that “one more robot per thousand workers reduces the employment to population ratio by about 0.18-0.34 percentage points and wages by 0.25-0.5 percent.” 
			* A 2016 Pew Research Center survey, “The State of American Jobs,” found that 87% of workers believe it will be essential for them to get training and develop new job skills throughout their work life in order to keep up with changes in the workplace.
			* A considerable number of respondents to this canvassing focused on the likelihood that the best education programs will teach people how to be lifelong learners. Accordingly, some say alternative credentialing mechanisms will arise to assess and vouch for the skills people acquire along the way."
* [[September 25th, 2020]]
	* Government of Canada report
            - Release date:**** June 29, 2020**
## 2016 Study**
   * 10.6% of Canadian workers were at high risk (probability of 70% or higher) of automation-related job transformation in 2016, while 29.1% were at moderate risk (probability of between 50% and 70%).
   * In the Americas, robot density rose by 7% annually, on average, between 2010 and 2016. This was lower than the annual growth rate in Asia (9%), but higher than the rate in Europe (5%).
   * Canada was in 13th place internationally with regard to robot density (145 robots in use per 10,000 employees). The Republic of Korea (631) was in first place, followed by Singapore (488) in second place. The United States (189) was in seventh place. Canada was ahead of France (132) in 18th place, and Australia (83) in 21st place. The worldwide average was 74 units per 10,000 employees.
## New Study
### Data
Category | % displacement
------------|-----------------
Office support occupations group | 35.7%
Service supervisors and specialized service occupations | 20%
Industrial, electrical and construction trades | 19.7%
Sales representatives and salespersons | 14.7%
Service representatives and other customer and personal services occupations | 13.7%
Maintenance and equipment operation trades | 13.2%

Age Group | % displacement
------------|-------------------
18 - 24 | 13.3%
55 & older| 14.6%
25 - 34 | 7.6%
35 -54 | 10.1%

**Educational Group | % displacement**
   ------------|-------------------
no certificate, diploma or degree | 33.4%
high school diploma | 24.1%
bachelor’s degree | 3.6%
master's | 1.3%

**Field of Study** | **% displacement**
------------|-------------------
Maths and Sciences | under 7%
Business | over 12%
**probability of facing high risk** | 
 Education | 1%
 Health / related | 1.8%

## **Conclusion**
- Overall, 10.6% of Canadian workers were at high risk (probability of 70% or higher) of automation-related job transformation in 2016, while 29.1% were at moderate risk (probability of between 50% and 70%). Several groups had a relatively higher share of workers who were at high risk, including those who were older (55 or above).
- Office support occupations and the manufacturing sector are at highest risk
                    - 
  ## WP article (2018)
	- 75 million jobs may be lost as companies shift to more automation, according to new estimates by the [World Economic Forum](https://www.weforum.org/reports/the-future-of-jobs-report-2018).
	- Machines account for 29 percent of the total hours worked in major industries, compared with 71 percent performed by people. By 2022, however, the report predicts that 42 percent of task hours will be performed by machines and 58 percent by people.


    - [[September 27th, 2020]]
 ### The Long-Term Jobs Killer Is Not China. It’s Automation (NY Times)
- Take the steel industry. It lost 400,000 people, 75 percent of its work force, between 1962 and 2005.
### Automation May Take Jobs—but AI Will Create Them - Opinion in Wired by Kevin Scott, CTO and executive vice president of AI and research at Microsoft
- Bass Sod Farms
	- a sod farm that grew by smartly using automation tech
- American Plastic Fabricators
- Germany’s Mittelstand
	- 99.6% of German companies 60 percent of jobs, and over 1/2 of Germany's GDP
	- German small-medium sized companies that serve narrow markets that take advantage of highly skilled labor and advanced automation to efficiently produce high-quality products.
- according to LinkedIn data demand for AI skills increased 190 percent between 2015 and 2017
### Why robots, not trade, are behind so many factory job losses - AP
- The vast majority of the lost jobs — 88 percent
  ### AI, automation, and the future of work: Ten things to solve for - McKinsey
- we find that about 30 percent of the activities in 60 percent of all occupations could be automated.
- Automation will displace some workers. [We have found that around 15 percent of the global workforce](https://www.mckinsey.com/featured-insights/future-of-work/jobs-lost-jobs-gained-what-the-future-of-work-will-mean-for-jobs-skills-and-wages), or about 400 million workers, could be displaced by automation in the period 2016–2030.
- Under the fastest scenario we have modeled, that figure rises to 30 percent, or 800 million workers. In our slowest adoption scenario, only about 10 million people would be displaced, close to zero percent of the global workforce.
- in advanced economies with relatively high wage levels, such as France, Japan, and the United States, automation could displace 20 to 25 percent of the workforce by 2030, in a midpoint adoption scenario, more than double the rate in India.
- scenarios showed a range of additional labor demand of between 21 percent to 33 percent of the global workforce (555 million and 890 million jobs) to 2030, more than offsetting the numbers of jobs lost.
- Our research suggests that, in a midpoint scenario, around 3 percent of the global workforce will need to change occupational categories by 2030, though scenarios range from about 0 to 14 percent. Some of these shifts will happen within companies and sectors, but many will occur across sectors and even geographies.
### Ten things to solve for
- **Ensuring robust economic and productivity growth**: Strong growth is not the magic answer for all the challenges posed by automation, but it is a prerequisite for job growth and increasing prosperity. Productivity growth is a key contributor to economic growth. Therefore, unlocking investment and demand, as well as embracing automation for its productivity contributions, is critical.
- **Fostering business dynamism**: Entrepreneurship and more rapid new business formation will not only boost productivity, but also drive job creation. A vibrant environment for small businesses as well as a competitive environment for large business fosters business dynamism and, with it, job growth. Accelerating the rate of new business formation and the growth and competitiveness of businesses, large and small, will require simpler and evolved regulations, tax and other incentives.
- **Evolving education systems and learning for a changed workplace**: Policy makers working with education providers (traditional and nontraditional) and employers themselves could do more to improve basic STEM skills through the school systems and improved on-the-job training. A new emphasis is needed on creativity, critical and systems thinking, and adaptive and life-long learning. There will need to be solutions at scale.
- **Investing in human capital**: Reversing the trend of low, and in some countries, declining [public investment in worker training](https://data.oecd.org/socialexp/public-spending-on-labour-markets.htm) is critical. Through tax benefits and other incentives, policy makers can encourage companies to invest in human capital, including job creation, learning and capability building, and wage growth, similar to incentives for private sector to invest in other types of capital including R&D.
- **Improving labor-market dynamism**: Information signals that enable matching of workers to work, credentialing, could all work better in most economies. Digital platforms can also help match people with jobs and restore vibrancy to the labor market. When more people change jobs, even within a company, [evidence suggests that wages rise](https://www.mckinsey.com/featured-insights/employment-and-growth/connecting-talent-with-opportunity-in-the-digital-age). As more varieties of work and income-earning opportunities emerge including the [gig economy](https://www.mckinsey.com/featured-insights/employment-and-growth/independent-work-choice-necessity-and-the-gig-economy), we will need to solve for issues such as portability of benefits, worker classification, and wage variability.
- **Redesigning work**: Workflow design and workspace design will need to adapt to a new era in which people work more closely with machines. This is both an opportunity and a challenge, in terms of creating a safe and productive environment. Organizations are changing too, as work becomes more collaborative and companies seek to become increasingly agile and nonhierarchical.
- **Rethinking incomes**: If automation (full or partial) does result in a significant reduction in employment and/or greater pressure on wages, some ideas such as conditional transfers, support for mobility, universal basic income, and adapted social safety nets could be considered and tested. The key will be to find solutions that are economically viable and incorporate the multiple roles that work plays for workers, including providing not only income, but also meaning, purpose, and dignity.
- **Rethinking transition support and safety nets for workers affected**: As work evolves at higher rates of change between sectors, locations, activities, and skill requirements, many workers will need assistance adjusting. Many best practice approaches to transition safety nets are available, and should be adopted and adapted, while new approaches should be considered and tested.
- **Investing in drivers of demand for work**: Governments will need to consider stepping up investments that are beneficial in their own right and will also contribute to demand for work (for example, infrastructure, climate-change adaptation). These types of jobs, from construction to rewiring buildings and installing solar panels, are often middle-wage jobs, those most affected by automation.
- **Embracing AI and automation safely**: Even as we capture the productivity benefits of these rapidly evolving technologies, we need to actively guard against the risks and mitigate any dangers. The use of data must always take into account concerns including data security, privacy, malicious use, and potential issues of bias, issues that policy makers, tech and other firms, and individuals will need to find effective ways to address.

[[October 18th, 2020]]
### Automation is making human labor more valuable than ever - Vox
- take the beer industry
	- "The future of work: How G20 countries can leverage digital-industrial innovations into stronger high-quality jobs growth"
- coffee shops
	- A Starbucks barista in Minnesota griped that the new rules had "doubled the amount of time it takes to make drinks in some cases." That's not only bad for the bottom line; it can also inconvenience customers by creating longer, slower lines.
	- But Starbucks management understood something important about their business: People don't go to Starbucks simply to get a cup of coffee — after all, there are lots of cheaper and faster ways to get coffee. People go to Starbucks because they enjoy the experience. And that experience has an important performative dimension — customers want to feel like their barista devoted personal attention to preparing their cup.
	- And Starbucks is hardly the most upscale coffee shop around. Serious coffee snobs refuse to drink the stuff, preferring independent coffee shops with exotic fair-trade beans. The process of making coffee at these stores is often even more elaborate and labor-intensive than at Starbucks. And because these shops are often smaller and don't have the Starbucks brand pulling in customers, baristas tend to serve fewer customers — often leading to higher prices.
    
	### Research: Automation Affects High-Skill Workers More Often, but Low-Skill Workers More Deeply - Harvard Business Review
- We found that automation does indeed affect many workers. Each year, about 9% of the workers in the sample are employed at firms that make major investments in automation. Yet relatively few workers are adversely affected. Only about 2% of tenured workers at automating firms leave the year of the automation event as a result of automation; after five years, 8.5% will have left
- Surprisingly, this burden falls more frequently on highly-educated and highly-paid workers. Contrary to conventional wisdom, they are more likely to leave as a result of automation, although they also seem to find new jobs faster. In other words, highly-paid workers are more commonly affected, but the effects are more severe for less well-paid workers.
-  only 0.7% of all workers on average leave their employers each year due to automation
- In contrast, in the Netherlands, about 3.5%-7.2% lose their jobs each year in mass layoffs, typically defined as a layoff of 30% or more of the workforce.  (The comparable rate is 4.4% in the U.S.)
- The real impact of automation is on income and time spent unemployed. 
	- The data show that after a spike, tenured workers cumulatively lose about 3,800 Euros in wage and salary earnings over five years on average (about 9% of one year’s income).  More recent hires also experience a negative impact, but only about 3% of one year’s income, which perhaps reflects their adaptability and flexibility as newer hires.
	- Conditional on leaving, incumbent workers are employed 43 fewer days over five years following the automation event. Only about 12% of these losses are made up by unemployment, welfare, or disability payments, which is comparable to what workers receive after a mass layoff.
- Conclusion
	- The study paints a picture of automation today that does not support the most alarmist views. The burden that automation places on workers is less than the burden created by mass layoffs and plant closings that arise from things like declining demand or bankruptcies. Nevertheless, the burden placed on affected workers is substantial, and existing safety net programs are not providing these workers much economic security. And, of course, the impact of automation might worsen in the future.  Further research will show what happens to net employment after automation, and to the workers hired after the automation event.

### New Brookings report forecasts automation’s sizable impacts on the American xworkforce through 2030 - Bookings
- ## Key findings include:
- Demographic variation: Young people, men, and underrepresented groups, particularly Hispanics and blacks, will face pronounced difficulties as a result of automation’s disruptions — an underexplored viewpoint in current coverage of automation.
- Geographic unevenness: Some places will do much better than others in dealing with the coming transitions. Places such as Las Vegas, Louisville, Ky., and Toledo, Ohio are among the most susceptible to the automation of job tasks, while the list of least susceptible places includes coastal giants such as Washington, D.C., the Bay Area, New York City, and Boston.
- Varying levels of occupational susceptibility: By 2030, some 25 percent of U.S. employment will have experienced high exposure to automation, while another 36 percent of U.S. employment will experience medium exposure, and another 39 percent will experience low exposure. Those with greater than 90 percent automation potential over the next two to three decades represented only 4 percent of U.S. employment in 2016. Job tasks projected to be 100 percent automatable represent only half of one percent of the workforce (740,000 jobs).
- Education helps combat automation: Occupations not requiring a bachelor’s degree are a staggering 229 percent more susceptible to automation compared to occupations requiring at least a bachelor’s degree. Just 6 percent of workers with a four-year degree or more are employed in jobs with a high potential for automation
- ## Conclusion
	- While this report concludes that the future may not be as dystopian as the most dire voices claim, plenty of people and places will be affected by automation, and much will need to be done to mitigate the coming disruptions. The authors offer five recommendations for federal, state, and local policymakers: 1) embrace growth and technology; 2) promote a constant learning mindset; 3) facilitate smoother adjustment; 4) reduce hardships for workers who are struggling, and 5) mitigate harsh local impacts.

### [[October 24th, 2020]]
- The jobs we'll lose to machines -- and the ones we won't | Anthony Goldbloom - TED Talk
	- 2013 Oxford study on future of work
		- almost 1 in 2 jobs have high risk of being replaced, machine learning is the source of most of that
		- In 2013, Kaggle challenged its community to write algorithms to grade high school papers and the winner was able to match the grades
		- then in 2015, Kaggle challenged its community to write algorithms to diagnose an eye disease called diabetic retinopathy again the winner was able to match humans
- How AI can bring on a second Industrial Revolution | Kevin Kelly - TED Talk
	- we have tendencies
	- Inteligence isn't a single note but more like a symphany 
	- we're trying to make as many types of thinking as possible
		- So in general, what we're trying to do is make as many different types of thinking as we can. We're going to populate the space of all the different possible types, or species, of thinking. And there actually may be some problems that are so difficult in business and science that our own type of human thinking may not be able to solve them alone. We may need a two-step program, which is to invent new kinds of thinking that we can work alongside to solve these really large problems,  say, like dark energy or quantum gravity. What we're doing is making alien intelligences. You might even think of this as, sort of, artificial aliens in some senses.
	- We're also going to learn that we're going to work with these AIs because they think differently than us. When Deep Blue beat the world's best chess champion, people thought it was the end of chess. But actually, it turns out that today, the best chess champion in the world is not an AI. And it's not a human. It's the team of a human and an AI. The best medical diagnostician is not a doctor, it's not an AI, it's the team. We're going to be working with these AIs, and I think you'll be paid in the future by how well you work with these bots.
	- What will future jobs look like? | Andrew McAfee - TED Talk
	- Now, for about 200 years, people have been saying exactly what I'm telling you --the age of technological unemployment is at hand —starting with the Luddites smashing looms in Britain just about two centuries ago, and they have been wrong. Our economies in the developed world have coasted along on something pretty close to full employment.
	- Why is this time different, if it really is? The reason it's different is that, just in the past few years, our machines have started demonstrating skills they have never, ever had before: understanding, speaking, hearing, seeing, answering, writing, and they're still acquiring new skills.
		- For example, mobile humanoid robots
			- are still incredibly primitive, but the research arm of the Defense Department just launched a competition to have them do things like this, and if the track record is any guide, this competition is going to be successful.
	- And we're creating a world where there is going to be more and more technology and fewer and fewer jobs. It's a world that Erik Brynjolfsson and I are calling "the new machine age." 
		- The thing to keep in mind is that this is absolutely great news. This is the best economic news on the planet these days. Not that there's a lot of competition, right? This is the best economic news we have these days for two main reasons.
			- The first is, technological progress is what allows us to continue this amazing recent run that we're on where output goes up over time, while at the same time, prices go down, and volume and quality just continue to explode. Now, some people look at this and talk about shallow materialism, but that's absolutely the wrong way to look at it.  This is abundance, which is exactly what we want our economic system to provide\
			- The second reason that the new machine age Is such great news is that, once the androids start doing jobs, we don't have to do them anymore, and we get freed up from drudgery and toil.\