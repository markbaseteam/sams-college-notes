- Why was the rise of the Mongol Empire historically significant? 
    - It made it that there were less countries to with if you wanted to travel between Europe and China
    - encouraged trade
    - Didn't count religion as a factor in who could be in the empire
    - Infrastructure to make trade easier
- How did the Pax Mongolica facilitate connections between Eurasian civilizations?
    - The Pax Mongolica fundamentally allowed Marco Polo and
other travellers to indeed were exceptionally able
to in general make the journey because of the truly open
borders of the Mongols. To effectively increase trade and travel
throughout the empire the Mongols extremely opened borders
to specifically make it easier to trade.
