 ```toc
```
## IoT
### What's IoT
```ad-note 
title: Definition 
A network of interconnected devices that are able to exchange data
```
### Examples
- Temp & Humidity Sensors
- Smart Bulbs
- Security Cams, etc.

### Services
#### Azure IoT Central
- fully managed
- scaling built-in
#### Azure IoT Hub
- managed
- bi-directional
#### Azure Sphere
- 2<sup>nd</sup> level of app platform
- built-in security communication and security features

## Big Data Analytics
```ad-note 
title: Definition 
Massive volumes of data that are hard to process with stanard tools
```
### Azure Sphere Analytics
- enterprise data warehousing
- SQL based 
- The control node is the brain of the system
- the compute node is what actually processes the data 
### HOInsuight
can run the following services
- Hadoop
- Kafka
- Spark

### Azure Databricks
- What it can do:
	- streaming
	- SQL Processing
- GUI enabled
- programable with Python

## AI & Machine Learning
### Azure Machine Learning
```ad-info
title: Definition

Cloud-based environment for development and deployment of ML models

```
### Cognitive Services
```ad-info
title: <h3>Definition</h3>

Allows apps to interoperate and understand various types of user input and produce a result

```
### Bot Services
```ad-info
title: <h3>Definition</h3>

What it sounds like

```

### Automated ML in Azure 
![[ML In Azure#^afde14]]



## Key Terms
| Terms         | Definition                                                                                |
| ------------- | ----------------------------------------------------------------------------------------- |
| AI            | Machines that perform jobs that mimic human behaviour.                                    |
| ML            | Machines that get better at a task without explicit programming                           |
| Deep Learning | a machine learning technique that teaches computers to do what comes naturally to humans. |
| Serverless Computing |                                                                                           |