```toc
	title: Network Security
```
## Defence in Depth
- Layered approach
  ![[Layers of Security.png]]

## Services
### Network Security Groups & Firewalls
 - filter traffic to and from resources on Azure Virtual Networks
 - security groups for VNs
### DDoS Protection
- enabled automatically in Azure's basic tier
- standard tier adds mitigation capabilities