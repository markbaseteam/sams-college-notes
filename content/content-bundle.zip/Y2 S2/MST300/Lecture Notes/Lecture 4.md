```toc
```
## Storage Types
| Storage Type | Description  |
| --- |  --- |
| Structured Data | Adheres to a schema | 
### Structured Data
- sometimes 
### Unstructured Data
- data that are ambiguous
- files like documents or images
## Azure Storage Services
| Service | Description |
| --- | --- |
|Disk Storage |  provides virtualized disks | 
## Access Tiers
| Tier | Description |
| --- | --- |
| **Hot tier** | An online tier optimized for storing data that is accessed or modified frequently. The Hot tier has the highest storage costs, but the lowest access costs. | 
| **Cool tier** | An online tier optimized for storing data that is infrequently accessed or modified. Data in the Cool tier should be stored for a minimum of 30 days. The Cool tier has lower storage costs and higher access costs compared to the Hot tier. | 
| **Archive tier** | An offline tier optimized for storing data that is rarely accessed, and that has flexible latency requirements, on the order of hours. Data in the Archive tier should be stored for a minimum of 180 days. | 