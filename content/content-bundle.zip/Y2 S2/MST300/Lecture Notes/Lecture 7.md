```toc
```
## Features
### Security Centre
- Monitoring service for both on-prem and Azure.
- security alerts
  Automatically creates logs
- detect malware
- policy controls
### Key Vault
- Centralized application secret storage
- Features Include
	- Secret Management 
	- Key Management
	- cert management
### Sentinal
- Security Information Management & Security Automated Response solution
- Threat detection, collection, investigation and, response
### Dedicated Host
- provides physical servers that are dedicated to a particular company
- same servers that are used in Azure datacentres