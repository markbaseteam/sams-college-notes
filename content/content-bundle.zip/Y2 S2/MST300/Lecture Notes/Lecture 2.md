## Regions
- Geographic Groups of Datacenters 
- Azure offers the most regions out of the major cloud service providers
### Benefits of Regions
- provides flexibility and scale to reduce customer latency
- preserves data residency
## Region Pairs
- 300 miles between datacenters in region pairs
- automatic replication
## Availability Options
| Option | SLA | Other Details |
|--- | --- | --- |
| Single VM |  3 9s | N/A | 
| Availability Zone | 4 9s | Multiple VMs |
## Availability Zones
- a physical location made up of one or more datacenter
- at least 3 zones per region (isolated from each other)
### Availability Sets
> A group with two or more virtual machines in the same Data Center is called Availability Set, this ensures that at least one of the virtual machines hosted on Azure will be available if something happens. This configuration offers 99.95% SLA.

 \- Microsoft TechNet

- Availability Sets are in the same data center but Availability Zones aren't
## Azure Resources
| Resource | Description |
| --- | --- |
| VMs | what it sounds like |
| Storage Account | Provides unique namespace to access you data anywhere in the world over the internet | 
| Virtual Network | - A representation of your physical network in the cloud <br> - all devices in a vNet can communicate with each other | 
| App Services | Managed web hosting | 
| SQL Database | Managed SQL servers | 