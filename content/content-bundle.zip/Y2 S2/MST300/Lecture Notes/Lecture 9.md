```toc
```
## 1 Governance
### Role-based Access Controls
- fine-grained access management
- grant users limited access 
- enable access to Azure portal for particular users.

#### Elements of a Role
```ad-info
title: Security principal

A _security principal_ is an object that represents a user, group, service principal, or managed identity that is requesting access to Azure resources. You can assign a role to any of these security principals.

```

```ad-info
title: Role definition

A _role definition_ is a collection of permissions. It's typically just called a _role_. A role definition lists the actions that can be performed, such as read, write, and delete. Roles can be high-level, like owner, or specific, like virtual machine reader.

```

### Resource Lock
- what it sounds like 