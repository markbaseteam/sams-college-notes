```toc
```
## Azure Compute
- on-demand 
- provides:
	- disks
	- processors
	- memory
	- networking
	- OSs
### Services
| Service | Description |
| --- | --- |
| VMs | - On-Demand, scalable service available in Azure Cloud <br>- Used to host applications when customer requires extra control over the computing environment | 
| App Services | managed hosting | 
| Container Instances | Enables devs to deploy containers on the cloud|
| Kubernetes Services | | 
| Windows Virtual Desktop | system for virtualizing its [Windows](https://www.wikiwand.com/en/Microsoft_Windows) operating systems, providing [virtualized desktops](https://www.wikiwand.com/en/Desktop_virtualization) and applications [in the cloud](https://www.wikiwand.com/en/Cloud_computing) |
## Levels of Computing
### Dedicated
- upgrading can be slow and expensive
- running 
### VMs
- multiple can be run on a single server
- limited to guest OS
- resource usage issues are isolated to each VM and won't affect other VMs
### Containers
- VMs can run multiple containers
- share the same OS
- maximizes compacity in a cost-effective way
### Functions (AKA Serverless Compute)
- Managed VMs running managed containers
- code is uploaded directly
- only responsible for code and data
- only paying for the time the code is running
- possibility of Cold Starts
## Azure Networking Services
| Service | Description |
| --- | --- |
| Virtual Networks | Allows resources to communicate with each other and/or the internet | 
| VPN Gateway | what it sounds like | 
| Express Route | Expands on-prem networks into Azure |