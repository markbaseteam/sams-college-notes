1.  Create 3 VNETs
	1. MST300-vnet1 with subnets:
		1. vnet1-subnet1l
		2.  AzureBastionSubnet
	2.  MST300-vnet2 with sublet vnet2-subnet1
	3.  MST300-vnet2 with sublet vnet1-subnet1l
2. Assign proper IPs to the VNETs