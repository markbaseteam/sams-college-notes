<center><H1>MST300 Projects</H1></center>

Sam Greenwood
<div align=right>102695195</div> 

## Project 1
<ol>
	<li>Create 3 VNETs</li>
		<ol type="a">
			<li> MST300-vnet1 with subnets:</li>
				<ul>
					<li>vnet1-subnet1</li>
					<li>AzureBastionSubnet</li>
				</ul>
			<li>MST300-vnet2 with sublet vnet2-subnet1</li>
			<li>MST300-vnet3 with sublet vnet3-subnet1 </li>
		</ol>
	<li>Assign proper IPs to the VNETs</li>
	<li>Create VMs</li>
		<ul>
			<li class=h4>Bastion VM</li>
				<ul>
					<li>Name it MST300-BastionHost</li>
					<li>Put it on VNET1s BastionHost subnet with BastionHostIP</li>
				</ul>
			<li class=h4>Domain Controller VM</li>
				<ul>
					<li>Name it dc-vm</li>
					<li>it should be running <i>Windows Server 2019 Datacenter – Gen1</i> at <i>Standard_B1s</i> tier</li> 
					<li>it should be on MST300-vnet1 subnet1</li>
				</ul>
			<li class=h4>Webserver VM</li>
				<ul>
					<li>call it webserver-vm</li>
					<li>it should be running <i>Windows Server 2019 Datacenter – Gen1</i> at <i>Standard_B1s</i> tier</li> 
					<li>it should be on MST300-vnet2 subnet1</li>
				</ul>
			<li class=h4>Client VM</li>
				<ul>
					<li>call it client-vm</li>
					<li>it should be running <i>Windows 10 Pro, Version 20H2 – Gen1</i></li> 
					<li>it should be on MST300-vnet3 subnet1</li>
				</ul>
		</ul>
	<li>Make sure that the peering is configured properly</li>
		<ul>
			<li>vent1 to vnet2</li>
			<li>vnet2 to vnet3</li>
			<li>vnet3 to vnet1</li>
		</ul>
	<li>Boot VMs (via RDP)</li>
	<li>Setup AD Domain</li>
		<ol type="a">
			<li>Install AD</li>
			<ul>
				<li>On dc-vm, in Server Manager (SM)</li>
			</ul>
			<ol type="i">
				<li>click <i>add roles and features</i></li>
				<li>select server that you're currently using on the <i>Server Selection</i> page</li>
				<li>Select <i>Active Directory Domain Services</i> on the <i>Server Roles</i> page</li>
			</ol>
			<li>Promote DC</li>
			<ol type="i">
				<li>On SM homepage select <i>Promote this server into a domain controller</i></li>
				<li>select <i>Create New Forest</i> and enter the domain name</li>
				<li>the next few steps stay default and than click <i>install</i></li>
			</ol>
			<li>add servers</li>
			<li>add client-vm using <i>AD Users and Computers</i></li>
		</ol>
		<li>install IIS on webserver-vm</li>
</ol>

## Project 2
<ol>
	<li class=h3>Create 3 VNETs</li>
		<ol type="a">
			<li> MST300-vnet1 with subnets:</li>
				<ul>
					<li>vnet1-subnet1</li>
					<li>AzureBastionSubnet</li>
				</ul>
			<li>MST300-vnet2 with sublet vnet2-subnet1</li>
		</ol>
	<li class=h3>Assign proper IPs to the VNETs</li>
	<li class=h3>Create VMs</li>
		<ul>
			<li class=h4>Bastion VM</li>
				<ul>
					<li>Name it MST300-BastionHost</li>
					<li>Put it on VNET1s BastionHost subnet with BastionHostIP</li>
				</ul>
			<li class=h4>Webserver VM 1</li>
				<ul>
					<li>call it webserver1-vm</li>
					<li>it should be running <i>Windows Server 2019 Datacenter – Gen1</i> at <i>Standard_B1s</i> tier</li> 
					<li>it should be on MST300-vnet1 subnet1</li>
				</ul>
			<li class=h4>Webserver VM 2</li>
				<ul>
					<li>call it webserver2-vm</li>
					<li>it should be running <i>Windows Server 2019 Datacenter – Gen1</i> at <i>Standard_B1s</i> tier</li> 
					<li>it should be on MST300-vnet1 subnet1</li>
				</ul>
			<li class=h4>Client VM</li>
				<ul>
					<li>call it client-vm</li>
					<li>it should be running <i>Windows 10 Pro, Version 20H2 – Gen1</i></li> 
					<li>it should be on MST300-vnet2 subnet1</li>
				</ul>
			</ul>
	<li>Laod Balancer</li>
		<ol>
			<li>lb vm</li>
				<ul>
					<li>Name: <b>MST300-lb</b></li>
					<li>Type: <b>Internal</b></li>
					<li>Virtual network: <b>MST300-vnet1</b></li>
					<li>Subnet: <b>vnet1-subnet1</b></li>
				</ul>
			<li>Pool: <b>MST300-BackendPool</b></li>
			<li>Health Probe</li>
				<ul>
					<li>Name: <b>MST300-HealthProbe</b></li>
					<li>Protocol: <b>HTTP</b></li>
					<li>Port: <b>80</b></li>
					<li>Interval: <b>15</b></li>
					<li>Unhealthy threshold: <b>3</b></li>
				</ul>
			</ol>
	<li>Setup Peering</li>
	<li>Configure Private DNS Zones</li>
</ol>