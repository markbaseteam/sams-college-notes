<center><h1>Lab 2</h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

![[Pasted image 20220126174427.png]]