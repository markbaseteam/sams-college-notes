<center><h1>Lab 6</h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

![[Lab 6.png]]