<center><h1> Lab 1</h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

![[Pasted image 20220126172755.png]]