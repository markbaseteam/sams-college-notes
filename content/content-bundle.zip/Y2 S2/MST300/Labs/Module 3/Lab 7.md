<center><h1>Lab 7</h1></center>

**Name:** Sam Greenwood
**Student Number:** 102608195

![[Pasted image 20220409201110.png]]

![[RasPi Simulator.png]]