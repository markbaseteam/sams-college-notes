<center><h1>Lab 8</h1></center>

**Name:** Sam Greenwood
**Student Number:** 102608195

**==httptrigger output:==**
![[Pasted image 20220409204441.png]]

**==Portal:==**
![[Pasted image 20220409204722.png]]