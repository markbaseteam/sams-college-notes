<center><h1>Lab 2</h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

## ==**The CapitalOne Hack:**==
Basically, someone on CapitalOne's IT team misconfigured the WAP firewall on one of their AWS instances. That misconfiguration allowed the attacker to start relaying requests to a backend resource on AWS., 

## ==**Part 2**==
|||
| --- | --- | 
|  ==**Question 5**== | ==**Question 6 (Stat Count)**== |
| ![[5 deduped host table.png]] |  ![[6 Stat Count.png]] | 
| ==**Question 7 (Renamed Stat Count)**== |   ==**Question 8 (Metadata)**== |  
| ![[7 Renamed Stat Count.png]]| ![[8 Metadata .png]]  | 
| ==**Question 9 (User List)**== | ==**Question 11 (User List Table)**== | 
![[9 user list.png]] | ![[11 user list.png]] | 
| ==**Question 13 (Users Logged Into Splunk)**== |  ==**Question 14 (CPU Load)**== |
| ![[13 Users Logged into Splunk.png]] | ![[14 CPU Load.png]] | <br>
| ==**Question 16 (pctMEM):**== | ==**Question 17 (RAM Util in Past 15 Minutes)**== |
| ![[16 pctMEM.png]] | ![[17 RAM Util 15 Min.png]] |

## ==**Part 3**==
| Spray Report | Task Category |
| ----------------------- | --- |
| ![[1 Spray Report.png]] | ![[2 Task Category.png]]    |
