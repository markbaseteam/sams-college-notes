<center><h1>Lab 5</h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

**==Part 1 (Live Forensics):==**

|                               |                            |
| ----------------------------- | -------------------------- |
| 1. System Information         | 2. Running Processes       |
| ![[1 Helix SysInfo.png]]      | ![[2 Processes.png]]       |
| 3. Browse                     | 4. Scan for Inages         |
| ![[3 Browse.png]]             | ![[4 Scan for Images.png]] |
| 5. System Info Viewer         | 6. WinAudit                |
| ![[5 System Info Viewer.png]] | ![[6 WinAudit.png]]        |
| 7. PreSearch                  | 8. Drive Manager           |
| ![[7 Pre-Search.png]] | ![[8 Drive Manager.png]] |

**==Part 2 (Memory Capture):==**

![[Memory Capture.png]]