<center><h1>Lab 6</h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

**==Part 1:==**

| ==Odd Questions==           | ==Even Questions==              |
| ----------------------- | --------------------------- |
| **Image Search** |  **pstree**  |
| ![[1 Image Search.png]] | ![[2 pstree.png]]           |
| **connscan**            | **plist**                   |
| ![[3 connscan.png]]     | ![[4 pslist.png]]           |
| **psscan**              | **psxview**                 |
| ![[5 psscan.png]]       | ![[6 psxview.png]]          || ![[7 connections.png]]  | ![[8 profile connscan.png]] |
| **connections** |  **profile connscan**                           |
|![[7 connections.png]]                        |  ![[8 profile connscan.png]]                           |


**==Part 2:==**

| ==Odd Questions== | ==Even Questions== |
| --------------------------- | ------------------- |
| **image info** | **pslist** |
| ![[1 image info.png]]  |   ![[2 pslist.png]] |
| **pstree** | **psxview** |
|   ![[3 pstree.png]]    |  ![[4 psxview.png]] |
| **Connections** | **connscan** |
| ![[5 connections.png]] | ![[6 connscan.png]] |
| **sockets** | |
| ![[7 sockets.png]] | |

**==Part 3:==**

| ==Odd Questions== | ==Even Questions== |
| ----------- | ----------- |
| **Plugin List** | **dllList** |
| ![[1 plugin list.png]] | ![[2 dlllist.png]] |
| getSibs | |
| ![[3 getsids.png]] |  |
