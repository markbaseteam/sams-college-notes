<center><h1>Lab 4</h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

**==Part 1:==**

| Create Image | Exported File |
| --- | --- |
| ![[1 Create Image.png]] | ![[2 Exported File.png]] |

**==Part 2:==**
![[Part 2.png]]

**==Part 3:==**
![[Part 3.png]]

**==Part 4:==**
<p style="text-indent:  40px">The NTUSER.DAT file is where each user’s unique preferences are stored by the system. The said file is run when a user signs in and it copies its contents to the registry. Each user has their own so that they can have unique preferences.</p>

**==Part 5:==**
<p style="text-indent:  40px">Event Viewer is Windows’s built-in system log viewer. It’s split into categories to make it as user-friendly as possible and make it as easy to find what you’re looking for. The following are descriptions of each component:</p><p style="text-indent:  40px">The *System Log* contains events pertaining to the operation of the OS itself. This includes system & hardware changes, device drivers and other related events. This is where events like system crashes and unexpected power loss are recorded.</p>
<p style="text-indent:  40px">The *Security Log* is where security-related events are recorded and audits are stored. What’s logged is determined by the system’s audit policy. This category includes login/logoff and other security-related events</p>
<p style="text-indent:  40px">The *Application Logs* stores records on app-related events. Things like app errors, warnings and crash reports are stored here.</p>