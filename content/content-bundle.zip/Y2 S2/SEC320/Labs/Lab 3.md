<center><h1>Lab 3</h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

## **==Part 1: Create and run a playbook on Phantom==**

| **==Event 1==** | **==Event 2==** |
| -------------------- | ------- |
| **==Event==** | **==IP List==** |
| ![[1 Event.png]] |   ![[1 IP List.png]]     |
| **==Artifacts==** |  **==Artifacts==** |
| ![[2 Artifacts.png]] | ![[2 Artifact.png]] |
| **==DNS==** | **==Playbook==** |
| ![[3 DNS.PNG]] | ![[3 Playbook Ran Successfully.png]] |

## **==Part 2 -Incident response==**

|                                                                                        |                     |
| -------------------------------------------------------------------------------------- | ------------------- |
| **==Question 1:==**                                                                    | **==Question 2:==**   |
| ![[Embeds & Templates/Images/Y2 S2/VM Screenshots/SEC320/Lab 3/Part 2/Question 1.png]] | ![[Question 2.png]] |
| **==Question 3:==**                                                                      | **==Question 4:==**   |
| ![[Question 3.png]] | ![[Question 4.png]] |



