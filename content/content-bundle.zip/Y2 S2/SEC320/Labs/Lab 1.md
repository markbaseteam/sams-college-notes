<center><h1> Lab 1 </h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

==**install Centos VM and agents:**==
![[Pasted image 20220120112919.png]]

==**Install Splunk:**==
![[Controller - CentOS 7.9 (SEC320) - Sam G-Splunk.png]]

==**Splunk Search:**==
![[Controller - CentOS 7.9 (SEC320) - Sam G-Splunk Search.png]]

==**Addon Installed:**==
![[Controller - CentOS 7.9 (SEC320) - Sam G (Addon).png]]