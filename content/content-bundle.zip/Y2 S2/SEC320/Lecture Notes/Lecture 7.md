```toc
```

## Dynamic Malware Analysis


### System Baselining
- snapshot can be used to compare state of the system before and after malware infection 

## Host Integrity Monitoring
- Runtime activities
	- propogation technoiques
	- URLs accessed
### Tools
## Port Monitoring
- TCPView
  Allows you to view TCP/UDP info (gives process path and also has the ability to close connections).
### Registry Monitoring
- Windows Service Manager
  detect changes in system services 
- 