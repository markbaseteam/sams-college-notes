```toc
```

## Intro/Review
Elements of Security
- Confidentiality
- integrity
- Availability

![[Courses/Y2 S1/SEC220/Lecture Notes/Lecture 1#Security Goals]]

## Incident Response

![[Pasted image 20220121150323.png]]

### What's Incident Response
==Incident Response can be defined as responding quickly and effectively when security incidents occur.==
Incident can also be caused by the following reasons:
1. Malicious attacks
2. Non-intentional mistakes
3. Environmental and natural disasters

### Incident Response Lifecycle
- Preparation
	- Insectary Software
	- equipment
	- prevention
	- Risk Assessment
- Detection & Analysis
- Containment, Eradication & Recovery
- Post-Incident Analysis

#### Preparation
- establishing response capabilities
- prevention

#### Detection & Analysis
Different types of incidents merit different response strategies.

What helps in identifying the response strategy:
- Identifying Attack Vectors 
- Signs of an incident
	- A precursor is a sign that an incident may occur in the future.
	- An indicator is a sign that an incident may have occurred or may be occurring now.
## Key Terms
![[Courses/Y2 S2/SEC320/Glossary#^da93d0]]