```toc
```
## Forensic Investigation
- branch of forensic science encompassing the recovery, investigation, examination and analysis of material found in digital devices.
- Sometimes collect evidence for courts
### Roles of Computer Forensics in Incident Response
1. Identify and gather evidence
2. Identify the root cause and the impact of the incident
3. Perform the forensic analysis of the affected system
4. Extract, process and interpret the evidence
5. Protect the organization from similar attacks.
6. Minimize the losses to the organization
7. Save the organization money and time.
### Digital Forensics Process
- [[Courses/Y2 S2/SEC320/Lecture Notes/Lecture 2/Lecture 2#Acquisition|Acquisition]]
- [[Courses/Y2 S2/SEC320/Lecture Notes/Lecture 2/Lecture 2#Inspection|Inspection]]
- [[Courses/Y2 S2/SEC320/Lecture Notes/Lecture 2/Lecture 2#Reporting|Reporting]]
### Investigation Phases
- Initiate the investigation process
- First Response
	The first action after response
- Search and Seizure
- Collect & Secure the Evidence
- Data Acquisition
- Data Analysis
- Documentation and Reporting
- Expert Witness Testimony
## Types of Evidence
![[Types of Evidence#^bfb3fa]]
![[Types of Evidence#^593f40]]

### Types of Digital Evidence
![[Types of Digital Evidence#^36a543]]
![[Types of Digital Evidence#^1a8bfa]]
		![[Types of Digital Evidence#^f8cca9]]
## Volatile Evidence Collection
- These data will be lost when the power is off.
- Volatile data stored in registers, cache and RAM.
- Volatile data includes:
	- Running process
	- Password in cleartext
	- Logging information
	- System information
	- Open ports and listening
	- Registry information
	- Unencrypted data
### Order of Volatility
Order of volatility refers to the order in which you should collect evidence: 
1. Data in cache memory, including the processor cache and hard drive cache
2. Data in RAM, including system and network processes
3. A paging file (sometimes called a swap file) on the system disk drive
4. Data stored on local disk drives
5. Logs stored on remote systems
6. Archive media

### Volatile Data Collection Methodology
- Incident Response Preparation 
- Incident Documentation
- Policy Verification
- Volatile data Collection strategy
- Volatile Data Collection Setup
- Volatile Data Collection process
## Evidence Retention
- most companies have an evidence retention policy

### Factors to be Considered
- Will the attacker be prosecuted 
- Time
	
- Cost
	
------
- disks should be wiped and sanitized before reuse or disposal
- 