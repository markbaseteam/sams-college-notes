   

## Incident Response Preparation

## Incident Documentation


## Policy Verification
- read policies and make sure they were signed by the user of that computer
- 
## Volatile data Collection strategy
- having a strategy
- a secure shell is a must (don't use the infected computer)
- don't restart or shut down the computer
## Volatile Data Collection Setup

## Volatile Data Collection process