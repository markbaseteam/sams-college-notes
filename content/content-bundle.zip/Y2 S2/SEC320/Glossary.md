   

## Lecture 1
| Term | Definition |
| --- | --- |
| Cybersecurity incident | A computer security incident is a violation or imminent threat of violation of computer security policies, acceptable use policies, or standard security practices. | 
| Incident Response | Incident Response can be defined as responding quickly and effectively when security incidents occur. | 

^da93d0

Lecture 