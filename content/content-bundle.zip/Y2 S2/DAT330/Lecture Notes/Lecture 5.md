```toc
```
## Azure Active Directory 
### Difference Between Active Directory and Azure Active Directory
- Azure Active Directory uses HTTPS protocols like SAML and OpenID Connect for authentication and uses OAuth for authorization.
- you cannot join a Windows Server to an Azure Active Directory domain
- A service called Azure Active Directory Connect connects your Active Directory identities with your Azure Active Directory.
## Auth & Identity
- Two types of authentication 
	- SQL Server authentication
	- Windows Authentication 
- AD auth is more secure SQL auth creds are sent in plain text
- don't use sa account
```ad-info
The roles can be defined when the application is designed, and then users can be assigned to those roles as they need access to the database.
```
### Server Roles
| Role | Description |
| ---- | ----------- |
| Sysadmin | Members of the sysadmin role can perform any activity on the server. | 
| Serveradmin | Members of the serveradmin role can change server-wide configuration settings (for example Max Server Memory) and can shutdown the server. | 
| Securityadmin | Members of the securityadmin role can manage logins and their properties (for example, changing the password of a login). The members can also grant and revoke server and database level permissions. This role should be treated as being equivalent to the sysadmin role. |
| Processadmin | Members of the processadmin role can kill processes running inside of SQL Server. | 
| Setupadmin | Members of the setupadmin role can add and remove linked servers using T-SQL. |
| Bulkadmin | Members of the bulkadmin role can run the BULK INSERT T-SQL statement. | 
| Diskadmin | Members of the diskadmin role have the ability to manage backup devices in SQL Server. | 
| Dbcreator | Members of the dbcreator role have the ability to create, restore, alter, and drop any database. | 
| Public | Every SQL Server login belongs to the public user role. Unlike the other fixed server roles, permissions can be granted, denied, or revoked |

### Permissions
#### Tables & Views

| Permission | Description |
| -------------------------------------------------------------------------------------------------------- | ---- |
| CONTROL | Confers ownership-like capabilities on the grantee. The grantee effectively has all defined permissions on the securable. A principal that has been granted CONTROL can also grant permissions on the securable. Because the SQL Server security model is hierarchical, CONTROL at a particular scope implicitly includes CONTROL on all the securables under that scope. For example, CONTROL on a database implies all permissions on the database, all permissions on all assemblies in the database, all permissions on all schemas in the database, and all permissions on objects within all schemas within the database. |
| ALTER | Confers the ability to change the properties, except ownership, of a particular securable. When granted on a scope, ALTER also bestows the ability to alter, create, or drop any securable that is contained within that scope. For example, ALTER permission on a schema includes the ability to create, alter, and drop objects from the schema. |
| ALTER ANY <Server Securable>, where Server Securable can be any server securable. | Confers the ability to create, alter, or drop individual instances of the _Server Securable_. For example, ALTER ANY LOGIN confers the ability to create, alter, or drop any login in the instance. |
| ALTER ANY <_Database Securable_>, where _Database Securable_ can be any securable at the database level. | Confers the ability to CREATE, ALTER, or DROP individual instances of the _Database Securable_. For example, ALTER ANY SCHEMA confers the ability to create, alter, or drop any schema in the database. |
| TAKE OWNERSHIP | allows the user the ability to take ownership of the object. |
| VIEW CHANGE TRACKING | allows the user to view the change tracking setting for theobject. | 
| VIEW DEFINITION | allows the user to view the definition of the object. | 

#### Functions & Procedures
| Permission | Description |
| ---------- | ------------------------------------------------------------------- | 
| ALTER |  grants the user the ability to change the definition of the object. | 
| CONTROL | grants the user all rights to the object. | 
| EXECUTE | grants the user the ability to execute the object. This permission can be granted to Azure SQL Database for MySQL and Azure SQL Database for PostgreSQL. | 
| VIEW CHANGE TRACKING | allows the user to view the change tracking setting for the object. | 
| VIEW DEFINITION | allows the user to view the definition of the object. |  