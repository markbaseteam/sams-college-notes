```toc
```
## Performance Monitoring
 ```ad-info
title: Baseline
It is a collection of data measurements that helps you understand the normal “steady state” of your application or server’s performance.
```
- Azure allows you to create a baseline to compare resource usage against 
```ad-info
title: Metrics
All Azure resources collect a set of metrics which are collected through the Azure Monitor service - Data is stored in Azure Log Analytics
```
### Metric Descriptions
| Metric  | Descriptions |
| ------ | ------------ |
| Processor(_Total)% Processor Time | This counter measures the CPU utilization of all of the processors on the server. It is a good indication of the overall workload, and when used in conjunction with other counters, can identity problems with query performance. | 
| Paging File(_Total)% Usage | Memory should not page to the paging file on disk. However, in some configurations you may have other services running that consume system memory and lead to the operating system paging memory to disk resulting in performance degradation. |
| PhysicalDisk(_Total)\Avg. Disk sec/Read and Avg. Disk sec/Write | This is a good metric for how the storage subsystem is working. Your latency values in most cases should not be above 20ms, and with Premium Storage you should see values less than 10ms. |
| System\Processor Queue Length | This number indicates the number of threads that are waiting for the time on the processor. If it is greater than zero, it indicates CPU pressure, indicating your workload could benefit from more CPUs. |
| SQLServer: Buffer Manager\Page life expectancy | Page life expectancy indicates how long SQL Server expects a page to live in memory. There is no proper value for this setting. Older documentation refers to 300 seconds as proper, but that was written in a 32-bit era when servers had far less RAM. |
| SQLServer: SQL Statistics\Batch Requests/sec | This counter is good for evaluating how consistently busy a SQL Server is over time. Once again there is no good or bad value, but you can use this in conjunction with % Processor time to better understand your workload and baselines. | 
| SQLServer: SQL Statistics\SQL Compilations/sec and SQL Re-Compilations/sec | These counters will be updated when SQL Server has to compile or recompile an execution plan for a query because there is no existing plan in the plan cache, or because a plan was invalidated because of a change. | 
## Query Store
```ad-info
title: What's the Query Store?
It's like the server's flight data recorder
```
## Blocking & Locking
![[Pasted image 20220312163431.png]]

## Isolation
### Isolation Levels
| Level Name | Description |
| ---------- | ----------- |
| Read uncommitted | This is the lowest isolation level available. Dirty reads are allowed, which means one transaction may see changes made by another transaction that have not yet been committed. | 
| Read committed | This level allows a transaction to read data previously read, but not modified by another transaction with without waiting for the first transaction to finish. This level also releases read locks as soon as the select operation is performed. This is the default SQL Server level. |
| Repeatable Read | This level keeps read and write locks that are acquired on selected data until the end of the transaction. | 
| Serializable | This is the highest level of isolation where transactions are completely isolated. Read and write locks are acquired on selected data and not released until the end of the transaction. |

### Isolation Levels That Include Row-versioning
| Level Name | Description |
| ---------- | ----------- |
| Read Committed Snapshot | In this level read operations take no row or page logs, and the engine presents each operation with a transactionally consistent snapshot of the data as it existed at the start of the query. | 
| Snapshot | This level provides transaction level read consistency through row versioning. This level is vulnerable to update conflicts. |