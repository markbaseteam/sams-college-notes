```toc
```
%%
# Week 4
%%

^cd320d

^bpl27j
- VMs - IaaS
- Managed Instance - PaaS
- Azure SQL - SaaS
## IaaS
- IaaS, has the highest level of control compared to the other Azure SQL offerings
- you are also responsible for software configuration with an IaaS deployment.
- Microsoft will manage any resource below the operating system, including the physical servers, storage and physical networking but not the SQL Server instance running on the operating system. 
- Azure offerings may not work with some of your applications such as Azure SQL Database, because they require specific operating conditions

### SQL Server Licensing Models
- If you aren’t participating in the Microsoft Software Assurance (SA) program, then you can deploy:
	- An image from the Azure Marketplace containing a preconfigured SQL Server and pay-per-minute for the use of SQL Server which knows as the Pay as you Go, model. cost of the SQL Server license is included with the cost of the virtual machine.
- If you are participating in the Microsoft Software Assurance (SA) program, then you can:
	- use the previous method and pay-per-minute by deploying a virtual machine image containing a SQL Server from the Azure Marketplace.
	- You can Bring Your Own License (BYOL) when deploying the virtual machine that doesn’t contain a preconfigured SQL Server instance.

### Virtual Machine Families
Groups of VMs based on their specs

| Series | Description |
| ------ | ----------- |
| General purpose | These VMs provide a balanced ratio of CPU to memory. | 
| Compute optimized | Compute optimized VMs have a high CPU-to-memory ratio | 
| Storage optimized | Storage optimized VMs provide fast, local, NVMe storage that is ephemeral. | 
| GPU | Azure VMs with GPUs are targeted towards natural graphics processing operations and massively parallel machine learning workloads. | 
| High performance compute | High Performance Compute workloads support applications that can scale horizontally to thousands of CPU cores. | 

### Availability Zones
![[Courses/Y2 S2/MST300/Lecture Notes/Lecture 2#Availability Zones]]

### Disk Types

| Type | Description |
| ---- | ----------- |
| Standard HDD | the original storage offering on Azure and offer cost-effective storage for non I/O intensive workloads. A common use case for standard disks are for SQL Server backups. | 
| Standard SSD | solid state drive and will have similar latency and IOPS to the standard HDD drives at sizes up to 4 TB; however, this type offers significant performance gains at larger volumes. Standard SSDs do offer guaranteed performance levels where the Standard HDD disks do not. | 
| Premium SSD | the most commonly used type of disk for SQL Server workloads. They are available in all regions and support a wide variety of VM types. Premium disks strike a good balance between price and performance. | 
| Ultra SSD | provides the lowest latency (sub-millisecond) and the highest potential IOPs. Ultra SSD allows you to configure IOPs, storage volume, and bandwidth independently for more granular cost control. | 

## PaaS
![[PaaS#^357ab4]]

### Open Source Offerings
![[Azure Open Source.png.annotations#^0151b3]]

## Service Tiers
| Tier | Description |
|  --- |  --- |
| Basic|This tier is best for light workloads that need minimal compute and I/O performance. | 
| General Purpose|This tier is great for most workloads requiring scalable I/O throughput along with a healthy balance of compute and memory. | 
| Memory Optimized|This tier is suitable for workloads that demand high performance and require in-memory speed for quick processing of transactions along with higher concurrency.  | 

 ^week5
## Advantages of PaaS
- automatic patching
- Automatic backups

## Open Source Offerings (2) 
![[open-source offerings pt2#Open-source offerings]]

## Single server deployment model services
- High availability
- Automated patching
- Automatic backups
- Adjust performance and scale within seconds
- Enterprise grade security, compliance, and governance
- Monitoring and alerting
- Migration

## Single Server Service Tiers
| Tier | Description |
| ---- | ----------- |
| Basic | Workloads that require light compute and I/O performance. Examples include servers used for development or testing or small-scale infrequently used applications. |
| General Purpose | Most business workloads that require balanced compute and memory with scalable I/O throughput. Examples include servers for hosting web and mobile apps and other enterprise applications. |
| Memory Optimized | High-performance database workloads that require in-memory performance for faster transaction processing and higher concurrency. Examples include servers for processing real-time data and high-performance transactional or analytical apps. |
