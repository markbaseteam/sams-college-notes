```toc 
style: bullet | number (default: bullet)
min_depth: number (default: 2)
max_depth: number (default: 6)
```

![[What Is a Database#What Is a Database]]

## Types of Databases

| Open-Source DBMS | Proprietary RDBMS |
| --- | --- |
| MySQL, MariaDB | Oracle Database | 
| PostgreSQL | Microsoft SQL |
| | IBM DB2 | 

### SQL 
#### Versions

| SQL Server edition | Definition |
| --- | --- |
| Enterprise | The premium offering, SQL Server Enterprise edition delivers comprehensive high-end datacenter capabilities with blazing-fast performance, unlimited virtualization[^1], and end-to-end business intelligence - enabling high service levels for mission-critical workloads and end-user access to data insights. | 
| Standard | SQL Server Standard edition delivers basic data management and business intelligence database for departments and small organizations to run their applications and supports common development tools for on-premises and cloud - enabling effective database management with minimal IT resources. | 
| Web | SQL Server Web edition is a low total-cost-of-ownership option for Web hosters and Web VAPs to provide scalability, affordability, and manageability capabilities for small to large-scale Web properties. | 
| Developer | SQL Server Developer edition lets developers build any kind of application on top of SQL Server. It includes all the functionality of Enterprise edition, but is licensed for use as a development and test system, not as a production server. SQL Server Developer is an ideal choice for people who build and test applications. | 
| Express editions | Express edition is the entry-level, free database and is ideal for learning and building desktop and small server data-driven applications. It is the best choice for independent software vendors, developers, and hobbyists building client applications. If you need more advanced database features, SQL Server Express can be seamlessly upgraded to other higher end versions of SQL Server. SQL Server Express LocalDB is a lightweight version of Express that has all of its programmability features, runs in user mode and has a fast, zero-configuration installation and a short list of prerequisites. |

[^1]: Unlimited virtualization is available on Enterprise Edition for customers with Software Assurance. Deployments must comply with the licensing guide. For more information, see our pricing and licensing page.

### Database Objects
![[Database Objects#^5749cd]]
