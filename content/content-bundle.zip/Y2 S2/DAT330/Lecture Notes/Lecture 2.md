# Lecture 2: Database Objects

```toc
```
# Week 2
## Database Tables
- database objects that contain data
- Data is logically organized in tables in a row-and-column format similar to a spreadsheet.
- Each row represents a unique record, and each column represents a field in the record.

### Constraints
- Predefined rules applied to a column

#### Types of constraints
| Constraint | Description |
| --- | --- |
| PRIMARY KEY | unique and not null & table created based on it |
| NOT NULL | | 
| UNIQUE | | 
| CHECK | | 
| FOREIGN KEY | requires the use of a key that already exists | 

### Statements
| Statement | Description | 
| --- | --- |
| INSERT INTO | used to insert values in a table | 
| UPDATE | used to modify the existing records in a table | 
| DELETE | used to delete existing records in a table |
| `:` | concatenates tables |

-----

## Joining Tables
- Allows retrieval of contents of two or more tables.

### Types of joins

| Type | Description | Syntax |
| --- | --- | --- |
| Inner Join | | - `SELECT <select list>` <br> - `FROM <table1>` <br> - `[INNER] JOIN <table2> ON <table1>.<col1> = <table2>.<col2>` | 
| Left Outer Join |  | - `SELECT <SELECT list>` <br>- `FROM <table1>` <br> - `LEFT [OUTER] JOIN <table2> ON <table1>.<col1> = <table2>.<col2>`  | 
| Right Outer Join | RIGHT OUTER JOIN is similar to LEFT OUTER JOIN but it differ in the location of the tables. | - `FROM <table1>` <br> - `LEFT [OUTER]JOIN <table2> ON <table1>.<col1> = <table2>.<col2>` <br> - `LEFT [OUER] JOIN <table3> ON <table2>.<col3> = <table3>.<col4>` | 
| Full Outer Join | FULL OUTER JOIN is similar to LEFT OUTER JOIN and RIGHT OUTER JOIN, but it will reutrn all the rows from each side of the join | - `SELECT <column list>` <br> - `FROM <table1>` <BR> - `FULL [OUTER] JOIN <table2> ON <table1>.<col1> = <table2>.<col2>`

# Week 3
## Views
- Read-Only
- Advantages
	- Security
	- selection of particular columns
- disadvantages
	- 
### Syntax
| Function | Example Code | 
| --- | --- |
| Create View | `CREATE VIEW <view name> AS SELECT <col1>, <col2> FROM <table>` <br> `ALTER VIEW <view name> AS SELECT <col1>, <col2> FROM <table>` <br> `DROP VIEW <view name>` | 
## Functions
- Similar to functions in other programming languages

`CREATE OR ALTER FUNCTION <scalar function Name> (<@param1> <data type1>, <@param2> <data type2>)
RETURNS <data type> AS
BEGIN <statements>
RETURN <value>
END
DROP FUNCTION <scalar function name>`

## Stored Procedures

## Triggers
- am event caused by something happening