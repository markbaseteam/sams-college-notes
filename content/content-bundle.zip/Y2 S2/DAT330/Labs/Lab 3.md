<center><h1>Lab 3</h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

**==Resource Group:==**
![[Resource Group.png]]

**==VM Page:==**
![[VM Page.png]]

**==VM Overview:==**
![[Details page.png]]