<center><h1>DAT330 Lab 1</h1></center>
**Name:** Sam Greenwood
**Student Number:** 102608195

==**Access to your SQL Server:**==

==**Access Database:**==
![[Access Server.jpg]]

==**Query 1:**==
![[Query 1.jpg]]

==**Query 2:**==
![[Query 2.jpg]]


