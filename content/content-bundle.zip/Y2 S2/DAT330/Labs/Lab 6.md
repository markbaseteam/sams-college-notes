<center><h1>Lab 6</h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

**==Exercise 1:==**

| Task 1 | Task 2 |
| --- | --- |
| ![[Task 1.png]]    |  ![[Task 2.png]]   |

**==Exercise 2:==**

| Task 1                                                                                 | Task 2.1    | Task 2.2 |
| -------------------------------------------------------------------------------------- | --- | --- |
| ![[Embeds & Templates/Images/Y2 S2/VM Screenshots/DAT330/Lab 6/Exercise 2/Task 1.png]] | ![[Task 2.1.png]]    | ![[Task 2.2.png]] |
