<center><h1>Lab 2</h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

==**Task 2:**==

| Table Creation | Display Table |
| -------------- | ------------- |
| ![[Table Creation.png]] | ![[Task 2 Done.png]] |

==**Task 3:**==
![[Task 3.png]]

==**Task 4:**==
![[Task 4.png]]

==**Task 5:**==
![[Task 5.png]]

==**Task 6:**==
I couldn't get the update statement to work even though I used the correct syntax.

==**Task 7:**==
![[Task 7.png]]

==**Task 9:**==
![[Task 9.png]]