<center><h1>Lab 4</h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

**==Overview Page:==**

![[Screenshot 2022-02-20 111953.png]]

**==DB &Table Creation:==**

![[Question 2.5.png]]

**==Addition of Data & SELECT Statement:==**

![[Question 2.7.png]]

**==Deletion:==**

![[Question 3.3.png]]
