<center><h1>Lab 8</h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

**==Exercise 2:==**
![[Pasted image 20220418125048.png]]

**==Exercise 3:==**
![[screencapture-portal-azure-2022-04-18-12_59_41.png]]