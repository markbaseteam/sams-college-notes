<center><h1> Assignment 2</h1></center>

**Name:** Sam Greenwood
**Student Number:** 102608195

## tables created
![[created tables.png]]

## data added to tables
![[selected tables.png]]

## counts
![[counts.png]]

## Create View
![[Pasted image 20220325175529.png]]