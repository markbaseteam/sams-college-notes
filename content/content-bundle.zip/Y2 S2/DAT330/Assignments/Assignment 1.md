<center><h1> Assignment 1</h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

==**Create Table:**==
![[Question 1.png]]

==**Insert Data:**==
![[interts.png]]

==**Create View:**==
![[table.png]]

==**Procedure:**==

| Procedure Code | Run Procedure |
| --- | --- |
| ![[Procedure.png]] | ![[Run Procedure.png]] |  