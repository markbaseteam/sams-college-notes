<center><h1>Assignment 3</h1></center>

**Name:** Sam Greenwood
**Student Number:** 102608195

**==create view:==**
![[1 view created.png]]

**==Query Store:==**

| Top Resource Consuming Queries | Query Wait Statistics |
| ------------------------------ | --------------------- |
| ![[2 top resource.png]] | ![[2 wait stats.png]] |

**==Nonclustered Index:==**
![[3 created index.png]]

**==Join:==**
![[4 join.png]]

**==Execution Plan:==**
![[5 execution plan.png]]