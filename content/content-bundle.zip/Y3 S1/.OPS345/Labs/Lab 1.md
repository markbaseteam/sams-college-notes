<center><h1>Lab 1</h1></center>

**Name:** Sam Greenwood
**Student Number:** 102608195

**==Security Group:==**
![[Embeds & Templates/Images/Y3 S1/Other Screenchots/OPS345/Lab 1/Security Group.png]]

**==User Config:==**
![[Embeds & Templates/Images/Y3 S1/Other Screenchots/OPS345/Lab 1/AWS User Config.png]]

**==Hostname Changed:==**
![[Hostname Changed.png]]