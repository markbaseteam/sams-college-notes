<center><h1>Lab 3</h1></center>

**Name:** Sam Greenwood
**Student Number:** 102608195

**==AWS Console:==**
![[www instance.png]]

**==Web Page:==**
![[Webpage.png]]

**==EBS:==**
![[EBS.png]]
