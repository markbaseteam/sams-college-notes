<center><h1>Lab 2</h1></center>

**Name:** Sam Greenwood
**Student Number:** 102608195

**==Create VPC:==**
![[Create VPC.png]]

**==Subnet:==**
![[Create Subnet.png]]

**==Create Internet Gateway:==**
![[Create Internet Gateway.png]]

**==Routing Table:==**
![[Create Routing Table.png]]

**==Hostname Changed:==**
![[Embeds & Templates/Images/Y3 S1/VM Screenshots/OPS345/Hostname Changed.png]]

**==Elastic IP:==**
![[Elastic IPs.PNG]]

**==iptables:==**
![[Embeds & Templates/Images/Y3 S1/VM Screenshots/OPS345/iptables.png]]

**==Logged into ww VM:==**
![[Embeds & Templates/Images/Y3 S1/VM Screenshots/OPS345/Lab 2/logged into ww VM.png]]