- a Security Groups Like a Firewall as a Service
- ssh keys are more secure than username as pw

Benefits of sudo
- everything is logged
- configurable