## Virtual Private Cloud (VPC)
- Servers aren't specifically located on prem
- resources are specifically alocated to you and secregated but aren't deditated to you 100%of the time
- virtual private cloud in a private cloud

## Internet Gateways
- works similarly to port forwarding on home routers

> [!NOTE] Elastic IPs
> free when used but cost money when not being used 

## iptables
- relys on Input and Output chain
- Prerouting chain
  applies to packets that have been recieved before any routing decisions have been made
- Postrouting chain
  applies to packets leaving the machine

