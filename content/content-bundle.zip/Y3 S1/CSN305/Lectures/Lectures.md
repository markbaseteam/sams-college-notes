```ccard
items: [
  {
    title: 'Lecture 1: Virtualiation',
    link: 'Courses/Y3 S1/CSN305/Lectures/Lecture 1.md',
    brief: 'The topic of this lecture was Virtualiation.',
    foot: '9/15/2022, 1:32:25 PM',
    head: 'Note'
  },
  {
    title: 'Lecture 2: The Cloud',
    link: 'Courses/Y3 S1/CSN305/Lectures/Lecture 2.md',
    brief: 'Benefits of Virtualizing the Data Center, Types of Clouds and Cloud Deployment Models',
    foot: '9/29/2022, 11:02:12 PM',
    head: 'Note'
  },
  {
    title: 'Lecture 3: Network Virtualization',
    link: 'Courses/Y3 S1/CSN305/Lectures/Lecture 3.md',
    brief: 'Intro to Network Virtualization',
    foot: '9/26/2022, 5:25:39 PM',
    head: 'Note'
  },
  {
    title: 'Lecture 4: Software Defined Networking',
    link: 'Courses/Y3 S1/CSN305/Lectures/Lecture 4.md',
    brief: 'Intro to SDN',
    foot: '9/29/2022, 6:00:24 PM',
    head: 'Note'
  },
  {
	title: 'Lecture 5: OpenFlow',
	link: 'Courses/Y3 S1/CSN305/Lectures/Lecture 5.md',
	brief: 'Intro to OpenFlow',
	foot: '11/18/2022, 11:35:41 AM',
	head: 'Note'
  },
  {
    title: 'Lecture 6: SDN Application Plane',
    link: 'Courses/Y3 S1/CSN305/Lectures/Lecture 6/Lecture 6.md',
    foot: 'SDN Application Plane',
    head: 'Note'
  },
  {
    title: 'Lecture 7',
    link: 'Courses/Y3 S1/CSN305/Lectures/Lecture 7.md',
    brief: 'SDN Application Layer and Use Cases',
	head: 'Note'
  },
  {
    title: 'Lecture 8',
    link: 'Courses/Y3 S1/CSN305/Lectures/Lecture 8.md',
    brief: 'SDN traffic analysis',
    note: 'Note'
  },
  {
    title: 'Lecture 9',
    link: 'Courses/Y3 S1/CSN305/Lectures/Lecture 9.md',
    brief: 'Network Visibility & QoE',
    head: 'Note'
  },
  {
    title: 'Lecture 10',
    link: 'Courses/Y3 S1/CSN305/Lectures/Lecture 10.md',
    brief: 'How SDN and NFV will affect you',
    head: 'Note'
  },
  {
    title: 'Lecture 11: SDN Security',
    link: 'Courses/Y3 S1/CSN305/Lectures/Lecture 11.md',
    head: 'Note'
  }
]
```