|     |     |
| --- | --- |
| overlay network    | virtual network     |
| underlay | physical network |


> [!NOTE] Software-Defined Networks
> the ability to program the network. SDN is a newer technology, one that was born as a result of virtualization and the shift of where the “chokepoint” is in data communications.

> [!NOTE] firewalls
> Firewalls allow traffic from authorized users but block others. Firewalls can be located at the edge of the data center but can also be located close to the server.

> [!NOTE] VPNs
> VPNs logically segment/isolate user traffic within the network (over the WAN). This allows many users to privately share a common infrastructure without mixing traffic.

> [!NOTE] Secure Sockets Layer (SSL)
> SSL is a web-based encryption tool. SSL has become very popular because it provides security of web-based data streams without user intervention. The SSL offload service provides a termination point for encryption.

> [!NOTE] Load balancers
> Load balancers direct and spread user traffic coming into the data center or cloud. Load balancing is a way to control the flow of traffic as applications scale up and down.
