```toc
```
## Secure Enterprise SDN
- SES delivers three compelling benefits:
	- Easy user onboarding
	- Easy endpoint security
	- Easy traffic monitoring

### SES user onboarding
- As a user enters the business, their details are entered into a cloud-based HR database:
	- Location
	- Department
	- Device address(es)
	- Work schedule
- The SDN controller can apply business rules—for example departmental access permissions, degree of mobility, expected hours of access, and so on—to the user information, in order to derive access rules to apply to the edge switches and Wi-Fi APs.

## MEF – SD WAN ServiceComponents
1. SD-WAN UNI (User-Network Interface)
2. SD-WAN Virtual Connection (SWVC) and End Points
3. SD-WAN Underlay Connectivity Service (UCS)
4. Tunnel Virtual Connection (TVC)
5. SD-WAN Edge
6. SD-WAN Application Flows and Policies
![[Pasted image 20221114105332.png]]

## SD-LAN
- SD-LAN builds on the principles of SDN in the data center and SD-WAN to bring specific benefits of adaptability, flexibility, cost-effectiveness, and scale to wired and wireless access networks.
- SD-LAN is an application- and policy-driven architecture that unchains hardware and software layers while creating self-organizing and centrally-managed networks that are simpler to operate, integrate, and scale.
![[Pasted image 20221114105545.png]]

