<center><h1>Lecture 11</h1></center>
<% @today %>

<% [TOC] %>

## Where’s My Data, Exactly?

## 3 Tenet of Data Security
![[Pasted image 20221208150906.png]]

## Minimizing Data Loss
There are two key steps in minimizing data loss:
- Apply the risk formula for data loss
  Risk = Impact × Rate of occurrence
- Apply the 80:20 rule of data loss to identify where you are likely to experience a high impact data breach.
  80% of the record and files compromised by the 20% of breach vectors
[[Courses/Y3 S1/CSN305/Lectures/Lecture 11#^df5913|Jump to Types of DLP]]
## Types of Data
- Data in motion (traveling across the network)
- Data in use (being used at the endpoint)
- Data at rest (sitting idle in storage)
> [!note] Described:
> Out-of-box classifiers and policy templates, which help identify types of data. This is helpful when looking for content such as personal identifiable information.

> [!note] Registered
> Data is registered to create a “fingerprint,” which allows full or partial matching of specific information such as intellectual property.^your-id`
^your-id
### Types of Data Loss Prevention (DLP)

> [!note] Full suite DLP
> covers the complete spectrum of leakage vectors, from data moving through the network (data in motion), data at the computer or endpoint (data in use), to data stored on the server drives or in a storage-area network (SAN) (data at rest).

> [!note] Channel data loss prevention
> Channel DLP is typically designed for some other function but was modified to provide visibility and DLP functionality. Like: email security, web gateways, and device control.

## Auditing
![[Courses/Y2 S1/SEC220/Lecture Notes/Lecture 2#Auditing]]

## Encryption in Virtual Networks
|     |     |
| --- | --- |
| ![[Pasted image 20221208153506.png]]    |  ![[Pasted image 20221208153533.png]]   |