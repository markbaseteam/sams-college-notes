```toc
title: Table of Contents
```
- Software defined networks are more efficiant

## Traditional Networks
- closed proprietary systems
- Vendor-Locked in
- data and communications networks are complex and difficult to manage

![[Pasted image 20220929172050.png]]

-----
- data plane controlled by the control plane

##  Software Defined Networks
- Direct programmability
- Standard OPEN Hardware, controller, Apps
- Agile implementation
- Centralized management

![[Pasted image 20220929172147.png]]

----
- controller manages networks instead of the router
- simillar to VMs and hypervisors

In this case, the applications and the intelligence are removed from the switch/router. A centralized controller becomes the control plane for all devices, which makes the network programmable. Applications interface with the controller, and their functions are applied across the network.


> [!definition] Software-Defined Networking
> The physical separation of the network control plane from the forwarding plane, and where a control plane controls several devices

## SDN Layers

> [!NOTE] The application layer
> This layer handles the business applications and helps accelerate new features and service introduction by decoupling applications from vendor platforms.

> [!NOTE] The control layer
> The centralization of intelligence simplifies provisioning, optimizes performance, and enables greater control, granularity, and simplification of policy management across all network devices.

> [!NOTE] The infrastructure layer
> It is at this layer that hardware is decoupled from software and the control plane is decoupled from the data (forwarding) plane. Decoupling these planes facilitates logical configuration through software on a central controller rather than physical configuration of each device.

## OpenFlow
works by interfacing with the device’s flow table and assigning flows with an action. The action tells the router or switch how to handle the data flow. By specifying through OpenFlow which data flows are handled and how, there is no need to physically connect to and configure each individual router and switch in the network. This not only improves efficiency, but it also greatly reduces complexity and configuration errors.

## The Logic Planes

> [!NOTE] ### Control Plane 
> where the intelligence of the device lies. It is here where all the instructions (in the form of applications and large tables of rules) are stored.

> [!NOTE] ### Forwarding Plane
> where packets are moved from one network interface on the machine to one of the many other network interfaces on the machine. You can think of the control plane as the brain and the forwarding plane as the muscle.

