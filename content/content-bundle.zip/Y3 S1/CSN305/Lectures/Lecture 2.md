![[Cloud Infographic.png]]

## Benefits of Virtualizing the Data Center
- Less Heat BuildupReduced
- Reduced Hardware Spend
- Faster Deployment
- Testing and Development
- Faster Redeploy
- EasierBackups Backups
- Disaster Recovery
- Server Standardization
- Separation of Services
- Easier Migration to the Cloud

## Cloud Attributes


## Types of Clouds

| Type of Cloud | Description |
| ------------- | ----------- |
| Software as a service (SaaS) | The provider offers an application that clients connect to over the network. |
| Infrastructure as a service (IaaS) | The provider offers processing, storage, and other computing resources in a manner that has the attributes listed earlier. | 
| Platform as a service (PaaS) | The provider offers the ability to run applications that they have created themselves. |

![[Types of Clouds.png]]

## Cloud Deployment Models
| Cloud Deployment Model | Description                                                                                                                                                                                                                                                                                                                                         |
| ---------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Private Clouds         | The first step that most enterprises take toward cloud adoption is the virtualization of their existing data centers. A private cloud is created when an enterprise data center is reconfigured in such a way as to provide the five attributes                                                                                                     |
| Public Clouds          | It’s open to anyone and everyone who has connectivity and a credit card (or some remote method of payment).                                                                                                                                                                                                                                         |
| Community Clouds       | a community or multitenant cloud is run by a service provider that hosts services for a select group of customers, almost always businesses (as opposed to  individuals). The various tenants are likely sharing common resources, but the service is not public in the sense that just anyone can access these cloud resources any time they want. |
| Hybrid Clouds          | some providers offer administrative control over multiple cloud platforms (private or public) that can be managed through a single interface. This allows seamless access to both cloud environments.                                                                                                                                               |

