<center><h1>Lecture 8</h1></center>
Date. 2022-11-30

<% [TOC] %>

## Review
### OpenFlow Channels
- always runs on a secure connection 

## OpenFlow Messages

### Types

> [!note] Controller-to-switch
>Messages that are initiated by the controller and used to configure the switch or its query status

> [!note] Asynchronous
> Messages that are initiated by the switch and used to notify the controller about network events or changes to the switch state

> [!note] Symmetric
>Messages that are initiated by either the switch or the controller and sent without solicitation

### Headers
- the same every time
- equivilant to a class in programming

Every message includes an internal header instance that encapsulates:
- The protocol version
- The message type
- The message length (in bytes)
- The transaction ID (XID)

![[Pasted image 20221130135109.png]]
\- OpenFlow message types by ID

----
- Each switch has its own OpenFlow channel to negotiate with controller, also there can be multiple OpenFlow channels on a switch to connect to multiple controller for redundancy
- The OpenFlow controller can use a multipart request message to request the following information:
	•Switch, group, or port descriptions
	•Single-flow, aggregate-flow, flow table, port, or group statistics
	•Group or table features

> [!note] Multipart messages
> are used to encode request or replies that potentially carry a large amount of data that would not always fit into a single OpenFlow message which is limited to 64KB.
> - Request or reply is encoded as a sequence of multipart messages with a specific multipart type which is reassembled by the receiver.
> - Multipart messages are primarily used to request statistics or state information from a switch.

