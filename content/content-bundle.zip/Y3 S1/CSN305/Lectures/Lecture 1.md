## Server Proliferation
- systems have multiple cores so they can do multiple tasks simaltainusly
---
- using VMs instaead of seperate servers would be cheaper and more economical to maintain
- hypervisor is what hosts VMs and allow/controls interactions between the hardware and the VMs.
	- Hypervisors allow vertically and horizontally

## Tyoes of Hypervisors 
| bare-metal hypervisors | these run directly on the host computer’s hardware to control the hardware resources and to manage guest operating systems. Examples of Type 1 hypervisors include VMware ESXi, Citrix XenServer and Microsoft Hyper-V hypervisor. |
| ---------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| hosted hypervisors     | these run within a formal operating system environment. In this type, the hypervisor runs as a distinct second layer while the operating system runs as a third layer above the hardware.                                          |

