```toc
```
## Consolidation of SDN Architecture
![[Courses/Y3 S1/CSN305/Lectures/Lecture 5#^bf2c10]]

![[Courses/Y3 S1/CSN305/Lectures/Lecture 5#^0c9a49]]

![[Courses/Y3 S1/CSN305/Lectures/Lecture 5#^cb6efb]]

## Open Flow Tables
### Types of Tables
| Type | Description |
| ---- | ----------- |
| Flow Table | matches incoming packets to a particular flow, and specifies what particular  functions are to be performed on the packets. Multiple flow tables can operate simultaneously.  |
| Group Table | may receive flow from a flow table, and affects one or multiple flows. |
| Meter Table | can trigger a variety of performance-related actions on a flow. |

> [!NOTE] What is a flow?
> It is a sequence of packets traversing the network that share a set of header field values. Example: all the packets with the same source and destination IP addresses, or all packets with the same VLAN ID.

### Flow Table Structure
![[Pasted image 20221106161353.png]]
 #### Example
| Fields       | Content                                                         |
| ------------ | --------------------------------------------------------------- |
| Match fields | ports, MAC addresses, IP addresses, and port numbers.           |
| Priority     | <p>2<sup>16</sup> down to 0</p> | 
| Counters     | (see table in second next slide)                                |
| Instructions | to be performed if there is a match                             |
| Timeouts     | idle-timeout, hard-timeout.                                     |
| Cookies      | to filter flow statistics, flow modification and flow deletions |
| Flags        | they alter the way flow entries are managed                     |

### OpenFlow Table Format
![[OpenFlow Table Format.png]]

### Match Fields
#### Required Match Fields
| Counter | Usage | Bit Length |
| ------- | ----- | ---------- |
| Reference count (active entries) |  Per flow table | 32 |
| Duration (seconds) | Per flow entry | 32 |
| Received packets | Per port | 64 |
| Transmitted packets | Per port | 64 | 
| Duration (seconds) | Per port | 32 | 
| Transmitted packets | Per queue | 64 | 
| Duration (seconds) | Per queue | 32 | 
| Duration (seconds) | Per group | 32 | 
| Duration (seconds) | Per meter | 32 | 

#### Optionally Supported Match Fields
- Physical port
- Metadata
- VLAN ID and VLAN ID user priority
- SCTP source and destination ports
- ARP code
- Source and target IPv4 address in ARP payload
- MPLS label value, traffic class, and BoS
- Provider Bridge traffic ISID
- Tunnel ID
- TCP flags

| IP==v6==                                         | ICMP==v6==            |
| ------------------------------------------------ | --------------------- |
| DS and ECN*                                      | type and code fields* |
| ==neighbor discovery source and target address== |                       |
| ==flow label==                                   |                       |
| ==extension==                                                 |                       |

----
> [!NOTE] Flow
>- A sequence of packets that matches a specific entry in the flow table
>- A combination of flow entries on multiple switches defines a flow that is bound to a specific path

---
%%## Four Categories of Instructions ### %% 
## Flow Table Pipeline
>[!NOTE] Definition
>A set of linked flow tablesthat provide matching, forwarding, and packet modification in an OpenFlow switch. A port is where packets enter and exit the pipeline.

- The OpenFlow specification defines two stages of processing:
	- Ingress
	- Egress
![[Example of Nested Flows.png]]
## The OpenFlow Protocol
- Typically, the protocol is implemented on top of TLS
### OpenFlow Messages
![[OpenFlow Messages#^947625]]
![[OpenFlow Messages#^54fa40]]
## REST API (REpresentational State Transfer)
- An architectural style used to define APIs
- This has become a standard way of constructing northbound APIs for SDN controllers
- A REST API, or an API that is RESTful is not a protocol, language, or established standard
- It is essentially six constraints that an API must follow to be RESTful
	- The objective of these constraints is to maximize the scalability and independence/interoperability of software interactions, and to provide for a simple means of constructing APIs
### REST Constraints
- Client-server
  dictates that interaction between application and server is in the client-server request/response style
- Stateless
  Dictates that each request from a client to a server must contain all the information necessary to understand the request and cannot take advantage of any stored context on the server
- Cacheable
  Requires that the data within a response to a request be implicitly or explicitly labeled as cacheable or non-cacheable
- Uniform interface
  The uniform interface constraint defines the interface between clients and servers. It simplifies and decouples the architecture, which enables each part to evolve independently.
- Layered system
  The uniform interface constraint defines the interface between clients and servers. It simplifies and decouples the architecture, which enables each part to evolve independently.
- Code on demand
  This condition allows the customer to run some code on demand, that is, extend part of server logic to the client, either through an applet or scripts. Thus, different customers may behave in specific ways even using exactly the same services provided by the server. As this item is not part of the architecture itself, it is considered optional. It can be used when performing some of the client-side services which are more efficient or faster.