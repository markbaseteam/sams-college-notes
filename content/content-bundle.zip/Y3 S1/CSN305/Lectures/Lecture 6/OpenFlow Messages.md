 **Message** | **Description** | **Message** | **Description** 
 --- | ---- | ---- | -----
**Controller-to-Switch** || **Asynchronous** 
| Features | Request the capabilities of a switch. Switch responds with a features reply that specifies its capabilities. | Packet-in | Transfer packet to controller. |
| Configuration | Set and query configuration parameters. Switch responds with parameter settings | Flow-Removed | Inform the controller about the removal of a flow entry from a flow table. | 
| Modify-State | Add, delete, and modify flow/group entries and set switch port properties. | Port-Status | Inform the controller of a change on a port.
| Read-State | Collect information from switch, such as current configuration, statistics, and capabilities. | Role-Status | Inform controller of a change of its role for this switch from master controller to slave controller. | 
| Packet-out | Direct packet to a specified port on the switch. | Controller-Status | Inform the controller when the status of an OpenFlow channel changes. This can assist failover processing if controllers lose the ability to communicate among themselves. | 
| Barrier | Barrier request/reply messages are used by the controller to ensure message dependencies have been met or to receive notifications for completed operations. | Flow-monitor | Inform the controller of a change in a flow table. Allows a controller to monitor in real time the changes to any subsets of the flow table done by other controllers | 
^947625

| **Message** | **Description** |
:-----------: | ----------- | --------------- 
| **Controller-to-Switch** |||
|| Role-Request               | Set or query role of the OpenFlow channel. Useful when switch connects to multiple controllers.                |
|| Asynchronous-Configuration | Set filter on asynchronous messages or query that filter. Useful when switch connects to multiple controllers. | 
| **Symmetric** |||
|| Hello | Exchanged between the switch and controller upon connection startup. | 
|| Echo | Echo request/reply messages can be sent from either the switch or the controller, and must return an echo reply. | 
|| Error | Used by the switch or the controller to notify problems to the other side of the connection. | 
|| Experimenter | For additional functionality. | 

^54fa40
