```toc
```
- cables must be fully identifyable

## Overlay Networks
- They use software to create layers of network abstraction on top of the physical layer.
## MPLS
> [!note] MPLS
> Multiprotocol label switching (MPLS) is a mechanism used within computer network infrastructures to speed up the time it takes a data packet to flow from one node to another. It enables computer networks to be faster and easier to manage by using short path labels instead of long network addresses for routing network packets.
