```toc
```

> [!note] **OpenFlow**
> A [communications protocol](https://www.wikiwand.com/en/Communications_protocol "Communications protocol") that gives access to the [forwarding plane](https://www.wikiwand.com/en/Forwarding_plane "Forwarding plane") of a [network switch](https://www.wikiwand.com/en/Network_switch "Network switch") or [router](https://www.wikiwand.com/en/Router_(computing) "Router (computing)") over the network.

## Parts of OpenFlow
- Flow tables, which are installed in the switches themselves
- A controller, which communicates with the switches through the OpenFlow protocol and sets the policies on traffic flow. It also sets up specific paths through the network or optimizes it for specific attributes like speed, reduced latency or number of hops.
- OpenFlow protocol, which enables the controller to securely communicate with the switches

## OpenFlow Ports

^1f3c93

> [!note] Logical Ports  
> Logical ports are switch-defined ports that do not correspond directly to hardware interfaces on the switch. Examples of these include LAGs, tunnels and loopback interfaces. 

^bf2c10

> [!note] Physical Ports 
> Physical ports are switch-defined ports that correspond to a hardware interface on the switch. This could mean one-to-one mapping of OpenFlow physical ports to hardware-defined Ethernet interfaces on the switch, butt doesn’t necessarily have to be one-to-one.

^0c9a49

>[!note] Reserved Ports
> specify generic forwarding actions such as sending to the controller, flooding, or forwarding using non-OpenFlow methods, such as “normal” switch processing.

^cb6efb

^02e7db
## OpenFlow Messages
| Message | Function |
| ------- | -------- |
| Features | switch needs to request identity | 
| Configuration | set and query configuration parameters | 
| Modify-State | also called ‘flow mod’, used to add, delete and modify flow/group entries | 
| Read-States | get statistics | 
| Packet Outs | controller send message to the switch, either full packet or buffer ID. | 
| Barrier | Request or reply messages are used by controller to ensure message dependencies have been met and receive notification. | 
| Role-Request | set the role of its OpenFlow channel | 
| Asynchronous-Configuration | set an additional filter on asynchronous message that it wants to receive on OpenFlow Channel | 

### Asynchronous Messages
Asynchronous messages are initiated by the switch and used to update the controller of network events and changes to the switch state. These messages include:

| Message | Function |
| ------- | -------- |
| Packet-in | transfer the control of a packet to the controller | 
| Flow-Removed | inform controller that flow has been removed | 
| Port Status | inform controller that switch has gone down | 
| Error | notify controller of problems | 

### Symmetric Messages
Symmetric messages are initiated either by the switch or controller and sent without solicitation. These messages include:

| Message | Function |
| ------- | -------- |
| Hello | introduction or keep-alive messages exchanged between switch and controller | 
| Echo | sent from either switch or controller, these verify liveness of connection and used to measure latency or bandwidth | 
| Experimenter | a standard way for OpenFlow switches to offer additional functionality within the OpenFlow message type space. | 

