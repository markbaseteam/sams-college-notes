<center><h1>Lecture 10</h1></center>

<% [TOC] %>

## Network Functions Virtualization

>[!note] NFV
>abstracts the network functions in a network appliance from the underlying hardware and creates software instances of each function that can be used in a VM or as an application on a nonvirtualized server.

- Specific functions
- compliment to SDN
- 
### SDN vs NFV
![[SDN vs NFV.png]]

## Downsides of SDN
- A Loss of Visibility
	- intra-VM-to-VM communications through tunnels
	- inter-VM-to-VM communications through tunnels
- Latency among virtualized resources
- Vulnerability to external threats
## Reasons to Adopt SDN
| Telecom industry                                                                                                                                 | End Users / Customer Experience                                                                         |
| ------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------- |
| <ul><li>++ production of internet-based applications</li><li>5G explosion</li><li>M2M and IoT connectivity >>> chaotic traffic patters</li></ul> | <ul><li>Lower costs</li><li>Minimum latency</li><li>Scalability</li><li>Reduce time-to-market</li></ul> |

