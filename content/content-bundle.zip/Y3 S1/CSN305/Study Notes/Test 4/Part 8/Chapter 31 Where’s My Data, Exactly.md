```button
name Link to Textbook
type link
action https://learning.oreilly.com/library/view/sdn-and-nfv/9780134307398/ch31.html#ch31
```
^button-zflv
```toc
```
## Storage-Area Networks
As network storage evolved, it grew in complexity, and even larger drives were being aggregated into storage arrays to support enterprise levels of data that required dedicated storage-area networks (SANs). The SAN might not necessarily be in the user’s local data center, but instead be hosted in a regional data center, but again this was not something the user was aware of, or was interested in knowing.

![[Pasted image 20221208185410.png]]
<center><p>- <b>Figure 31-1</b> <i>Storage-area network diagram</i> </p></center>
Therefore, where exactly the data so stored is not a technical issue (well, not in huge enterprise networks), because we don’t really know. Of course, we know which data centers store the data, but not specifically on which storage area element or drive array because it will be located in several locations for performance, availability, and backup.

## Data Location and Security
### The 3 Tenets of Security:
- Confidentiality
- Integrity
- Availability 
![[Pasted image 20221208190240.png]]
<center><p>- <b>Figure 31-2</b> <i>The CIA triad is a broadly used concept describing the self-reinforcing concept of data security with regard to confidentiality, integrity, and availability.</i></p></center>
IT security has been against the use of free anonymous email since the beginning, and they have considered hosted email solutions as being little better, sometimes even worse. Their compliance revolved around the ambiguous storage of company data, regarding not just storage location, but with regard to data ownership and other legalities. Nothing has changed in the meantime. IT security teams are still concerned with locating data on the public cloud, not so much for technical reasons but more for the political and legal concerns.

## So What Are the Nontechnical Issues That We Need to Address?

The issue is that the big cloud providers (Google, Amazon, and Microsoft, among others) all have global networks and could be (and probably are) storing your company data in any part of the world. Other smaller cloud providers may not have the scale of these behemoths but are just as oblique in their storage policies. After all, these providers are storing your private and confidential data on proprietary cloud storage networks in locations you perhaps cannot verify and that you will have little chance of auditing. [Figure 31-3](https://learning.oreilly.com/library/view/sdn-and-nfv/9780134307398/ch31.html#ch31fig03) shows a diagram of AWS storage, which does not guarantee a specific location for their customers’ data.

![Image](https://learning.oreilly.com/api/v2/epubs/urn:orm:book:9780134307398/files/graphics/31fig03.jpg)
<center><p>- <b>Figure 31-3</b> <i>A block diagram of AWS storage. AWS does not guarantee that it can or will provide details on the exact physical location of customer data.</i></p></center>