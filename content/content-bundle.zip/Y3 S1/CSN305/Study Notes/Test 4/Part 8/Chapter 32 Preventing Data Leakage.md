```button
name Link to Textbook
type link
action https://learning.oreilly.com/library/view/sdn-and-nfv/9780134307398/ch32.html#ch32
```
^button-zflv
```toc
```

Unauthorized removal of data from businesses has long been a problem, especially with the advent of high-capacity removable storage such as laptop hard disks and USB thumb drives. However, with the advent of the Internet and its associated technologies such as private email, mobile wireless devices, and cloud storage, it has never been more difficult for IT security to secure the company’s data. Recent business initiatives such as bring your own device (BYOD) and worse bring your own cloud (BYOC) have almost given employees free rein to transfer data outside of the business on personal devices and even to store company data on personal storage clouds such as Dropbox. Note that this is not meant to imply that rogue employees with the intent of stealing data are the main issue here.

## Minimizing Data Loss
### Key Steps in Minimizing Data Loss
1. Apply the risk formula for data loss (Risk = Impact × Rate of occurrence). This differs from the standard security risk formula because data loss is inevitable, unintentional, and (importantly) it can be measured and mitigated.
2. Apply the 80:20 rule of data loss to identify where you are likely to experience a high impact data breach.
---
![[Courses/Y3 S1/CSN305/Lectures/Lecture 11#^your-id]]

## Data Loss Protection![[Courses/Y3 S1/CSN305/Lectures/Lecture 11#Types of Data Loss Prevention (DLP)]]