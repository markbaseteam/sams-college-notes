```toc
```

## [[Test 1]]
### [[Chapter 3 Hypervisors (VMWare, KVM, and Others)]]

> [!note]- Hypervisor
> the bridge between the operating systems and the server hardware. It carries the input/output (I/O) commands and interrupt commands from the virtualized OS to the hardware.

> [!note]- Type 1/_bare-metal_ hypervisor
> the hypervisor runs directly on the server hardware without any native operating system.
> 

> [!note]- Type 2/_hosted hypervisors_
> run on top of a native OS. In this use case, the hypervisor is a shim that sits between the OS of the VM above and the OS of the server or computer below.
> 

![[Chapter 3 Hypervisors (VMWare, KVM, and Others)#^8f7c07]]

### [[Chapter 5 Virtualized Data Centers (Some Call Them Clouds)]]
![[Chapter 5 Virtualized Data Centers (Some Call Them Clouds)#^257f91]]

| Cloud Deployment Model | Description                                                                                                                                                                                                                                                                                                                                         |
| ---------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Private Clouds         | when an enterprise data center is reconfigured in such a way as to provide the five attributes                                                                                                     |
| Public Clouds          | It’s open to anyone and everyone who has connectivity and a credit card (or some remote method of payment).                                                                                                                                                                                                                                         |
| Community Clouds       | a community or multitenant cloud is run by a service provider that hosts services for a select group of customers, almost always businesses (as opposed to  individuals). The various tenants are likely sharing common resources, but the service is not public in the sense that just anyone can access these cloud resources any time they want. |
| Hybrid Clouds          | some providers offer administrative control over multiple cloud platforms (private or public) that can be managed through a single interface. This allows seamless access to both cloud environments.                                                                                                                                               |

### [[Chapter 8 VMware, VSphere, VMotion, and VXLAN]]
> [!note]- VXLAN
> n encapsulation protocol that **provides data center connectivity using tunneling to stretch Layer 2 connections over an underlying Layer 3 network**.

### [[Chapter 10 How Do You Virtualize a Network]]
> [!note]- Server Virtualization
> The abstraction of applications and operating systems from physical servers.

> [!NOTE]- Network Virtualization
> Network Virtualization refers to the creation of logical groupings of endpoints on a network.

> [!NOTE]- Network Functions Virtualization
> NFV refers to the virtualization of Layer 4 through 7 services such as load balancing and firewalling.

> [!note]- Software-Defined Networking
> Software-defined networking is a network concept where, in network architecture, the network’s "control plane" or data transmission structure is separated from other functions. It creates some abstraction in the software layers that manage the network.

### [[Chapter 20 What’s Wrong With the Network We Have]]
> [!NOTE]- Control Pane
> where the intelligence of the device lies. It is here where all the instructions (in the form of applications and large tables of rules) are stored. 

> [!note]- Forwarding Plane
> where packets are moved from one network interface on the machine to one of the many other network interfaces on the machine. 

> [!note]- Open Shortest Path First (OSPF)
> Open Shortest Path First (OSPF) is a link state routing protocol (LSRP) that uses the Shortest Path First (SPF) network communication algorithm (Dijkstra's algorithm) to calculate the shortest connection path between known devices.

> [!note]- **Dijkstra's algorithm**
> an [algorithm](https://www.wikiwand.com/en/Algorithm "Algorithm") for finding the [shortest paths](https://www.wikiwand.com/en/Shortest_path_problem "Shortest path problem") between [nodes](https://www.wikiwand.com/en/Vertex_(graph_theory) "Vertex (graph theory)") in a [graph](https://www.wikiwand.com/en/Graph_(abstract_data_type) "Graph (abstract data type)"), which may represent, for example, [road networks](https://www.wikiwand.com/en/Road_network "Road network"). It was conceived by [computer scientist](https://www.wikiwand.com/en/Computer_scientist) [Edsger W. Dijkstra](https://www.wikiwand.com/en/Edsger_W._Dijkstra "Edsger W. Dijkstra") in 1956 and published three years later.

### [[Chapter 21 How SDN Works]]
> [!note]- The Application Layer
> As the name suggests, this layer includes the network applications. These can include communication applications such as VoIP prioritization, security applications such as firewalls, and many others. This layer also includes network services and utilities.

>[!note]- The Control Layer
> What used to be the control plane of the switches and routers is now centralized. This allows for a programmable network. OpenFlow is an open source network protocol that the industry seems to have settled on, although the big network vendors (such as Cisco) have their own variants.

> [!note]- The Infrastructure Layer
> This layer includes the physical switches and routers and the data. Traffic is moved based on flow tables. 

## Test 2
### [[Chapter 15 OpenFlow]]
>[!note]- OpenFlow 
> an open communications protocol that acts on Layer 2 of the OSI model and provides access to the forwarding plane of a router or switch over the network. 

 > [!note]- MPLS
> **Multiprotocol Label Switching** (**MPLS**) is a routing technique in [telecommunications networks](https://www.wikiwand.com/en/Telecommunications_network "Telecommunications network") that directs data from one [node](https://www.wikiwand.com/en/Node_(networking) "Node (networking)") to the next based on labels rather than network addresses.[](https://www.wikiwand.com/en/Multiprotocol_Label_Switching#cite_note-1) Whereas network addresses identify [endpoints](https://www.wikiwand.com/en/Communication_endpoint "Communication endpoint") the labels identify established paths between endpoints.
### [[Chapter 23 SDN Controllers]]
#### Closed Source
> [!note]- Cisco Application Policy Infrastructure Controller (APIC)
> The Cisco APIC acts as a central point of control, data, and policy and provides a central API.

> [!note]- HP Virtual Application Networks
This uses OpenFlow to control forwarding decisions and policy in an SDN topology.

> [!note]- NEC ProgrammableFlow PF6800
> The NEC controller is programmable and standardized in that it integrates with both OpenFlow and Microsoft System Virtual Machine Manager.

> [!note]- VMware NSX Controller
> This product is a distributed control system that can control virtual networks and overlay transport tunnels over the existing infrastructure. The controller communicates with the applications to ascertain their requirements before configuring all the vSwitches.

#### Open Source
> [!note]- OpenDaylight 
> OpenDaylight can provide centralized control over any vendor equipment.

> [!note]- OpenContrail SDN controller
> This controller is actually a stem from Juniper’s commercial offering and can be used as a platform for network virtualization under open source licensing. 

> [!note]- Floodlight
> This is a Java-based controller for SDN that supports a range of OpenFlow virtual or real switches. It is part of the Big Switch open source project and has been successfully used in a number of SDN projects (for example, the OpenStack Quantum plug-in and the Floodlight virtual switch). 

> [!note]- Ryu OpenFlow Controller
>Ryu is an open source SDN controller framework that supports several protocols, including OpenFlow, Netconf, and OF-config.

> [!note]- Flowvisor
>This is a specialist OpenFlow controller that acts as a go-between for OpenFlow switches and multiple OpenFlow Controllers.


## Part 3

![[MEF 3.0 SD-WAN Services -MEF White Paper#9 Terminology]]

