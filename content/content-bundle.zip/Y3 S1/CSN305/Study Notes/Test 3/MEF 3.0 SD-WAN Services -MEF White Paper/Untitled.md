## Row 1
<ul style="list-style-type:none;">
	<li>Rapid matching of production facilities to requirements for new products</li>
	<ul>
		<li>Supply chain accuracy</li>
		<li>Stock and supplier management for just-in-time engineering</li>
		<li>Rapid time-to-market for products</li>
		<li>Plant re-tooling</li>
	</ul>
	<li>Including remote facilities in production capabilities both robustly and securely</li>
	<ul>
		<li>Integration of acquired sites in a rapid expansion</li>
		<li>Strengthened security for SCADA systems and IoT endpoints</li>
		<li>Autonomous network telemetry</li>
		<li>5G network slicing</li>
		<li>Multi-access Edge Computing</li>
		<li>Pre-empting and mitigating production failures</li>
	</ul>
	<li>Predictive maintenance in production processes</li>
	<ul>
		<li>Digital twin technology</li>
	</ul>
</ul>

## 2
<ul style="list-style-type:none;">
	<li>Extending geographical footprint of medical expertise and care</li>
	<ul>
		<li>Immersive healthcare experiences using virtual reality (VR), augmented reality (AR) and mixed reality (MR)</li>
		<li>Mobile clinics and MRIs</li>
		<li>New therapies are also developing, underpinned by technology innovation: examples include virtual & augmented (AR/VR) reality and digital engagement therapy.</li>
		<li>5G Ambulance</li>
	</ul>
	<li>Improving security of health data</li>
	<ul>
		<li>Better security in medical device IoT (MDIoT) - IoMT devices are becoming prolific in healthcare, and these simple devices are difficult to secure and breaches very challenging to repair</li>
		<li>Better healthcare cybersecurity far beyond patient data protection but defense against potential state-sponsored cyber-terrorism</li>
	</ul>
	<li>Improving patient experience</li>
	<ul>
		<li>Digital twin technology </li>
	</ul>
</ul>

## Row 3
<ul style="list-style-type:none;">
	<li> Rapid set up, adjustment and re-distribution of physical branch facilities to meet changing localized market needs.</li>
	<ul>
		<li>Pop-up stores & intelligent kiosks</li>
		<li>Automation - customer movements and experiences can be   monitored with big data assessments for test and strengthening of branch performance.</li>
		<li>Meeting multi-generational customer demands with a modern customer-centric environment</li>
		<li>Leveraging customer data - branch systems and tools must connect up all the touch points with clients</li>
	</ul>
	<li>Improving security of financial data</li>
	<ul>
		<li>Consistent branch security policy compliance Improving customer experience</li>
	</ul>
	<li>Improving customer experience</li>
	<ul>
		<li>AR/VR</li>
		<li>Robotics and wearable technologies</li>
		<li>Interactive Teller Machine (ITM) technology and self-service kiosks - 'drive-through' customer experience e.g., customers can use an ATM to scan an ID document and get approval for a cash withdrawal while they are waiting for a card replacement, without having to interact with a human</li>
	</ul>
</ul>

## 4
<ul style="list-style-type:none;">
	<li> Rapid set up, adjustment and re-distribution of physical branch facilities to meet changing localized citizen needs and range of verticals</li>
	<ul>
		<li>Government agency networks act like commercial enterprises</li>
		<li>Agencies have a lot of branch offices, and they want to be     able to turn them up quickly if needed (for example, FEMA).</li>
		<li>Larger offices are sometimes using SD-WAN with multiple     connections, including back-up connectivity over wireless (and especially want this capability as 5G emerges)</li>
		<li>Need to handle multiple verticals under the nation or state     government umbrella</li>
		<li>Thousands of remote offices and branches with low bandwidth</li>
		<li>Differentiation from local government/municipalities</li>
		<li>Ability to handle home schooling in remote areas (e.g. via satellite)</li>
		<li>Emergency 'cell on wheels'</li>
	</ul>
	<li>Maximizing taxpayer ROI</li>
	<ul>
		<li>Key drivers: performance and cost savings (connectivity, management, staff). Shift from 2x Private IP VPN service to 1x Private IP VPN service + dedicated Internet.</li>
		<li>Managed services reduce dependence on internal IT agencies</li>
		<li>Greater use of cloud and Internet and less VPNs</li>
		<li>Use of smaller localized service providers rather than the larger telcos that have large footprintsReconfiguration</li>
	</ul>
	<li>Reconfiguration of security architecture</li>	<ul>
		<li>Safely bypassing security gateways that reduce performance</li>
		<li>Ability to use policies dynamically to handle wide range of data security classification levels</li>
	</ul>
	<li>Simplifying procurement</li>
	<ul>
		<li>Standardized and certified SD-WAN</li>
		<li>Standardized terminology across multiple government agencies</li>
	</ul>
</ul>
