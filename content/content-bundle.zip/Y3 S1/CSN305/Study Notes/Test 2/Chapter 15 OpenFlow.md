```toc
```
>[!note]- OpenFlow 
> an open communications protocol that acts on Layer 2 of the OSI model and provides access to the forwarding plane of a router or switch over the network. 
## How OpenFlow Works 
In OpenFlow, a flow table has three fields: (1) A packet header that defines the flow, (2) the action that is to be taken on packets for each flow, and (3) statistics that keep track of the packets and bytes for each flow. Each flow in the table has a simple action associated with it. The four basic actions that all OpenFlow ready switches must support are as follows:
1. Forward: packet flows to a given port. This allows packets to be routed through the network 
2. Encapsulate and forward: flow to a controller. This is typically an action for the first packet in a new flow so that the controller can decide whether it needs to be added to the flow table.
3. Drop: packet flow. This is used for security. For example, it can be used to curb denial-of-service attacks.
4. Forward: packet as normal.

 > [!note]- MPLS
> **Multiprotocol Label Switching** (**MPLS**) is a routing technique in [telecommunications networks](https://www.wikiwand.com/en/Telecommunications_network "Telecommunications network") that directs data from one [node](https://www.wikiwand.com/en/Node_(networking) "Node (networking)") to the next based on labels rather than network addresses.[](https://www.wikiwand.com/en/Multiprotocol_Label_Switching#cite_note-1) Whereas network addresses identify [endpoints](https://www.wikiwand.com/en/Communication_endpoint "Communication endpoint") the labels identify established paths between endpoints.

OpenFlow works on three layers, enabling a controller to manage the forwarding process of data flows through the network by manipulating the flow tables of both physical and virtual switches and routers. These layers are as follows:

- **The application layer:** This layer handles the business applications and helps accelerate new features and service introduction by decoupling applications from vendor platforms.
- **The control layer:** The centralization of intelligence simplifies provisioning, optimizes performance, and enables greater control, granularity, and simplification of policy management across all network devices.
- **The infrastructure layer:** It is at this layer that hardware is decoupled from software and the control plane is decoupled from the data (forwarding) plane. Decoupling these planes facilitates logical configuration through software on a central controller rather than physical configuration of each device.