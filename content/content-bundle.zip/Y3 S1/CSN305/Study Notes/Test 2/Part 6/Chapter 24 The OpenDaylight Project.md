```toc
```

- The ideals of the ODL project are to further the adoption and innovation of the SDN through a common framework
- ODL as a project was designed to fulfill the following:
	- Design a framework for delivering a network architecture that can deliver diverse applications and customer experience
	-  Provide the means for a programmable network
	- Abstract the control plane logic from network devices into a centralized entity 
## How the ODL Architecture Works
The ODL controller, as you have seen, sits between the application layers and the data (packet forwarding) layers. This is important because it provides the mechanisms to control both upstream and downstream traffic flows.
- The ODL controller acts as a service abstraction layer that mediates between southbound and northbound communications. ODL sits between the applications (northbound) and the lower-layer switches (southbound).
- Northbound APIs allow applications to collect and analyze traffic data, and therefore adjust traffic flows by sending corrective signals to the network devices via the ODL controller.
- The southbound APIs provide the interface to control the physical or virtual switches. The most commonly used, standardized, and integrated protocol in ODL is OpenFlow.

## The ODL Controller Platform
With an understanding of what ODL is and how it operates, let’s look at the ODL controller platform. After all, the controller is the “brain” that controls both northbound interfaces and southbound interfaces, but there is much more than that to a controller’s function:
- **Topology manager:** Stores and manages information about all the network devices.
- **Statistic manager:** Collects and analyzes data for each network segment. The northbound APIs also supply information (data) on switch port, flow meter, table, and group statistics.
- **Forwarding rules manager:** Manages basic forwarding rules such as through OpenFlow.
- **Host tracker:** Stores information of all entities on the network, their OS, device type, and version.

