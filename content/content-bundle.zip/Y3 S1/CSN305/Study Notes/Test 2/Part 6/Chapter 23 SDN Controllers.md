```toc
```
## Centralized Control
- The controller is a centralized “brain” in the network; it will have a global view of all the network devices, their interconnections, and the best paths between hosts. Having this single global map of the network enables the controller to make swift, intelligent, and agile decisions with regard to flow direction, control, and speedy network reconciliation when a link fails.
- After all, the time to converge in a network is as follows:
	  The time to detect a failure + the time to announce a failure to all parties + the time to run the algorithm + the time to update the databases in each device

### Commercial controllers
- Cisco Application Policy Infrastructure Controller (APIC)
	The Cisco APIC acts as a central point of control, data, and policy and provides a central API.
- HP Virtual Application Networks
	This uses OpenFlow to control forwarding decisions and policy in an SDN topology.
- NEC ProgrammableFlow PF6800
	The NEC controller is programmable and standardized in that it integrates with both OpenFlow and Microsoft System Virtual Machine Manager.
- VMware NSX Controller
	This product is a distributed control system that can control virtual networks and overlay transport tunnels over the existing infrastructure. The controller communicates with the applications to ascertain their requirements before configuring all the vSwitches.

### Open-Source Offerings
- OpenDaylight 
	OpenDaylight can provide centralized control over any vendor equipment.
- OpenContrail SDN controller
	This controller is actually a stem from Juniper’s commercial offering and can be used as a platform for network virtualization under open source licensing. 
- Floodlight
	This is a Java-based controller for SDN that supports a range of OpenFlow virtual or real switches. It is part of the Big Switch open source project and has been successfully used in a number of SDN projects (for example, the OpenStack Quantum plug-in and the Floodlight virtual switch). 
- Ryu OpenFlow Controller
	Ryu is an open source SDN controller framework that supports several protocols, including OpenFlow, Netconf, and OF-config.
- Flowvisor
	This is a specialist OpenFlow controller that acts as a go-between for OpenFlow switches and multiple OpenFlow Controllers.
 