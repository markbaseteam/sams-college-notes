```ccard
sytle: strip
items: [
  {
    title: 'Chapter 23 SDN Controllers',
    link: 'Courses/Y3 S1/CSN305/Study Notes/Test 2/Part 6/Chapter 23 SDN Controllers.md',
    brief: '`toc',
    foot: '10/20/2022, 4:22:27 PM',
    head: 'Note'
  },
  {
    title: 'Chapter 24 The OpenDaylight Project',
    link: 'Courses/Y3 S1/CSN305/Study Notes/Test 2/Part 6/Chapter 24 The OpenDaylight Project.md',
    brief: '`toc',
    foot: '10/20/2022, 4:42:11 PM',
    head: 'Note'
  }
]
```

## Test 4
