```toc
```

> [!question] ## What's a Hypervisor?
> - [[#An Operating System for Operating Systems]]
> - [[#A Virtual Machine Monitor]]

## An Operating System for Operating Systems
For example, the hypervisor has replaced the server’s own OS and as such has taken responsibility for interacting between the hardware devices and the VM’s internal OS. It’s doing for the operating system portion of a VM just what the server’s own operating system would do for applications on a dedicated machine.

## A Virtual Machine Monitor
The second part of our working definition of hypervisors takes into account the fact that multiple VMs can run on a single server. To do this, the hypervisor must also provide a monitoring function for each VM to manage the access requests and information flows from the VMs to the computing resources and vice versa.

## Types of Hypervisors
There are two types of hypervisors, denoted as Type 1 and Type 2. A Type 1 hypervisor (see [Figure 3-1](https://learning-oreilly-com.libaccess.senecacollege.ca/library/view/sdn-and-nfv/9780134307398/ch03.html#ch03fig01)) is called a _bare-metal_ hypervisor in reference to the fact that the hypervisor runs directly on the server hardware without any native operating system. The hypervisor is the operating system of the server providing direct access to the hardware resources for the guest VMs riding on top of it. Most of the servers in production today are using Type 1 hypervisors.

![[Bare-Metal Hypervisor.png]] ^45rjkd
> **Figure 3-1** _A Type 1 hypervisor interfaces directly with the hardware resources._

Type 2 hypervisors (see [Figure 3-2](https://learning-oreilly-com.libaccess.senecacollege.ca/library/view/sdn-and-nfv/9780134307398/ch03.html#ch03fig02)), called _hosted hypervisors_, run on top of a native OS. In this use case, the hypervisor is a shim that sits between the OS of the VM above and the OS of the server or computer below.

![[Hosted Hypervisor.png]]
>**Figure 3-2** _Type 2 hypervisors interface with the native OS running on the server._

- The hypervisor is the bridge between the operating systems and the server hardware. It carries the input/output (I/O) commands and interrupt commands from the virtualized OS to the hardware.

## Choosing a Hypervisor
| Hosted hypervisors                                                                                                                                                                                                                                           | Native hypervisors |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ------------------ |
| are easier to install, but they do tend to run at less than full capacity due to the extra layer. They do have greater flexibility, though, and if you already have servers running a specific operating system, the transition to virtualization is easier. | typically offer better performance for the VMs running on them because they are directly connected to the hardware. This improved latency response is an important factor, especially in a service model where there may be service level agreements (SLAs) that specify server and application performance. |

^8f7c07

## Summary
Hypervisors are the foundation of virtualization, providing the bridge between VMs and the server hardware and native operating system. Without this crucial piece, we would not be able to abstract VMs from the servers they run on.

What’s more is the hypervisor is a precursor to what is referred to as an SDN controller, a foundational component of software-defined networks. You’ll learn more about that later in the book and will continue to read about the role of hypervisors in cloud networks and the virtualization of networking functions.