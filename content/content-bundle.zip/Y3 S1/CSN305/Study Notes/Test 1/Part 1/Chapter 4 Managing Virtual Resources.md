```toc
```
## What Is a Workload?
- One of the simplest ways to explain a workload is to think of it as a collection of computing “stuff” you need to run an application. A lot of people get hung up on the idea that a workload is a program or an application, but that’s only part of it. More than just the application, the workload also includes resources needed to run it, including operating system burden, compute cycles, memory, storage, and network connectivity. In the VM environment, the workload can even include the load on the components apart from the server itself, such as network or storage components that are not permanently attached to a server.
- In the virtualization model, these workloads are able to be spun up and torn down very quickly, and in some cases require that another workload be spun up to complete a subtask.
- Virtualization is what allows us to break up all the various resources into pools so that we can create very efficient workloads (such that the containers all have the resources they need, and no more), but it’s what we commonly know as cloud networking that allows us to stitch these workloads together quickly and reliably.

## Managing Virtual Resources in the Hypervisor
- Once the VM is up and running, the task of controlling and managing the virtual resources belongs to the hypervisor.
- one of the goals of going down the virtualization route was to improve server utilization and efficiency.
- Unfortunately, our efforts to bring a smile to the CFO’s face may rebound badly on us if we push the utilization thresholds too far. After all, our VMs are using virtual resources, created and supplied by the hypervisor, such as virtual CPU, virtual RAM, virtual disk, and virtual network. Therefore, we must understand the correlation between virtual and real resources, because the virtual resources are being taken from very real and finite physical resources, such as the physical RAM and physical CPU.

In any virtualized environment, the key resources you must manage are as follows:

- CPU
- Memory
- Storage
- Network
- Power

The first four resources are probably expected, but power might come as a surprise.

The reason that power is included is that even power is a finite resource in the data center, which means it must be monitored and managed. For that reason, hypervisors can manage the utilization of power distribution through power distribution management (PDM), which can consolidate VMs when utilization is low on fewer hosts and even put some hosts to sleep.

## Virtual Resource Providers and Consumers
In a virtualized environment, physical resources are provided by physical hosts, which is a little different than traditional data centers. In traditional data centers, all required resources were supplied by a single host. In virtualized data centers, you’ll find resource clusters, which are groups of physical resources. Resource clusters can include the following:
- Storage
- Memory
- Data stores (storage)
- Hosts (physical servers with VMs loaded on them)

## So How Do You Manage Virtual Resources?
- The reason that virtual resource management is so important is that performance isolation must be maintained.
- In summary, virtual resources can be managed through both administrative controls and through automated hypervisor virtual management. However, both have to be configured as preset VM resource allocations, which if not predicted carefully can create resource starvation in busy or active VMs and resource waste in less-intensive or idle VMs. However, by utilizing good management and oversight, you can enable dynamic stretching and shrinking of resource pools, which allows applications to demand and consume resources on an as-needed basis without impacting performance.