```toc
```
## Reduced Cost
- As discussed in [Chapter 1](https://learning-oreilly-com.libaccess.senecacollege.ca/library/view/sdn-and-nfv/9780134307398/ch01.html#ch01), “[Primer on Virtualization](https://learning-oreilly-com.libaccess.senecacollege.ca/library/view/sdn-and-nfv/9780134307398/ch01.html#ch01),” the most obvious benefit of VMs is that they greatly reduce the runaway expenses from server proliferation. These costs are compounded by the extremely inefficient usage and the costs associated with 24/7 power and energy consumption, which contribute to the rising temperature of the data centers and consequently the high costs of cooling the environment.
- VMs cut costs by addressing the twin problems of underutilization of each server and over usage of power due to supporting server proliferation or server spread in the data center. A typical server today is extremely powerful and is severely underutilized if dedicated to running only one application, running perhaps as low as 5% to 10 %. VMs allow for server consolidation because several VMs can be installed and operate on a single server. Therefore, server consolidation can not only reduce the number of servers in the data center by a factor as high as ten but also increase the efficiency of each server by as much as 80%. Fewer servers and more densely deployed VMs per server provides for the largest cost savings.

## Less Space (Even More Cost Savings)
### Rate of Growth
  For example, a company that is building a data center must attempt to accurately gauge growth to avoid underutilized space or worse, underestimating server growth that would require yet another data center.
### Power
  All of these servers generate an enormous amount of heat, and the servers need to be kept cool. Interestingly, though, the temperatures that data centers are cooled to are more about human consideration than server consideration. It turns out that servers can operate efficiently at much higher temperatures than humans can tolerate over a sustained period of time. In fact, in some cases, robots are being used within the data centers left at higher temperatures (80+ F). The robots are controlled by people in command rooms where the temperature is set for humans.
### Cabling
  Connecting servers together (to each other and to the network) requires a lot of cabling, including power cables, direct connection cables between ports, and the massive data center networks that connect all the servers to the network and monitoring tools.
  
## Faster Application Spin-Up and Provisioning
- using VMs for test and development is a wonderful solution because VMs can be installed and started when required, and then shut down and stored between projects, without using up any precious resources or conflicting with other test and development environments.
- Other benefits of a VM environment relate to system administration. VMs come with tools that enable granular server management by allocating, regulating, and enabling the fine-tuning of the computer resources that each VM may use. For example, an administrator may assign an intensive CPU application several CPU cores, but assign other VMs running standard applications a single core. Similarly, the administrator can reserve or allocate memory and even network bandwidth per VM to tailor the requirements for the application it is running.
- a VM file can be created, stored, or proliferated across the organization with adjustments for each user or application. One typical application is an end-user virtual desktop infrastructure (VDI) in a hosted environment. This allows users to access what looks like a desktop operating system (Windows or Mac) that is actually running on a common server. The user can fully customize their environment, but rather than having it all on a laptop (which can be lost, stolen, or broken), the user can connect to the VDI from any machine.

### Promotion of Standardization
This is because the VMs only see what CPU is on the host. Therefore, the host server hardware can vary, as it often will, but the VM will always be a standard image across all the servers regardless of the underlying hardware.

### Management
VM administration tools also facilitate the creation and management of VM instances. This is because unlike conventional servers, which are a collection of hardware, OS, drivers, and application files, a VM exists as a single file. This is why, as described earlier, a VM can be so easily migrated to other locations using a simple file copy or move.
