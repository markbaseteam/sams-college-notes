```toc
```
## Understanding SDN
If we take a simplified view of SDN, we can think of it as really just an extensible networking control system that allows separate applications to control the forwarding plane of network hardware through a defined API. It effectively pulls network intelligence out of the many network devices and places it in the hands of a central authority. In the military example earlier, SDN is the mechanism that lets the general give an order to all the troops at once instead of letting an order trickle through the ranks slowly and randomly.

### The Application Layer
As the name suggests, this layer includes the network applications. These can include communication applications such as VoIP prioritization, security applications such as firewalls, and many others. This layer also includes network services and utilities.

In traditional networks, these applications were handled by the switches and routers. SDN allows us to offload them, making them easier to manage. It also means that the hardware can be stripped down, saving companies a lot of money on networking gear

### The Control Layer
What used to be the control plane of the switches and routers is now centralized. This allows for a programmable network. OpenFlow is an open source network protocol that the industry seems to have settled on, although the big network vendors (such as Cisco) have their own variants.

### The Infrastructure Layer
This layer includes the physical switches and routers and the data. Traffic is moved based on flow tables. This layer is largely unchanged in SDN because the routers and the switches are still moving packets around. The big difference is that the traffic flow rules are managed centrally. This is not to say that the actual intelligence is stripped out of vendor devices. In fact, many of the big network providers accommodate SDN centralized control via an application programming interface (API) to protect their intellectual property. That said, it is possible to use generic packet forwarding devices built specifically for SDN at a much lower cost than traditional networking gear.

## So What’s the “So What?”
The big takeaway here is that SDN makes it really easy (well, much easier than it used to be) for network operators to provide customized, isolated services for individuals that use the network. With SDN, the _network owners_ have all (or at least most) of the power and control by gaining the ability to customize their networks. For example, they can get rid of features they don’t use; quickly and easily isolate parts of their networks (or users or types of traffic) from other parts or users or types for efficiency, performance, and security; or create customized applications. Again, the key here is centralized control and programmability.

It’s also a good bet that SDN will result in an increased rate of innovation. (It’s well known that if you let users create applications, they will...in fact they will create lots of them.) Chances are this will result in some real breakthroughs, too; it should be an exciting time for networking. It’s worth noting that this will not diminish the value of the large vendors creating applications. It will actually add to it, and it will help the vendors be more innovative as well. This is a case where more is more and it’s also better. From a cloud networking perspective, network virtualization in the form of SDN will accelerate cloud providers almost as much as server virtualization has.

As shown in [Figure 21-5](https://learning-oreilly-com.libaccess.senecacollege.ca/library/view/sdn-and-nfv/9780134307398/ch21.html#ch21fig05), with SDN the entire network can be virtualized. The use of centralized controller software (such as OpenFlow) allows programmable control of how VMs connected with each other or with users. It also allows logical (and location independent) groupings to be created quickly and easily. This is something that was complex, slow, and error prone in traditional networks where device-by-device configuration was required.

![[Pasted image 20221003144439.png]]

**Figure 21-5** _SDN allows programmable control of how VMs connect with each other or with users. It also allows logical (and location independent) groupings to be created quickly and easily._

The really big takeaway, though, is that SDN will make networking a lot less complex, which will also make networks faster, more reliable, more agile, and more secure. No one intended for current models of networking to become massively complex and generally at odds with the way that the customers want to use and move data around. The reality is that networking based on distributed control, intertwined hardware-software systems, and stacked code bases is approaching the end of its useful life. SDN, with its centralized control, virtualized applications, and programmable networks, has emerged to take us into the next golden era of networking.

![[Pasted image 20221003144424.png]]