```toc
```
## A Brief Review of Networking
### Control Planes and Forwarding Planes
> [!NOTE] Control Pane
> where the intelligence of the device lies. It is here where all the instructions (in the form of applications and large tables of rules) are stored. 

> [!note] Forwarding Plane
> where packets are moved from one network interface on the machine to one of the many other network interfaces on the machine. 
- You can think of the control plane as the brain and the forwarding plane as the muscle.

### The Cost of Complexity
> [!note] OSPF
> OSPF creates a set of rules that tells a device what the next best path is to get traffic to its final destination and each point throughout the network. _Best_ in this case is a relative term (it could be based on speed or number of devices, and so on), and it is based on “link state,” which means that the map it creates is constantly changing based on any number of factors that could impact the millions of combinations of connections between any two points on the network.

> [!note] **Dijkstra's algorithm**
> an [algorithm](https://www.wikiwand.com/en/Algorithm "Algorithm") for finding the [shortest paths](https://www.wikiwand.com/en/Shortest_path_problem "Shortest path problem") between [nodes](https://www.wikiwand.com/en/Vertex_(graph_theory) "Vertex (graph theory)") in a [graph](https://www.wikiwand.com/en/Graph_(abstract_data_type) "Graph (abstract data type)"), which may represent, for example, [road networks](https://www.wikiwand.com/en/Road_network "Road network"). It was conceived by [computer scientist](https://www.wikiwand.com/en/Computer_scientist) [Edsger W. Dijkstra](https://www.wikiwand.com/en/Edsger_W._Dijkstra "Edsger W. Dijkstra") in 1956 and published three years later.