## Part 1
```ccard
type: folder_brief_live
folder: 'Courses/Y3 S1/CSN305/Study Notes/Test 1/Part 1'
imagePrefix: 'Embeds & Templates/Images/Y3 S1\Diagrams & Tables/Study Note Images/Part 1/'
```

## Part 2
```ccard
type: folder_brief_live
folder: 'Courses/Y3 S1/CSN305/Study Notes/Test 1/Part 2'
imagePrefix: 'Embeds & Templates/Images/Y3 S1\Diagrams & Tables/Study Note Images/Part 1/'
```

## Part 3
```ccard
type: folder_brief_live
folder: 'Courses/Y3 S1/CSN305/Study Notes/Test 1/Part 3'
imagePrefix: 'Embeds & Templates/Images/Y3 S1\Diagrams & Tables/Study Note Images/Part 1/'
```

## Part 5
```ccard
type: folder_brief_live
folder: 'Courses/Y3 S1/CSN305/Study Notes/Test 1/Part 5'
imagePrefix: 'Embeds & Templates/Images/Y3 S1\Diagrams & Tables/Study Note Images/Part 1/'
```
