```toc
```
## VMware Product Design
- VMware has been producing their hypervisors aimed at the server market since 2001 with the launch of the VMware GSX server (type 2) and the ESX Server (type 1) hypervisor products.
- VMware has an extensive product line, but this chapter covers only the enterprise VMware vSphere product. This enterprise-class product, sometimes known as ESXi, is a higher-performance hypervisor that easily outmuscles its sibling, the freeware version VMware Server.
### vSphere
VSphere is designed as a data center server product, and it leverages the power of virtualization to transform conventional computing architectures into simplified virtualized infrastructures or private clouds. The vCenter Server product (part of the VSphere family) provides a single point of control and management for data centers. VMware vSphere is best understood as a product if we think back to an earlier definition of a hypervisor as an operating system for an operating system. Being a bare-metal hypervisor, it is an operating system that manages a dynamic operating environment such as a data center.

The components that comprise vSphere are as follows:
- Infrastructure services, which provide abstraction, aggregation, and they allocate hardware resources, through the component, vCompute, vStorage, and vNetwork services.
- Application services, which are high-availability and fault-tolerance services that provide availability, security, and scalability to applications.
- Clients, in which IT administrative users access vSphere through clients such as a vSphere client or a web access through a browser.

### VMotion
- A stunning feature of vSphere is vMotion, which permits an active VM to be migrated live across a network to another physical server in a way that is completely transparent to the users.
- VMotion (see [Figure 8-2](https://learning-oreilly-com.libaccess.senecacollege.ca/library/view/sdn-and-nfv/9780134307398/ch08.html#ch08fig02)) also supports storage vMotion moving virtual disks or configuration files of a powered up VM to a new data store. Migration using vMotion storage allows an administrator to move a VM’s storage without any interruption in the availability of the VM. It is important to note that a frozen or suspended VM can be moved across data centers, but an active VM can only be moved within a data center.

## VXLAN
- VXLAN is a close relative of the humble VLAN, which is itself a virtualization protocol used to create virtual Layer 2 LAN segments across the common physical network media, such as Ethernet or air interface. VXLAN provides the same services and purpose as VLANs, but it has been given extensions to enable it to address some common VLAN failings.
- One of VLAN’s biggest failings is that when the protocol was created the VLAN ID was only assigned 8 bits, which meant it could only address 4096 unique VLANs.
	- when redesigning protocols for virtualization, the VXLAN addressing scheme has been given 24 address bits, giving it a possible identifier range of up to 16 million VXLAN identifiers.
- VXLAN also provides better utilization of available network paths in the underlying infrastructure.
	- Spanning Tree Protocol, however, has the undesirable effect of shutting down a lot of ports to prevent them forwarding messages over paths that could form a potential loop. In contrast, VXLAN uses a Layer 3 header, which also means it can be routed and take advantage of equal-cost multipath routing and link-aggregation protocols to make the best use of all available paths without the potential for broadcast storms.
- VXLAN is a Layer 2 overlay scheme over a Layer 3 network.

### VXLAN Tunnel Endpoints
VXLAN uses VTEP (VXLAN Tunnel EndPoints) devices to map tenants and end devices to VXLAN segments and to perform encapsulation/decapsulation. As shown in [Figure 8-3](https://learning-oreilly-com.libaccess.senecacollege.ca/library/view/sdn-and-nfv/9780134307398/ch08.html#ch08fig03), each VTEP has two interfaces: a switch port on the local LAN network and an interface on the transport IP network.

![[Pasted image 20220930005100.png]]
**Figure 8-3** _VXLAN Tunnel EndPoints (VTEP) map tenants and end devices over VXLAN segments._

The IP interface has a unique IP address that identifies the VTEP device on the transport IP network, also known as the infrastructure VLAN. The VTEP uses this IP address to encapsulate Ethernet frames and transmit them through the IP interface and over the IP transport network. Furthermore, a VTEP device discovers remote VTEPs for its VXLAN segment and learns the remote MAC Address to VTEP mappings.

## Summary
VMware has brought a number of products to market that help manage very large-scale virtualized environments, and that’s the real takeaway here. These products are interesting and well designed, but they were all borne out of necessity due to the explosive scaling of virtualized data centers and clouds. Whereas early data centers were predicated on efficient movement of traffic, modern data centers must also account for orchestration on a grand scale.