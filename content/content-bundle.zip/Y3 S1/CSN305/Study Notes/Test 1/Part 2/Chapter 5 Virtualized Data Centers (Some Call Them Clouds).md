```toc
```
## Benefits of Virtualizing the Data Center
### Less Heat Buildup 
- Less wasted energy leads to considerable savings in operation costs.
- The answer to this is simply to reduce the number of servers.
- This is a tricky one for IT departments within an organization because usually IT does not have direct responsibility for facility costs such as power. In these cases, the finance team has to estimate the data center’s power consumption costs relative to the rest of the organization. For a hosting company, it’s much easier because most of the facilities are used specifically to run the servers.
### Reduced Hardware Spend
- Another benefit of reducing the number of servers in the data center is the reduction in server sprawl, which results in less spend on new and replacement hardware. Fewer servers require less electricity and a reduction in rack space. Reducing the number of servers reduces capital and operational costs as maintenance and support costs drop.
- This cost saving can be limited, however, because these servers are often replaced with much larger (more expensive) servers, and they also require more bandwidth, which increases networking costs and storage costs.
### Other Benefits
- Faster Deployment
- Testing and Development
- ==Faster Redeploy==
	  An administrator can configure VMs to start automatically, start manually, or can copy them over to a new location in a matter of seconds; this makes fast service recovery a key benefit.
- ==Easier Backups==
	  with VMs, backing up using full and snapshot backups makes life much easier, and restoring from backups is also easier.
- ==Disaster Recovery==
	  VMs provide the ability to ensure business continuity in a disaster scenario, because operational VMs can be migrated live across WAN links to another location without any downtime or loss of data.
- ==Server Standardization==
	  VMs don’t really care what hardware they run on, as the level of abstraction removes that dependence on individual hardware specifications. This allows companies to avoid vendor lock in because the VMs will run on any make of server. Many large hosting providers even go so far as to specify their own servers from hardware manufacturers to avoid vendors altogether.
- Separation of Services
- ==Easier Migration to the Cloud==
	  Virtualization in the data center prepares the mindset for eventual migration to an all-cloud environment. This can be a big shift for companies because migrating to a third-party cloud can offer significant cost savings. This is especially the case for companies whose usage is “bursty” (for example, retail companies that have a massive jump in server utilization during the holidays).

## The Five Cloud Attributes
The hard part of defining a cloud is that the word has been overused and even abused during the hype cycle that accompanied the investment and build-out of data center virtualization. Rather than go with a strict definition, it’s more instructive to instead focus on the attributes.

The five attributes of clouds were originally outlined by the National Institute for Science and Technology (NIST) and have largely been adopted (or at least recognized) by the rest of the industry. The five attributes are as follows:

1. On-demand self-service
	 a client (which can be a person or a company) can provision computing resources from the cloud without having to interact with IT or service provider personnel. In other words, you can order it online by clicking buttons (without a salesperson trying to meet you for lunch).
2. Ubiquitous network access 
	you should be able to connect to the cloud from wherever you are with whatever you have.
3. Pay per use (metered usage)
	The cloud is, generally speaking, a pay per use model. This attribute is a bit hard to pin down because some clients may want or need a fully private cloud (as explained later). Private clouds require a fixed monthly payment because, by definition, another client could not use the same resources even if they were idle.
4. Rapid elasticity
	Elasticity is probably the one characteristic that most people refer to when describing a cloud. Accomplished via automation and application programming interfaces (APIs), elasticity is the ability to very rapidly (or even instantly) “spin up” computing resources for a short while or to accommodate an event and then spin it all back down (just as easily) when you no longer need it.
5. Location-independent resource pooling
	Resource pooling is where many of the advantages of cloud networking are derived from. As the name suggests, the cloud provider has different types of grouped resources, including storage, memory, computer processing, and bandwidth (just to name a few), which instead of being dedicated to any one client are allocated to clients as they need them. Rather than having a dedicated resource allocated to a user, the cloud model allows clients to draw resources from functional pools as needed.

## Types of Clouds
| Type of Cloud | Description |
| ------------- | ----------- |
| Software as a service (SaaS) | The provider offers an application that clients connect to over the network. |
| Infrastructure as a service (IaaS) | The provider offers processing, storage, and other computing resources in a manner that has the attributes listed earlier. | 
| Platform as a service (PaaS) | The provider offers the ability to run applications that they have created themselves. |

^257f91

## Cloud Deployment Models
| Cloud Deployment Model | Description                                                                                                                                                                                                                                                                                                                                         |
| ---------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Private Clouds         | The first step that most enterprises take toward cloud adoption is the virtualization of their existing data centers. A private cloud is created when an enterprise data center is reconfigured in such a way as to provide the five attributes                                                                                                     |
| Public Clouds          | It’s open to anyone and everyone who has connectivity and a credit card (or some remote method of payment).                                                                                                                                                                                                                                         |
| Community Clouds       | a community or multitenant cloud is run by a service provider that hosts services for a select group of customers, almost always businesses (as opposed to  individuals). The various tenants are likely sharing common resources, but the service is not public in the sense that just anyone can access these cloud resources any time they want. |
| Hybrid Clouds          | some providers offer administrative control over multiple cloud platforms (private or public) that can be managed through a single interface. This allows seamless access to both cloud environments.                                                                                                                                               |