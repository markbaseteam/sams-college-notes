```toc
```
## Networking in Traditional Data Centers
- The user’s application call will point to an address associated with the server where the application resides. Data centers were traditionally designed in a hierarchical network model that consists of a core, an aggregation layer, and an access layer, which ensures that data is collected, aggregated, and then transported at high speed to its final destination.
  ![[Pasted image 20220929231109.png]]
- However, at this point, we are dealing with an incoming request so that the application call’s IP packets, which are destined for our application server, will arrive via a router connected to the core. The incoming packets will be fast routed through the core, to the high-port-density access switches via the aggregation layer. At the access layer, the packets will be examined for the destination address, and they will be fast switched across the wire to the required server (based on that server’s unique address) where the destination application is running.
- It’s worth noting here that data center designs were based on these factors, and the three-layer design was implemented specifically to optimize “north-south” traffic flows. That is to say there was very little traffic from server to server. Most traffic was from a server to a client outside of the data center (or vice versa), so data center networks were designed to optimize that traffic flow.

## Virtualized Data Center Design
There are two key pieces to making this all work. The first is figuring out how to establish and maintain addressing when the VMs are both sharing common physical devices yet are prone to moving from session to session; and the second is changing the physical layout and performance characteristics of the data center networking devices to better accommodate the new requirements.

## Addressing with Virtual Machines
The key point here is that each host needs both a MAC (Layer 2) address and an IP (Layer 3 address). For physical devices, unique MAC address are assigned by manufacturers as devices come off the assembly line. This makes Layer 2 addresses easy for the network engineer. Layer 3 addresses, however, are assigned by network engineers, which can be cumbersome when done all at once, but generally they do not change.

In the absence of factory assigned MAC address allocation, VM software such as VMSphere or Citrix provides a unique MAC address for each VM created. These VM managers also assign a virtual NIC (vNIC) or multiple vNICs; you’ll recall that the NIC is a specific piece of equipment within a device that uses the MAC address.