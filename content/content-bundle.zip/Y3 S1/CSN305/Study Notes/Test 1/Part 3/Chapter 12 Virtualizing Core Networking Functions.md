```toc
```
## Virtualization Recap
- In the early 2000s, IT introduced virtualization into the organization using the VMware desktop, and later when confidence had grown, around the mid 2000s, into the data center through the implementation of server virtualization.
- early server virtualization though very successful only hinted at the true potential of VMs. If only they could be untethered from the conventional network, they would be capable of doing wonderful things.
- Network virtualization (NV) in IT data centers was the next logical step in the virtualization evolution. After all, server virtualization had proven to be a highly beneficial technology, delivering cost savings, agility, flexibility, and very importantly, scalability. In fact, scalability was one of the most important aspects of server virtualization because it consolidated servers and stopped the unsustainable server spread inherent in the conventional network architecture.
- this made the reality of massively scalable data centers possible

## Where Core Functions Are Being Virtualized
- Enterprises and application providers are the primary drivers of server and appliance virtualization, but it is the service providers who are looking to use network virtualization to build dynamic, virtualized core networks that meet the growing demands of users.
- The benefits to the mobile operator realized by deploying network functions virtualization are as follows:
	- Lower capital expenditure
	- Lower operational expenditure
	- Increased flexibility
	- Reduced time to market