```toc
```
## Scalability Versus Performance
- The administrator’s ambition is to be able to easily and quickly spin up virtual servers. The planner’s goal is to reduce the number of physical servers and future deployment times. Ironically, virtualization can often make the problems they are implemented to solve worse.

## Performance in Network Virtualization
- There are inherent performance issues with network virtualization that go way beyond VM density issues and network card overutilization. A virtualized environment must allow unlimited migration of VM workloads across physical servers. Furthermore, virtualization is often utilized in multitenant environments (cloud services) that require provisioning resources across diverse geographic locations. A virtualized network must therefore be able to scale while maintaining the quality of service (QoS) customers require. Consequently, a virtualized network must accomplish the following:
	- Handle vast numbers of MAC addresses and explosive growth in VMs
	- Accommodate large numbers of LANs (4096—the old VLAN limit isn’t going to cut it)
	- Provide isolation of the physical Layer 2 network so that each tenant has the illusion of being on their own physical network without any performance overhead

## Scalability and Performance for Virtual Appliances
- Examples of this include high-speed routing, packet forwarding, and encryption. Packaging these functions in software (even when installed on high-performance x86 servers) isn’t going to replicate the wire-speed performance of the dedicated silicon. Perhaps this is why most of the network functions decoupled from the devices are for firewall or load-balancing types of applications that can be handled via CPU cycles in software. The key point is that some network services are okay to run as software applications running on generic (albeit powerful) servers, but if wire-speed performance matters, there’s still no substitute for dedicated hardware designed specifically for the task at hand.

## Summary
This chapter covered a lot of downsides and cautions. This is not to detract from the power or goodness of virtualization in its many formats. Rather, it’s a reminder that virtualization is not always the right solution, and even when it is the right solution, not taking user behavior into account can often have disastrous results. It should be obvious that if you build a system that allows users to spin up an application with the click of a button, there will be an awful lot of button clicking, but designers miss this all the time. Systems that are fast and easy to deploy won’t just make it easy to deploy, they will also make it more enticing—which means that demand will usually skyrocket. If there is one big takeaway to virtualization, it’s this: It is best to plan for a massive uptake rather than the current rate of consumption.