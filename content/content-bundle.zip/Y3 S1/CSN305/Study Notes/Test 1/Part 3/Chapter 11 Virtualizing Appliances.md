```toc
```
## Layer 4 Through 7 Network Services
- One of the issues with the dynamic nature of server virtualization is that all that spinning up, spinning down, and movement of VMs is really difficult to manage in terms of connecting them to network services.
- Examples of Layer 4 through 7 services include the following:
	- Data loss prevention systems
	- Firewalls and intrusion detection systems (IDS)
	- Load balancers
	- Security event and information managers (SEIM)
	- Secure Sockets Layer (SSL) accelerators
	- Virtual private network (VPN) concentrators 
### Firewalls
_Firewalls_ allow traffic from authorized users but block others. Firewalls can be located at the edge of the data center, but can also be located close to the server. There has been a shift in recent years to application-aware firewalls, which give network administrators better visibility and control over security.

### VPNs
Virtual private networks logically segment/isolate user traffic within the network (over the WAN). This allows many users to privately share a common infrastructure without mixing traffic. In some cases, VPNs encrypt traffic between the user and the application, which is important when traffic traverses the public Internet. If you’ve ever been to a coffee shop, about half of those people (the smart ones anyway) are using a secure VPN to connect back to their corporate office.

### SSL Offload
Secure Sockets Layer is a web-based encryption tool. SSL has become very popular because it provides security of web-based data streams without user intervention. The SSL offload service provides a termination point for encryption.

### Load Balancer
Load balancers direct and spread user traffic coming into the data center or cloud. Load balancing is a way to control the flow of traffic as applications scale up and down. There is an important distinction in the cloud, however: In the “old days,” scalability meant growing over time (months and years). In the cloud, scalability means scale up or scale down right now, and the expectation is that it scales in a way that does not impact service quality. What was once an architectural consideration (you designed the network so that you could scale it later) is now an automatic function enacting real-time changes.

----
## What’s the “So What”?
Application architectures are scaling, and application services need to match the scale and automation of VMs to ensure efficient operations and user satisfaction. The best way to achieve this is to virtualize Layer 4 through 7 services and make them part of the same fabric as the applications they support. This also means that Layer 4 through 7 services must now be statefully aware of the application traffic to ensure that they scale along with VMs as they grow, retract, and move throughout the cloud infrastructure.