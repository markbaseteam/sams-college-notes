<center><h1>Lab 5</h1></center>

**Name:** Sam Greenwood
**Student Number:** 102608195

==**VM IPs:**==
| Mininet | Ubuntu |
| ------- | ------ |
| 192.168.218.128 <br> ![[Pasted image 20221207175200.png]]     | 192.168.218.129 <br> ![[Ubuntu VM IP.png]] | 

**==ODL Dashboard:==**
![[ODL Dashboard.png]]
## Mininet Setup
| Create Network | pingall |
| -------------- | ------- |
| ![[Pasted image 20221207180532.png]] | ![[Pasted image 20221207180954.png]] |
## Topology
![[Pasted image 20221207181208.png]]