```ccard
items: [
  {
    title: 'Lab 3',
    link: 'Courses/Y3 S1/CSN305/Labs/Lab 3.md',
    foot: '11/22/2022, 10:03:15 PM',
    head: 'Note'
  },
  {
    title: 'Lab 4',
    link: 'Courses/Y3 S1/CSN305/Labs/Lab 4/Lab 4.md',
    brief: 'Contains 0 folders, 2 notes.',
    foot: 'Lab 4',
    head: 'Note'
  },

  {
    title: 'Lab 5',
    link: 'Courses/Y3 S1/CSN305/Labs/Lab 5.md',
    brief: 'Lab 5',
    foot: '12/7/2022, 6:17:46 PM',
    head: 'Note'
  },
  {
	title: 'Lab 6',
	link: 'Courses/Y3 S1/CSN305/Labs/Lab 6.md',
    foot: '12/7/2022, 7:32:25 PM',
    head: 'Note'
  },
  {
    title: 'PreLab',
    link: 'Courses/Y3 S1/CSN305/Labs/PreLab.md',
    foot: '9/13/2022, 9:59:27 PM',
    head: 'Note'
  }
]
```
