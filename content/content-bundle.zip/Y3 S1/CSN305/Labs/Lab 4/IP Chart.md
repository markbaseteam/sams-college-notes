-tx-
|        **Device**         | **Interface**         | **Address / Mask** |  **Gateway** |     | 
| ------------------------- | --------------------- | ---------------- | ------------| :---: |
||||| ==WAN== | 
| ON-Router 1 | GigabitEthernet 0/0/0 | 10.0.0.1 /30       |          N/A |     |
| QC-Router 1 | GigabitEthernet 0/0/0 | 10.0.0.2 /30       |          N/A |     |
||||| ==Ontario== |
|        ON-Router 1        | GigabitEthernet 0/0/1 | 192.168.95.1 /24   |          N/A |     |
|        ON-TO-DSW1         | VLAN 1                | 192.168.95.2 /24   | 192.168.95.1 |     |
|        ON-TO-ASW1         | VLAN 1                | 192.168.95.3 /24   | 192.168.95.1 |     |
|        ON-MA-ASW2         | VLAN 1                | 192.168.95.4 /24   | 192.168.95.1 |     |
|         DNSSever          | FastEthernet0         | 192.168.95.254     | 192.168.95.1 |     |
|          AdminPC          | FastEthernet0         | 192.168.95.10      | 192.168.95.1 |     |
|        ON-UserPC1         | FastEthernet0         | 192.168.95.11      | 192.168.95.1 |     |
|||||==Quebec==|
|        QC-Router 1        | GigabitEthernet 0/0/1 | 172.16.95.1 /16    |          N/A |     |
|        QC-MT-DSW1         | VLAN 1                | 172.16.95.2 /16    |  172.16.95.1 |     |
|        QC-MT-ASW1         | VLAN 1                | 172.16.95.3 /16    |  172.16.95.1 |     |
|        QC-QC-ASW1         | VLAN 1                | 172.16.95.4 /16    |  172.16.95.1 |     |
|        QC-UserLT1         | FastEthernet0         | 172.16.95.10 /16   |  172.16.95.1 |     |
|          QC-PR1           | FastEthernet0         | 172.16.95.11 /16   |  172.16.95.1 |     |
|          QC-SP1           | Wireless0             | 172.16.95.12 /16   |  172.16.95.1 |     |
|          QC-TB1           | Wireless0             | 172.16.95.13 /16   |  172.16.95.1 |     |
| CSN305 Network Controller | GigabitEthernet0      | 172.16.95.254 /16  |  172.16.95.1 |     |
^2c19ad