<center><h1>Lab 4</h1></center>

**Name:** Sam Greenwood
**Student Number:** 102608195

%%
```toc
	varied_style:true
```
%%
## Part A
%%
### **==Address Table:==**
![[IP Chart]]
%%
### **==Pings:==**
| ON-QC                                | QC-ON                                |
| ------------------------------------ | ------------------------------------ |
| ![[Pasted image 20221029151218.png]] | ![[Pasted image 20221029144904.png]] |

## **==Topology==**
![[Pasted image 20221029151111.png]]

## Part B
### **==Discovered Devices==**
![[Pasted image 20221029162405.png]]

### **==Network Devices Tab==**
![[Pasted image 20221029162534.png]]

### **==Discovered Topology:==**
![[Pasted image 20221111143324.png]]
## Part C



### **==TO QoS:==**
| DSW1                                 | TO-ASW1                              | MA-ASW1                              |
| ------------------------------------ | ------------------------------------ | ------------------------------------ |
| ![[Pasted image 20221111144907.png]] | ![[Pasted image 20221111144955.png]] | ![[Pasted image 20221111145042.png]] |

### **==Router:==**
![[Pasted image 20221111145725.png]]