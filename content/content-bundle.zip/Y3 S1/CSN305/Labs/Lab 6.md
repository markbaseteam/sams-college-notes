<center><h1>Lab 6</h1></center>

**Name:** Sam Greenwood
**Student Number:** 102608195

![[Pasted image 20221207190859.png]]

Suppose we want the following forwarding behavior of packets to be implemented:
- Packets coming from the source network attached to s3 and destined to the network attached to s2 should be forwarded along the path: s3 -> s2.

| Question                                                                                                               | Answer     |
| ---------------------------------------------------------------------------------------------------------------------- | ---------- |
| For router s2, what should the value of the 'IP Src' be? Pick either a specific address (including CIDR), any, or none | 128.121/16 |
| For router s2, what should the value of the 'IP Dst' be? Pick either a specific address (including CIDR), any, or none | 128.120/16 |
| For router s2, what should the value of the 'Src Port' be? Pick either a specific port, or any                         | any        |
| For router s2, what should the value of the 'Dst Port' be? Pick either a specific port, or any                         | any        |
| For router s2, what should the value of the 'IP Proto' be? Pick either TCP, UDP, or any                                | any        |
| For router s2, what should the action of the rule be? Some examples include forward, allow, deny, etc                  | forward    |
| For router s2, what interface should the packets be forwarded to? | 1 | 
| For router s3, what should the value of the 'IP Src' be? Pick either a specific address (including CIDR), any, or none | 128.121/16 | 
| For router s3, what should the value of the 'IP Dst' be? Pick either a specific address (including CIDR), any, or none | 128.120/16 | 
| For router s3, what should the value of the 'Src Port' be? Pick either a specific port, or any | any |  
| For router s3, what should the value of the 'Dst Port' be? Pick either a specific port, or any | any | 
| For router s3, what should the value of the 'IP Proto' be? Pick either TCP, UDP, or any |  any | 
| For router s3, what should the action of the rule be? Some examples include forward, allow, deny, etc | forward | 
| For router s3, what interface should the packets be forwarded to? | 4 | 
   