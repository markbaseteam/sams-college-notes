<center><h1>PreLab</h1></center>

**Name:** Sam Greenwood
**Student Number:** 102608195

**==Cloudpaging Player:==**
![[Cloudpaging Player.png]]


**==Media Settings:==**
![[Pasted image 20220913204728.png]]
<p>* I'm using VMWare because I've been having issues with vbox VMs randomly freezing and that doesn't seem to happen in VMWare. </p>

**==System Name Changed:==**
![[System Name.png]]

**==Cloned VMs:==**
![[Pasted image 20220913215907.png]]
