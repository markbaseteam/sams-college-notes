<center><h1>Lab 3</h1></center>

**Name:** Sam Greenwood
**Student Number:** 102608195

> [!NOTE]
> I couldn't connect to the server via PuTTY so the requsite screenshot isn't present.

## **==VPC:==**
![[VPC.png]]

## **==Subnets:==**
![[Subnets.png]]

## **==Instances:==**
![[Instances.png]]

## **==Internet Gateway:==**
![[Internet Gateway.png]]

## **==Routing Table:==**
![[Routing Tables.png]]

## **==Scecurity Groups:==**
![[Security Group Rules.png]]

## **==Pings Successful:==**
![[Embeds & Templates/Images/Y3 S1/VM Screenshots/OPS345/Pasted image 20221027182025.png]]