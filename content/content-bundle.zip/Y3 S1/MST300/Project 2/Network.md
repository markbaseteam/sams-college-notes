|                   | Name               | Virtual Network | Subnet             | Public IP address name | Image                          | Size         |
| ----------------- | ------------------ | --------------- | ------------------ | ---------------------- | ------------------------------ | ------------ |
| **Bastion** | MST300-BastionHost | MST300-vnet1 | AzureBastionSubnet | MST300-BastionIP | N/A | N/A |
| **Webserver** 1 | webserver1-vm | MST300-vnet1 | vnet1-subnet1 | None | Windows Server 2019 Datacenter | Standard_B1s |
| **Webserver** 2 | webserver2-vm | MST300-vnet1 | vnet1-subnet1 | None | Windows Server 2019 Datacenter | Standard_B1s |
| **Client** | client-vm | MST300-vnet2 | vnet2-subnet1 | None | Win10 Pro 20H2 |              |

## Load Balancer
|                  |                       |                        |
|:----------------:| --------------------- | ---------------------- |
|                  | Name | MST300-lb |
|                  | Type | Internal |
|                  | Virtual network | MST300-vnet1 |
|                  | Subnet | vnet1-subnet1 |
|                  | **Backend Pool** Name | **MST300-BackendPool** |
| **Health Probe** |||
| | Name | MST300-HealthProbe |
| | Protocol | HTTP |
| | Port | 80 | 
| | Interval | 15 | 
| | Unhealthy threshold | 3 |
