<center><h1>Lab 16</h1></center>

**Name:** Sam Greenwood
**Student Number:** 102608195
Date: 2022-11-20

![[Pasted image 20221120115850.png]]