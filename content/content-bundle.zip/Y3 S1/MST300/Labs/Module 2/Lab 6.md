<center><h1>Lab 6</h1></center>

**Name:** Sam Greenwood
**Student Number:** 102608195
Date: 2022-11-10

![[DB Qurey.png]]