<center><h1> Lab 1</h1></center>

**Name:** Sam Greenwood
**Student Number:** 102608195

![[Lab 1 Screenshot.png]]
