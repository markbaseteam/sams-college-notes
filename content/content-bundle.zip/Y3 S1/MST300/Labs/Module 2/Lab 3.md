<center><h1>Lab 3</h1></center>

**Name:** Sam Greenwood
**Student Number:** 102608195

> [!NOTE]
> This lab is using a different account than the other labs becuase I'm retaking this class and was unable to do this lab because threre was an issue that I don't remember the details of.

**==Container Webpage:==**
![[Pasted image 20220920163723.png]]

**==Resource Group:==**
![[Pasted image 20220920163841.png]]
