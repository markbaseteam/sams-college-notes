<center><h1>Lab 8</h1></center>

**Name:** Sam Greenwood
**Student Number:** 102608195
Date: 2022-11-10

**==httptrigger output:==**
![[httptrigger output.png]]

**==Portal:==**
![[httpTrigger (Portal).png]]