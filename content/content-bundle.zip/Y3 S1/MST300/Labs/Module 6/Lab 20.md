<center><h1>Lab 20</h1></center>

**Name:** Sam Greenwood
**Student Number:** 102608195

![[Pasted image 20220412152903.png]]