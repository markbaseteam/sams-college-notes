|                   | Name | Virtual Network | Subnet | Public IP address name | Image | Size |
| ----------------- | ------------------ | --------------- | ------------------ | ---------------------- | ------------------------------ | ------------ |
| **Bastion** | MST300-BastionHost | MST300-vnet1 | AzureBastionSubnet | MST300-BastionIP | N/A | N/A |
| **Domain Controller** | dc-vm | MST300-vnet1 | vnet1-subnet1 | None | Windows Server 2019 Datacenter | Standard_B1s |
| **Webserver** | webserver-vm | MST300-vnet2 | vnet2-subnet1 | None | Windows Server 2019 Datacenter | Standard_B1s |
| **Client** | client-vm | MST300-vnet3 | vnet3-subnet1 | None | Win10 Pro 20H2 |              |

## Domain
Name: **studentID.MST300.com**

| User              | Role                  |
| ----------------- | --------------------- |
| sgreenwood3.admin | Domain Administrators |
| sgreenwood3       | Domain Users          |


•Reactive Flow Entries: