<center><h1>Project 1</h1></center>

**Name:** Sam Greenwood
**Student Number:** 102608195

## VNets
**==VNet1:==**
![[Pasted image 20221124163637.png]]

**==Vnet2 & 3:==**

| VNet2 | VNet3 |
| ------------------------------------ | ------------------------------------ |
| ![[Pasted image 20221124164006.png]] | ![[Pasted image 20221124163956.png]] |
| ![[Pasted image 20221124170231.png]]  | ![[Pasted image 20221124170636.png]]                                     |
## Bastion
**==Bastion Host:==**
![[Pasted image 20221124164302.png]]
## VMs
**==Domain Controller VM==**
![[Pasted image 20221124171214.png]]

**==Webserver VM==**
![[Pasted image 20221124171153.png]]

**==Client VM==**


==**AD User Creation**==
![[Pasted image 20221126162124.png]]

