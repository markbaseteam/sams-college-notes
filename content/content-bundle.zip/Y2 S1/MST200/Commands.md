## Lec 6
### Printing
| Action                                                     | Command                                                                                             |
| ---------------------------------------------------------- | --------------------------------------------------------------------------------------------------- |
| List all cmdlets in the PrintManagement module             | `Get-Command –Module PrintManagement`                                                               |
| List Installed Printers on a Print Server                  | `Get-Printer`                                                                                       |
| To display only a list of shared printers, use the command | `"Get-Printer -ComputerName MTS-prnt1 | where Shared -eq $true | fl Name"`                          |
| To add a printer to a local computer                       | `Add-Printer -Name "mxdw 2" -DriverName "Microsoft XPS Document Writer v4" -PortName "portprompt:“` |
| To add a networked printer connection                      | `Add-Printer -ConnectionName \\printServer\printerName`                                             |
| To add a printer driver                                    | `Add-PrinterDriver -Name "HP Color LaserJet 5550 PS Class Driver”`                                  |
| To create a TCP printer port                               | `Add-PrinterPort -Name "TCPPort:" -PrinterHostAddress "192.168.100.100“`                            |
| Get the information for a specific printer                 | `Get-Printer -Name "Microsoft XPS Document Writer"`                                                 |

## Lec 7
### DHCP Installation
| Command                                      | Function                                                                |
| -------------------------------------------- | ----------------------------------------------------------------------- |
| To install the DHCP Role                     | Install-WindowsFeature DHCP –IncludeManagementTools                     |
| To create the DHCP Security Groups           | netsh dhcp add securitygroups                                           |
| restart DHCP Service                         | Restart-Service dhcpserver                                              |
| To authorize this DHCP server in your domain | Add-DhcpServerInDC -DnsName Server1.SenecaID.com -IPAddress 10.0.100.10 |

### Scope Setup
| Function                      | Command                                                                                                    |     |                                               |                                                                                                                          |
| ----------------------------- | ---------------------------------------------------------------------------------------------------------- | --- | --------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------ |
| Add the Exclusions            | Add-DhcpServerv4ExclusionRange -ScopeID 10.0.0.0 -StartRange 10.0.0.1 -EndRange 10.0.0.15                  |     |                                               |                                                                                                                          |
| Configure the default gateway | Set-DhcpServerv4OptionValue -OptionID 3 -Value 10.0.0.1 -ScopeID 10.0.0.0 -ComputerName DHCP1.SenecaID.com |     |                                               |                                                                                                                          |
| Configure DNS Server          | Set-DhcpServerv4OptionValue -DnsDomain SenecaID.com -DnsServer 10.0.0.2                                    |     | Create a scope and set the range of addresses | Add-DhcpServerv4Scope -name “TheScope" -StartRange 10.0.0.1 -EndRange 10.0.0.254 -SubnetMask 255.255.255.0 -State Active |

### DNS Installation
| Function | Command |
| ----------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------ |
| To install the DNS role (separate from ADDS) | `Install-WindowsFeature -Name DNS -IncludeAllSubFeature –IncludeManagementTools` |
| Run the following command to retrieve a list of all PowerShell DNS functions: | <p> `Get-Command -Module DNSServer | Select-Object -Property Name` </p> |
| Use Get-DNSServer to retrieve the local server's configuration data | `Get-DnsServer -CimSession 'server01’` |
| To restart the local DNS server we can run: | `Restart-Service -Name DNS -Force` |
| To define a new A record for a host named 'client1' and verify its existence  | `Add-DnsServerResourceRecordA -Name 'client1' -ZoneName ‘SenecaID.com' -IPv4Address 10.0.99.100` |
| To retrieve client1's A record: | `Get-DnsServerResourceRecord -ZoneName ‘SenecaID.com’ -Name 'client1' | Format-Table -AutoSize` |
