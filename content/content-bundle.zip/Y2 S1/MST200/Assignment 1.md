            
PRACTICAL LAB ASSIGNMENT 1 	 

 | TERM | COURSE NAME | COURSE CODE | VERSION |
 | ---- | ----------- | ----------- | ------- |
 |Summer 2021 | Microsoft Server Administration | MST200 |S21 |
			

| Name           | Sam Greenwood |
| -------------- | ------------- |
| Student Number | 102695195     |
| Section        | NAA           |


TIME ALLOWED:	4 days – Due 11:59pm, Monday, October 11, 2021. 
PERCENTAGE:		15%
TOTAL MARKS: 	34 Marks

SPECIAL INSTRUCTIONS:

1.	When creating screen shots, ensure the resolution makes the images readable and that they are cropped to show only the necessary screens. This may require an adjustment of the resolution of the screens in VMWare. Do not take images of your entire desktop to show a small dialog box. 
2.	No smartphone photos. Use the Snipping Tool or Print Screen plus MSPaint or another computer-based screen capturing tool. 
3.	Every image must have your domain name or computer name visible (showing your SenecaID). You may want to leave a screen open that shows this, such as Server Manager > Local Server 
You may need to adjust the position of your dialog boxes so all information is displayed in your screenshot.
4.	Upload assignment file to Learn@Seneca once complete.
 
This test includes a cover page, plus two ( 2 ) pages of questions, instructions to upload assignment and one marking sheet. 
	
SENECA’S ACADEMIC HONESTY POLICY
As a Seneca student, you must conduct yourself in an honest and trustworthy manner in all aspects of your academic career. A dishonest attempt to obtain an academic advantage is considered an offense and will not be tolerated by the College

**	Assignment Setup**
1.	Create a folder on your hard drive named Practical1. 
This is where you will store all your screenshots while you are completing the assignment.
2.	Create an MS Word document named Your_SenecaID Practical1.docx 
Save it into the Practical1 folder on your hard drive.
3.	At the top of the MS Word document, type your name, SenecaID and student number. Type the following labels, leaving at least one blank line between each label: PartA1, PartB1, PartB2, PartB3, PartD1, PartD2, PartD3, PartD4 and PartE. Keep the file open during the test so you can paste screenshots into the file. Save the file after each screenshot insert.
4.	Open your Server1 VM and boot Windows Server and login as the domain administrator.
5.	Open your AdminClient VM and boot Windows 10 and do not login.
6.	Keep both VMs open while doing the assignment.
**	Part A – Create an OU and Groups
**
1.	Create a new OU in your domain named Practical1.
2.	Create the following Global security groups in the Practical1 OU:
a.	HRDept
b.	CreativeDept
3.	Create the following Domain Local security groups in the Practical1 OU:
a.	HR_Docs_FC
4.	Add the HRDept  and CreativeDept global groups to the HR_Docs_FC domain local group. Take a screenshot of the HR_Docs_FC domain local group Members tab, and name the file PartA1.jpg
![[PartA1.jpg.png]]
**	Part B – Create a User Account Template**
1.	Create a user template named _HRTemplate in the Practical1 OU for your new employee accounts using the following properties:
a.	User must change password at next logon.
b.	Password set to P@ssw0rd
c.	Change the logon hours to be Monday through Friday from 8am to 6pm.
d.	Job Title: HR Person
e.	Department: HR Department
f.	Company: **Our Big Company**
g.	Users must be in the HRDept global group.
*take 3 screenshots of the user template properties sheet tabs (Ensure that the AdminClient VM tab is displayed in the screenshot) : 
•	Account tab (B.1.a), plus Logon Hours displayed (B.1.c)  (PartB1.jpg), 
a. 
![[Pasted image 20211008201944.png]] 

b. 
 ![[Pasted image 20211008202307.png]]

•	Organization tab (PartB2.jpg), 

 ![[Pasted image 20211008202140.png]]

•	Member of tab (PartB3.jpg)

 ![[Pasted image 20211008202733.png]]
 
**Part C – Create User Accounts and use Built-in Group**
1.	Create the following 3 user accounts in the Practical1 OU, using the first initial,+last name naming convention, and add a number if there are duplicate names,  by copying the template created above: (For example: Raymond Chen would be rchen. If there was already a rchen account, make the new account rchen1.)
		a.	Joey Janes	account name: <u> jjames </u>
		b.	May Flowers	account name: <u> mflowers </u>
		c.	April Showers	account name: <u> ashowers </u>
All 3 users should be added to the HRDept group
2.	Create the following user accounts manually (not using the template):
		a.	Hamid Sheikh	account name: <u> hsheikh </u>
		b.	June Janes	account name: <u> jujames </u>
2.	Give Hamid Sheikh full administrative rights on the domain by adding the user to the appropriate built-in group. What group did you add this account to? You will need to know the answer for Part D.
3.	Give June Janes the user rights that will allow her to create and manage user accounts and groups ONLY, by adding the user to the appropriate built-in group.
**	Part D – Using Remote Administration **
1.	Login to the AdminClient as the Hamid Sheikh account.
2.	Using Remote Server Administration Tools, display the Members tab for the group where you added the Hamid Sheikh account. (from Part C #3)
Take a screenshot of this group properties sheet. Ensure that the AdminClient VM tab is displayed in the screenshot. Name the file PartD1.jpg

![[Pasted image 20211009152924.png]]

3.	Using Remote Server Administration Tools, display the list of members of the group where you added the June Janes account. 
Take a screenshot of this group properties sheet. Ensure that the AdminClient VM tab is displayed in the screenshot. Name the file PartD2. 

![[Pasted image 20211009153516.png]]

4.	Take a screenshot of the contents of the Practical1 OU showing all user and group accounts from the AdminClient. Ensure that the AdminClient VM tab is displayed in the screenshot as well as the entire contents of the Practical1 OU. Name the file PartD3.jpg

![[Pasted image 20211009153545.png]]

5.	Display the HRDept global group Members tab. Take a screenshot and name it PartD4.jpg. Ensure that the AdminClient VM tab is displayed in the screenshot

![[Pasted image 20211009153611.png]]

**Part E – PowerShell**
1.	Use PowerShell to create a user named Power_Shell in the Practical1 OU. No other parameters are required. 
2.	Run the following command:  Get-ADuser Power_Shell
3.	Take a screenshot of the screen showing 1) the command you used to create the user and 2) the output from the Get-ADuser command. Name the file PartE.jpg.
![[Pasted image 20211009163206.png]]

Submitting the Screenshots to Learn@Seneca
1. Paste all screenshots into the MS Word document in order using the labels you created during the assignment setup. Save the file and then Save the file as a PDF or Print to PDF. 
Make the file name:  Your_SenecaID Practical1.PDF
2. Upload the file to the appropriate test link on Learn@Seneca.
(Learn@Seneca > MST200 > Tests + Practicals> Practical Lab Assignment 1)