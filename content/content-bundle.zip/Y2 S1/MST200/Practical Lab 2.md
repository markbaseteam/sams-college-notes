<center><h1> Practical Lab 2 </h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

| PartAA1                       | PartA1          |
| ----------------------------- | --------------- |
| ![[MST200-Prac2-PartAA1.png]] | ![[PartA1.png]] |

## PartA2
![[PartA2.png]]

| PartB1 | PartB2 |
| ------ | ------ |
| ![[PartB1.png]] | ![[PartB2.png]] |

## PartB3
![[PartB3.png]]

# Part C  
![[PartC1.png]]

## Part D
![[PartD.png]]