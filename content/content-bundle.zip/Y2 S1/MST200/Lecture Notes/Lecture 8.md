```toc 
**style: bullet | number (default:bullet)
min_depth: number (default: 2)
max_depth: number (default: 6)
```

## PowerShell Scripting Basics
- A script is a text file that contains a list of commands to be executed in sequence
- can be used to automate tasks on local or remote machines

## Execution Policies
%% #Polices %%

| Policy Name | Description |
| ---------------------- | ----------- |
| Unrestricted | Allow all scripts (used for testing only) |
| RemoteSigned | Allow local scripts and remote signed scripts. (default setting for Windows Server) |
| AllSigned | Allow only signed scripts (local or remote). |
| Restricted | No scripts will run. |

## Script Planning
### Process
1. flow Chart
2. pseudocode
3. write script

### Example Flow Charts
![[Pasted image 20211103140747.png]]

## Variables
### Automatic Variables
| Variable | Description |
| -------- | ----------- |
|  $? | Contains the execution status of the last operation. It contains TRUE if the last operation succeeded and FALSE if it failed. | 
| $_ | Contains the value of data as it travels though pipelines |
| $ARGS | Contains an array of the undeclared parameters and/or parameter values that are passed to a function, script, or script block |
| $PSVERSIONTABLE | Contains a read-only hash table that displays details about the version of PowerShell that is running in the current session. |
| $PSHOME | Contains the full path of the installation directory for PowerShell |
| $HOME | Contains the full path of the user's home directory |
| $PWD | Contains a path object that represents the full path of the current directory |

## Data Types
%% DataTypes %%

| Data Type         | Description                                             |
| ----------------- | ------------------------------------------------------- |
| <p> [int] </p>    | 32 bit signed integer                                   |
| <p> [long] </p>   | 64 bit signed integer                                   |
| <p>[decimal] </p> | 96 bit floating point number (more precise than double) |
| [double]          | Double-precision 64-bit floating point number           |
| [single]          | Single-precision 32-bit floating point number           |
| [bool]            | Boolean true or false value                             |
| [string]          | Fixed-length string of Unicode characters               |
| [DateTime]        | Date and Time object                                    |

## Test-Path
| Function                                                      | Command                                                        |
| ------------------------------------------------------------- | -------------------------------------------------------------- |
| PowerShell Check If File Exists                               | $WantFile = "C:\Windows\explorer.exe" <br> Test-Path $WantFile |
| PowerShell checks whether all the elements in the path exist. | Test-Path -Path "C:\Documents and Settings\DavidC"             |
| PowerShell Test-Path for Environmental Variables              | Test-Path Env:\PathExt                                         |

## Examples
### Environment  Variables
Example: Using an environment variable in a script to generate an email address  
  
Environment variable: $Env:Username
  
e.g.  $Email = $Env:Username + ‘@domain.com’

### User-Defined Variables

$FullName = “Murray Saul”

write-host “your name is: $FullName”

$UserAge = read-host “Enter your age (in years)”  
write-host “You are $userAge years old”

$Email = $Env:Username + ‘@domain.com’