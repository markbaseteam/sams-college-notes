```toc 
style: bullet | number (default: bullet)
min_depth: number (default: 2)
max_depth: number (default: 6)
```

# Managing Folders and Files
## What's a File Server
- a computer responsible for the central storage and management of data files that can be accessed by multiple systems/users
	- Remote Access
	- Centralized Management of Permissions
	- Data Security and Backup/Recovery
- On a Windows Server:  File and Storage Services role

## File Systems
%% #File-Systems %%

| File System | Features | Pictures |
| -------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------- |
| FAT – (MS-DOS) | **n**ot **u**sed **a**nymore **b**ecause of **f**ile and **v**olume **s**izes **l**imitations                                                                                                                                                                                                            |                                                                           |
| FAT32 | Good for small drives and old operating systems                                                                                                                                                                                                                                                          | ![[Pasted image 20211007140259.png]]                                      |
| exFAT (enhanced FAT) |                                                                                                                                                                                                                                                                                                          | ![[Pasted image 20211007141104.png]] ![[Pasted image 20211007141307.png]] |
| NTFS | Modern, robust, Windows file system <br> - supports file permissions for security <br> - a change journal that can help <br> quickly recover errors if your computer crashes <br> - shadow copies for backups <br> - encryption <br> - compression <br>  - disk quota limits, and various other features | ![[Pasted image 20211007142745.png]]                                      |
| Microsoft Encrypting File System (EFS) | - Microsoft’s newest file system <br> - Used for large data sets <br> - Improves efficiency, scalability and reliability <br>-  Automatically detects errors and fixes them, even while files are in use <br> - Can be used along with NTFS volumes <br> - Best used on storage volumes (not removable volumes) <br> - Cannot be used on the Windows boot partition |                                                                           |

### File and Folder Attributes
![[Pasted image 20211007153920.png]]
Information associated with a folder or file used to help manage access and backups
 - Stored as header information with each folder and file
 - Stored with other characteristics including volume label, designation as a subfolder, date of creation, and time of creation

| Common attributes | Extended attributes |
| ------ | ------ |
| - Read-only <br> - System <br> - Hidden <br> - Directory | - Archive <br> - Index <br> - Compress <br> - Encrypt |

| Attribute | Definition |
| --------- | --------- |
| Read-only | - Write-protected. Separate from permissions, applies to all users. <br> - Does not prevent file deletion. |
| Hidden    | Controls visibility of files (often system files) . |
| Archive   | Checked to indicate that the folder or file needs to be backed up because it is new or changed |
| Index     | - Index attribute and accompanying Indexing Service are legacy features for continuity with earlier operating systems. Usually includes files that are commonly accessed. |
| ![[Pasted image 20211007160253.png]]  | - Reduce the amount of disk space used for files <br> - Disadvantage of compressed files is increased CPU overhead to open the files and to copy them. |
| ![[Pasted image 20211007160203.png]] | - Only the user who encrypts folder or file can read it. |

### Microsoft Encrypting File System
%% #Encryption %%
- Requires NTFS (but as of Server 2016 also supports FAT & exFAT
- has to be manually configured

| Bitlocker | ![[Pasted image 20211007155923.png]] |
| --------- | ------------------------------------ |
| EFS       | ![[Pasted image 20211007155959.png]] |

##  Managing Folder and File Security
### Steps
- Create user accounts and Groups
- Create necessary folder structures
- Share folders that need to be accessed over the network
- Set permissions by creating Access Control Lists (ACLs) for each resource, using the users and groups created

### Permissions
%% #Permissions %%
- Privileges to access and manipulate resource objects, such as files, folders and printers; for example, can a user READ, WRITE, DELETE, CREATE etc.
- Permissions can be LOCAL – NTFS permissions
	- They only apply when a user accesses the object on the LOCAL computer
	- LOCAL access to servers is not common. Most files and folders are accessed over the network.
- Permissions can be NETWORK – Share permissions
	- They apply when a user access an object over the network
- NTFS and Shared permissions combine to create the most effective security

#### Explicit vs Inherited Permissions
%% #Inherited-Permissions #Explicit-Permissions %%

- Explicit permissions are permissions that are set by default when the object is created, or by user action
- Inherited permissions are permissions that are given to an object because it is a child of a parent object.
	- Inheritance can be disabled

#### NTFS Permissions
%% #NTFS #Permissions #NTFS-Permissions %%
 - can only be used on NTFS volumes
 - Set on the Security tab of file or folder properties
 - NTFS Permissions Are Cumulative
 - Permissions are Inherited from the Parent folder unless inheritance is disabled
 - File Permissions Override Folder Permissions
 - Deny Overrides Other Permissions (Explicit “Allow” overrides Inherited “Deny”)
	
![[NTFS Permissions#^2d64fb]]

----

The Effective Permission tool on the Advanced Security Settings dialog provides an easy method to determine the NTFS permissions, but it does not include share permissions. Shared permissions only apply to shares over the network.

This is a useful tool if permissions are extensive, and group membership is complicated. It may be difficult to determine a user’s or group’s effective permission manually.

### Examples
%% #Examples %%
![[Pasted image 20211007185743.png]]
	
## File Sharing
%% #File-Sharing %%
- shared folders can be shared over the network
- putting $ hides the file/folder
- only folders can be shared not individual files
	
### Combining Permissions
 - Evaluate Share Permissions - cumulative
 - Evaluate NTFS Permissions – cumulative unless denied access
 - The most restrictive permission is the effective permission
 - A common practice is to leave Share Permissions open (Everyone: Full Control), and restrict permissions with NTFS Permissions
	
## Cloud
%% #Cloud %%
### SharePoint
- ==SharePoint is a CMS==
- on-premise or cloud solution (Office 365)
-  a collaboration tool for businesses that need multiple individuals and teams to work on documents and products at the same time
-  collaborative workspace with dashboards, calendars, tasks, notifications, and updates
-  Integrates with apps to increase functionality

### OneDrive
- comes with SharePoint or can be used separately
- online document/file storage platform
- used by individuals and business teams who need a central location to store and access files
- versioning and sharing features