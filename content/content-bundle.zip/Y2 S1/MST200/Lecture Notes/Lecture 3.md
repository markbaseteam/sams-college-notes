```toc 
**style: bullet | number (default: bullet)
min_depth: number (default: 2)
max_depth: number (default: 6)
```

## User Management
### User Accounts
%% #Users #User #Accounts %% 

![[Pasted image 20210923142258.png]]
User Accounts are important because:
- they have the capability to require users to authenticate
- to tell the difference between users
	- to assign privileges 

| Domain User                                           | Local User |
| ----------------------------------------------------- | ------- |
| Access to network resources                           | access to resources on local computer       |
| user token for authentication                         | Are typically only created on user computers that are not in a domain        |
| Created through Active Directory on Domain Controller | Created in computer's local security database       |

It's a good idea to create a local user on a computer that's usually connected to a domain in case it's not connected to the internet

#### Built-In User Types
%% #Built-in %%
![[Pasted image 20210928135926.png]]

### User Account Creation 
%% #Users #User-Creation %%
![[Pasted image 20210928140103.png]]
![[Pasted image 20210928140110.png]]

#### Naming Conventions
![[Pasted image 20210928140328.png]]

### Active Directory Users & Computers
- Guests shouldn't be allowed to change their password

### Account Properties Tabs
![[Pasted image 20210928150002.png]]
![[Pasted image 20210928145618.png]]
![[Pasted image 20210928150041.png]]
![[Pasted image 20210928150100.png]]

### User Creation (Cont)
%% #User-Creation %%

![[Pasted image 20210928150155.png]]

#### Home Folder Configuration 
%% #Home-Folder #Configuration %%
![[Home Folder Templates.png]]
![[Pasted image 20210928150900.png]]
 
 #### Bulk Account Creation Methods
 %% #Bulk #User-Creation %%
 - When many users need to be created at one time, it is often useful to use a script
 - A .CSV (Comma Separated Values) file is created with all of the user accounts and their properties.
 - Use a PowerShell script to import all of the user accounts from the CSV file.

### Account Maintenance
%% #Maintenance %%
- **Disabling an account**: when a user takes a leave of absence or when another person may take over an existing position and take ownership of files.
- **Enabling an account**: when a user returns from an extended leave or starts a new job.
- **Renaming an account**: when someone gets married or changes their name.
- **Moving an account** into a different OU due to a change in position within the company.
- **Deleting an account** when a user leaves the organization and there will be no replacement person.
- **Resetting a password** for users who forget theirs
- **Account auditing** to track certain kinds of activity performed by an account holder
 
 ### Account Polices
 %% #Polices %%
- applied at the domain level to all members of Domain
- Kerberos policy covers communication external to the network.
- domain can only have a single account policy

#### Password Policies
%% #Password %%
- Enforce password history: the system remembers previous passwords and users cannot reuse them
- Maximum password age: set the maximum time allowed until a password expires
- Minimum password age: specify that a password must be used a minimum amount of time before it can be changed
- Minimum password length: passwords are a minimum length
- Passwords must meet complexity requirements: passwords must contain a number of different characters, including symbols, upper and lowercase and numbers.
- Store password using reversible encryption: means that the encrypted passwords can be decrypted for applications that use protocols that require the user's password for authentication

#### Lockout Policies
- Account lockout duration: Permits you to specify in minutes how long the system will keep an account locked out after reaching the specified number of unsuccessful log on attempts
- Account lockout threshold: Enables you to set a limit to the number of unsuccessful tries to log onto an account
- Reset account lockout count after: Enables you to specify the number of minutes between two consecutive unsuccessful logon attempts to make sure that the account will not be locked out too soon

#### Kerberos Policy
- Mechanism for authentication and authorization to access resources
- In most environments, these settings do not need to be changed

## Groups
%% #Groups %%
- permissions are applied to groups not individual Users
- users can be members of multiple groups
- Default groups are located in the Built-In and user folders
- Group editor is gpedit.msc

### Types of Security Groups
%% #Security-Groups %%

| Security Group                   | Description                                                                                                               |
| -------------------------------- | ------------------------------------------------------------------------------------------------------------------------- |
| Local %% #Local-Group %%            | Used on standalone servers that are not part of a domain                                                                  |
| Domain Local %% #Domain-Local-Group %% | Used in a single domain or to manage resources in a domain so that global and universal groups can access those resources |
| Global %% #Global-Group %%             | Used to manage accounts from the same domain and to access resources in the same and other domains                        |
| Universal  %% #Universal-Group %%      | Used to provide access to resources in any domain within a forest                                                         |

#### Local Groups
%% #Local-Group %%
- used in workgroups %% #workgroup %%
- truly Local
- Users and Admins are the only Built-In Groups in a domain.

##### Domain Local Group
%% #Domain-Local-Group %%

![[Pasted image 20210928155410.png]]

#### Global Group
%% #Global-Group %%
- Mostly serve as a role-based group, defining collections of users (and computers and groups) that have the same job function, or role
- You will often see Global Groups having names that refer to the role. For example, HR, Marketing, Sales
- Global Groups are typically added to Domain Local Groups to gain access to resources
- Can also be added to Universal groups in a multi-domain environment

#### Universal Group
%% #Universal-Group %%
- Only used when working with multiple connected domains

### Group Nesting
%% #Nesting %%
- Global groups %% #Global-Group %% can be nested within Domain Local groups, Universal groups and within other Global groups in the same domain.
- Global groups %% #Global-Group %% cannot be nested across domains
- A user or computer account from one domain cannot be nested within a Global group in another domain
- Global groups %% #Global-Group %% can be nested to reflect the structure of OUs
- Domain Local groups %% #Domain-Local-Group %% can accept anything, except for Domain Local groups from another domain. Domain Local groups accept user accounts from any domain.
- A Domain Local group %% #Domain-Local-Group %% cannot be nested within a Global or a Universal group.
- Universal groups %% #Universal-Group %% can be nested within Domain Local groups and within other Universal groups in any domain.
- Universal groups  %% #Universal-Group %% accept user/computer accounts from any domain. A Global group can also be nested within a Universal group (from any domain).
- A Universal group %% #Universal-Group %% can be nested within another Universal group or Domain Local group in any domain.

###  Microsoft's recommendation for effectively using groups (AGDLP/IGDLP)
summarizes Microsoft’s guidelines for implementing role-based access controls using nested groups in Active Directory (AD) domain.
1. Add the Accounts/Identities to Global group
2. Add the Global group to Domain Local group
3. Assign Permissions to Domain Local group
*AGUDLP to include Universal Groups.*

### Group Examples
![[Pasted image 20210930101705.png]]
![[Pasted image 20210930101731.png]]

### Creating A Groups
%% #Creation %%
- Groups are created through the Active Directory Users & Computers app
- There's no option to create Local groups because AD controls the domain and doesn't directly control the server itself

#### Group Properties Tab
%% #Tabs %%
- **General**: Used to enter a description, set the scope, and set the group type
- **Members**: Used to add group members
- **Member Of**: Used to join another group
- **Managed By**: Establishes who will manage the group

#### User Rights
%% #Rights %%
- Enable an account or group to perform predefined tasks, such as:
	- Logon locally
	- Shutdown the system
	- Create a shared resource
	- Change system date and time
	- Reset passwords
	- Backup Files and directories
- Built-in/Default Groups have predefined user rights
- User accounts and groups added to these groups automatically inherit the user rights of the group

### Built-in Domain Local Groups & User Rights
%% #Built-in %%
- Administrators
	- full administrative access to all domain controllers and to the domain
- Account Operators %% #Operators %%
	- create, delete, and modify user, computer, and group objects in the Users and Computers containers and in all OUs but not Domain Controllers and cannot modify Administrators or Domain Admins groups, nor accounts for members of those groups.
- Backup Operators%% #Operators %%
	- backup and restore files on all domain controllers in the domain
- Server Operators %% #Operators %%
	- On domain controllers, members of this group can log on, create and delete shared resources, start and stop some services, back up and restore files, format the hard disk, and shut down the computer.
- Print Operators %% #Operators %%
	- manage, create, share, and delete printers connected to domain controllers in the domain
- Users %% Users %%
	- Can run applications, use local and network printers and lock the server
	- Cannot logon to the server or shutdown

### Built-in Local Groups & User Rights
- Administrators %% #Admin %%
	- have complete and unrestricted access to the computer and the domain, enabling them to perform all administrative tasks
- Backup Operators
	- have user rights that enable them to override security restrictions for the sole purpose of backing up and restoring files
- Power Users
	- can create and modify local user and group accounts. Create and administer shared resources. Power Users cannot take ownership of files, back up or restore folders, load or unload device drivers, or manage security logs
- Print Operators
	- can manage printers and print queues on the computer.
- Users
	- can perform tasks such as running applications, using local and network printers, and locking the server. Users cannot share directories or create local printers.

## Process of Joining AD
 - The builtin/administrators group is created by default when you install Windows and has complete access to the system
	 -  By default the only user account that is a member of this group is Administrator.
 - The Domain Administrators group is only present in a Windows domain
	 - has complete access to the Domain

When a pc/server is added to a domain: 
- e domain admins group automatically becomes a member of the builtin/administrators group, thus providing the domain administrators administrator-level access to the computer.

If you move an account from the domain admins group to the builtin/administrators group
- the account would be able to administer that local computer but nothing else, unless you added the account to other builtin/administrators groups on all servers.

**This scenario occurs automatically, however there is a Group Policy that overrides the Local Administrative rights on the Local Computer for any administrative account other than the built-in Administrator account. It is related to something called User Account Control which is a security feature. To fix this problem, we can do the following on the client:
- Launch gpedit from an elevated command prompt.
- Navigate to Computer Settings\Windows settings\Security settings\Local policies\Security options
- Locate the following policy: User Account Control: Run all administrators in Admin Approval Mode, which you’ll find Enabled.	
- Set it to Disabled.