```toc 
**style: bullet | number (default: bullet)min_depth: number (default: 2
)max_depth: number (default: 6)
```

## Types of Installations

| Install Type | Info                                                                                                                      |
| ------------ | ------------------------------------------------------------------------------------------------------------------------- |
| Server Core  | - No GUI <br> - default Installation type <br> - you can no longer switch between Core and GUI                            |
| Nano Server  | - Remote Admin only <br> - No local login <br> - more compact than Server Core <br> - only available on Standard Editions |
       
## Basic Admin of Server Core


## PowerShell
%% #PowerShell %%
- PowerShell is a task-based cls

## Commands 
%% #Commands %%

| Command  | What It Does          | Options      |
| -------- | --------------------- | ------------- |
| New-Item | Creates new directory | - Path: specifies where the directory will live |
| Get-Command  | shows list of usable commands                      | |


## Active Directory Basics 
%% #ActiveDirectory #AD #Basics %%

### Domain Controllers 
%% #Domain %%
- allows an Active Directory server to use their own Domain
	- validates user login
- it's suggested that only one Domain Controller is used

#### Single Domain
|     |     |
| --- | --- |
| - logical grouping of networking resources under the same administrative control <br> - there can be subgroups inside of a domain (called Organizational Units)     | ![[Pasted image 20210916131338.png]] |

### Objects

![[Pasted image 20210922150824.png]]

Schema: Data and Objects that can be stored in Active Directory

![[Pasted image 20210922150850.png]]

![[Pasted image 20210922151027.png]]

### Trees & Forests 
%% #Tree #Forrest %%
![[Pasted image 20210922151133.png]]

- all Domains in the same tree use the same schema for all common objects 

### Global Catalog Server
%% #GCS %%
![[Pasted image 20210922172055.png]]

### DNS
%% #DNS %%
- AD Domain Services requires a DNS server to function
- Each Tree in the forest is contiguous
- Forest is not contiguous

-------

- suggested to have a maximum of 10 OUs
- 