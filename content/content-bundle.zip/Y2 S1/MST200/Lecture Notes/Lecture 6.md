 # Printing Services
```toc 
style: bullet | number (default: bullet)
min_depth: number (default: 2)
max_depth: number (default: 6)
```

## Industries that are still dependent on Print
- education
- medical 
- government

## Windows Printing
Print & Document Services is a Windows Server role that controls printing

### Windows Print Architecture Components
| Component    | Description                                                                                                                                   |
| ------------ | --------------------------------------------------------------------------------------------------------------------------------------------- |
| Print Device | the physical device (hardware) that produces the hard-copy documents on paper                                                                 |
| Printer      | the software interface through which the computer communicates with the print device                                                          |
| Print Job    | document or items to be printed                                                                                                               |
| Print Client | workstation or application that. generates the print job                                                                                      |
| Print Server | server or computer that receives print jobs from clients that are attached locally or over the network                                        |
| Driver       | a device driver (software) that provides the formatting instructions for a given print device                                                 |
| Print Queue  | the list of print jobs waiting to be printed                                                                                                  |
| Spooler      | software that manages sending jobs to the print device by slowly feeding stored print images, while other stored print jobs wait in the queue |

### Types of Printing 
| Type                             | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |                                      |
| -------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------ |
| Direct Printing                  | - Print device is attached directly to a server/computer <br> - Server/computer sends print job to the print device <br> - This is an expensive model and not commonly used                                                                                                                                                                                                                                                                                                                                                                                                                              | ![[Pasted image 20211014130058.png]] |
| Locally-attached Printer Sharing | - The same as direct printing, but you also need to share the printer and print device with other clients on the same network <br> - The server connected to the print device acts as the Print Server and can control and manage printing services                                                                                                                                                                                                                                                                                                                                                      | ![[Pasted image 20211014130324.png]] |
| Network-attached Printing        | - Print device is directly attached to the network by wire or wirelessly <br> - Without a print server, users print directly to the print device over the network, and: <br> - Users only see their own print jobs in their own print queue and are oblivious if other users are printing and Administrators cannot centrally manage the print queue <br> - Error messages are directed only to the computer where the print job is currently processing <br> - All print job processing is completed by the client computer instead of being shared with a print server | ![[Pasted image 20211014134639.png]] |
| Network-attached Printer Sharing  | - The same as Network-attached Printing, but you assign a computer as a print server <br> - Print Server manages the Printer and all clients print through the Print Server  |                                      |

### The Printing Process
- Software application at client generates a print file 
- Application communicates with the Windows graphics device interface (GDI)
- Print file formatted with control codes to implement the special graphics, font, and color characteristics of the file
- Software application places print file in client’s spooler by writing spool file to spooling subfolder
- Remote print provider makes a remote procedure call to network print server
- Network print server uses four processes to receive and process a print file:
	- Router, print provider, print processor, and print monitor
- Server service calls Print Spooler service
- Print provider works with print processor to ensure that file is formatted to use right data type
- Print monitor pulls file from spooler’s disk storage and sends it to printer

### PowerShell Commands
%% #Commands #PowerShell #PS-Commands %%

| Action | Command |
| ------ | ------- |
| List all cmdlets in the PrintManagement module |  `Get-Command –Module PrintManagement` |
| List Installed Printers on a Print Server | `Get-Printer` |
| To display only a list of shared printers, use the command | `Get-Printer -ComputerName MTS-prnt1 | where Shared -eq $true | fl Name` |
| To add a printer to a local computer | `Add-Printer -Name "mxdw 2" -DriverName "Microsoft XPS Document Writer v4" -PortName "portprompt:“` |
| To add a networked printer connection | `Add-Printer -ConnectionName \\printServer\printerName`|
| To add a printer driver                    | `Add-PrinterDriver -Name "HP Color LaserJet 5550 PS Class Driver”`       |
| To create a TCP printer port               | `Add-PrinterPort -Name "TCPPort:" -PrinterHostAddress "192.168.100.100“` |
| Get the information for a specific printer | `Get-Printer -Name "Microsoft XPS Document Writer"`                      |
  
  ----------- 
## Azure Hybrid Cloud Printing Services
%% #Azure #Printing %%
- Provides secure user access to on-premises printers
- Built on Windows Print Server Role so it feels like managing printers and user access security
- Allows users in your organization to print from the devices they use to complete their work (even mobile devices), even when they are away from their desk or workplace

