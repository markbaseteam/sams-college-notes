```toc 
**style: bullet | number (default: bullet)min_depth: number (default: 2
)max_depth: number (default: 6)
```

## What's New In Windows Server 2016

- Features: additional functionalities

### New Features In Windows Server 2016
%% #Features %%
| Feature Name                      | Description                                                                                                                                                          |
| --------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Containers                        | allow action to run in its own space, an isolated environments without affecting other applications or other operating system resources. Ex: virtualizations          |
| Fail=over Clustering              | Making networked server available and scalable during downtime                                                                                                       |
| File Server Resource Manager      | set of tools that allows administrators to manage and control the amount and type of data stored on the organization’s servers.                                      |
| Group Policy Objects              | set of rules and management configuration options that can be controlled through the Group Policy settings. Can be placed on all users’ computers in an organization |
| IPAM IP Address Management (IPAM) | allows an administrator to customize and monitor the IP address infrastructure on a corporate network                                                                |
| Nano Server                       | a type of server installation that allows an administrator to remotely administer the server operating systems.                                                      |
| Nested Virtualization | lows to create virtual machines within another virtual machines
| NIC Teaming | allowing multiple network adapters on a system to be placed into a team which provide network connection even if one of the adapter fails. | 
| Smart Cards (two-factor authentication) | a popular, reliable, and cost-effective way to provide authentication and to provide a guard to access if the card is lost or stolen                                 |                                                                                                                                                                      |


## Editions & Versions
### 3 Editions
- Datacenter and Standard
- Essentials (no Foundation)

### New Installations/Interfaces
- Graphical User Interface is now called “Desktop Experience”
- Server Core Mode – command line only interface  (You can no longer go back and forth between Server Core and Desktop Experience as with Windows Server 2012 R2. A reinstall is required.)
- Nano Server – no user interface. Remote administration only

### PowerShell 5.1 preinstalled
- PowerShell will be a required skill for Windows Server administrators
- You will use PowerShell commands in MST200 labs with 2 weeks dedicated to PowerShell

## Windows Server 2016 Platforms

The Windows Server 2016 platforms are as follows:
- [[Windows Server Versions#Windows Server 2016 Essentials Edition|Windows Server 2016 Essentials Edition]]
- [[Windows Server Versions#Windows Server 2016 Standard Edition|Windows Server 2016 Standard Edition]]
- [[Windows Server Versions#Windows Server 2016 Datacenter Edition|Windows Server 2016 Datacenter Edition]]
- [[Windows Server Versions#Windows Hyper-V Server 2016|Windows Hyper-V Server 2016]]
- [[Windows Server Versions#Windows Storage Server 2016|Windows Storage Server 2016]]
- [[Windows Server Versions#Windows MultiPoint Premium 2016 Server|Windows MultiPoint Premium 2016 Server]]
