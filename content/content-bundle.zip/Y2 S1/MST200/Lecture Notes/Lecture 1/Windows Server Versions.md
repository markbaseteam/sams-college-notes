### Windows Server 2016 Essentials Edition
- Suitable for small businesses
- Supports up to 25 users and 50 devices
- Simpler interface and preconfigured connectivity to cloud-based services
- Licensed on a per processor basis
- No virtualization rights
- No CALs requirement due to the user and device restriction

### Windows Server 2016 Standard Edition
- Designed to deploy as a physical server
- Can be use as a virtual server
- Full Windows Server functionality with two virtual instances
- Uses per processor core licensing
- Requires Windows Server Client Access Licenses (CALs)

### Windows Server 2016 Datacenter Edition 
- Designed for datacenters with highly virtualized and private cloud environment
- Full Windows Server functionality with unlimited virtual instances
- Per processor core licensing and require Windows Server CALs.

### Windows Hyper-V Server 2016
- Hyper-V 2016 Server is a stand-alone version that has the Windows hypervisor, the Windows Server driver model, and the other virtualization components only
- Does not require a license or CALs
- Using simple virtualization solution to reduce the costs
- Has the exact same Hyper-V role components as Windows Server 2016
- Doesn’t have a GUI
- Use Hyper-V Manager or Virtual Machine Manager to remotely Manager

### Windows Storage Server 2016
- Not openly available for sale to the general public
- Only available in OEM (Original Equipment Manufacturer) channels.
- Licensed on processor based and no CAL requires
- Fully supports upgrades from previous versions

### Windows MultiPoint Premium 2016 Server
- Designed for sharing one computer simultaneously with multiple users
- Available only to academic licensing user for education purposes
- Same Windows Server 2016 with Multipoint Services Installed.
- Licensed on a per-processor basis
- Allows multiple users to share one computer with user specific windows settings
