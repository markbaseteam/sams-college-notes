```toc 
style: bullet | number (default: bullet)
min_depth: number (default: 2)
max_depth: number (default: 6)
```

## DHCP
%% #DHCP #dynamic #TCP/IP %%
### DHCP Basics
%% #Basics #DHCP %%
- client/server protocol based on TCP/IP
- dynamically assigns system IP configuration and other IP adjacent addresses
- automatic

### Benefits of DHCP
%% #Benefits %%
![[Benefits of DHCP#^224519]]

### DHCP Process
- The DHCP client requests an IP address by broadcasting a **DHCP Discover** message to the local subnet.
- The client is offered an address when a DHCP server responds with a** DHCP Offer** message containing an IP address and configuration information for lease to the client. 
- The client indicates acceptance of the offer by selecting the offered address and broadcasting a **DHCP Request** message in response.
- The client is assigned the address and the DHCP server broadcasts a **DHCP Ack** message in response, finalizing the terms of the lease.
- When the client receives the acknowledgment, it configures its TCP/IP properties by using the DHCP option information in the reply and completes its initialization of TCP/IP.

### DHCP Renewal Process
- once 1/2 the lease time has elapsed the client attempts to renew
	- client sends DHCP request to server that originally accepted the lease
	- the server sends a DHCP ACK back to the client
- if the first renew request fails it will be reattempted at one 75% of the lease period has elapsed and if that fails at 87.5%

### Using PowerShell to Install DHCP
%% #InstallationProcess #PS-Commands  #PowerShell %%

| Command                            | Function                                            |
| ---------------------------------- | --------------------------------------------------- |
| To install the DHCP Role           | Install-WindowsFeature DHCP –IncludeManagementTools |
| To create the DHCP Security Groups | netsh dhcp add securitygroups |
| restart DHCP Service               | Restart-Service dhcpserver |
| To authorize this DHCP server in your domain | Add-DhcpServerInDC -DnsName Server1.SenecaID.com -IPAddress 10.0.100.10 |

### Verify the DHCP Server is Authorized in AD
%% #DHCP-Verification #AD %%
![[Pasted image 20211021140032.png]]

### Configuring a DHCP Server
%% #Configuration  %%
- Set up one or more scopes
	- Range of addresses to be given out by the DHCP Server
	- Ensure the range of addresses does not include addresses that have been manually configured on devices on your network
	- Configure the Subnet Mask
	- Set Exclusion(s) if addresses in the scope have been used on the network
	- Set the lease duration
	- Configure DHCP Options (Scope Options or Server Options)
		- Default gateway, WINS Server, DNS Servers
- Activate each scope

### Configuring DHCP Scopes
#### Planning IP address ranges
%% #IP-Addresses #Ranges %%
- Each subnet must have its own unique IP address range. These ranges are represented on a DHCP server with scopes.
- A scope is an administrative grouping of IP addresses for computers on a subnet that use the DHCP service. The administrator first creates a scope for each physical subnet and then uses the scope to define the parameters used by clients.

A scope has the following properties:
-   A range of IP addresses from which to include or exclude addresses used for DHCP service lease offerings.
-   A subnet mask, which determines the subnet prefix for a given IP address.
-   A scope name assigned when it is created.
-   Lease duration values, which are assigned to DHCP clients that receive dynamically allocated IP addresses.
-   Any DHCP scope options configured for assignment to DHCP clients, such as DNS server IP address and router/default gateway IP address.
-   Reservations are optionally used to ensure that a DHCP client always receives the same IP address.
    
Before deploying your servers, list your subnets and the IP address range you want to use for each subnet.

#### Planning subnet masks
%% #SubnetMask %%
- Network IDs and host IDs within an IP address are distinguished by using a subnet mask. Each subnet mask is a 32-bit number that uses consecutive bit groups of all ones (1) to identify the network ID and all zeroes (0) to identify the host ID portions of an IP address.
- For example, the subnet mask normally used with the IP address 131.107.16.200 is the following 32-bit binary number:

> 11111111 11111111 00000000 00000000

This subnet mask number is 16 one-bits followed by 16 zero-bits, indicating that the network ID and host ID sections of this IP address are both 16 bits in length. Normally, this subnet mask is displayed in dotted decimal notation as 255.255.0.0.

The following table displays subnet masks for the Internet address classes.

| Address class | Bits for subnet mask                | Subnet mask |
| ------------- | ----------------------------------- | ----------- |
| Class A | 11111111 00000000 00000000 00000000 | 255.0.0.0   |
| Class B | 11111111 11111111 00000000 0000000 | 255.255.0.0 |
| Class C | 11111111 11111111 11111111 00000000 | 255.255.255.0 |
 
- When you create a scope in DHCP and you enter the IP address range for the scope, DHCP provides these default subnet mask values. Typically, default subnet mask values are acceptable for most networks with no special requirements and where each IP network segment corresponds to a single physical network.
- In some cases, you can use customized subnet masks to implement IP subnetting. With IP subnetting, you can subdivide the default host ID portion of an IP address to specify subnets, which are subdivisions of the original class-based network ID.
- By customizing the subnet mask length, you can reduce the number of bits that are used for the actual host ID.
- To prevent addressing and routing problems, you should make sure that all TCP/IP computers on a network segment use the same subnet mask and that each computer or device has an unique IP address.
 
#### Planning exclusion ranges
%% #Planning %%
- When you create a scope on a DHCP server, you specify an IP address range that includes all of the IP addresses that the DHCP server is allowed to lease to DHCP clients, such as computers and other devices. If you then go and manually configure some servers and other devices with static IP addresses from the same IP address range that the DHCP server is using, you can accidentally create an IP address conflict, where you and the DHCP server have both assigned the same IP address to different devices.
- To solve this problem, you can create an exclusion range for the DHCP scope. An exclusion range is a contiguous range of IP addresses within the scope's IP address range that the DHCP server is not allowed to use. If you create an exclusion range, the DHCP server does not assign the addresses in that range, allowing you to manually assign these addresses without creating an IP address conflict.
- You can exclude IP addresses from distribution by the DHCP server by creating an exclusion range for each scope. You should use exclusions for all devices that are configured with a static IP address. The excluded addresses should include all IP addresses that you assigned manually to other servers, non-DHCP clients, diskless workstations, or Routing and Remote Access and PPP clients.
- It is recommended that you configure your exclusion range with extra addresses to accommodate future network growth. The following table provides an example exclusion range for a scope with an IP address range of 10.0.0.1 - 10.0.0.254 and a subnet mask of 255.255.255.0.

| Configuration items | Example values |
| ------------------- | -------------- |
| Exclusion range Start IP Address | 10.0.0.1 |
| Exclusion range End IP Address | 10.0.0.25 |

#### [Planning TCP/IP static configuration](https://docs.microsoft.com/en-us/windows-server/networking/technologies/dhcp/dhcp-deploy-wps#planning-tcpip-static-configuration)
%% #TCP #TCP/IP #static-conf %%
- Certain devices, such as routers, DHCP servers, and DNS servers, must be configured with a static IP address. In addition, you might have additional devices, such as printers, that you want to ensure always have the same IP address. List the devices that you want to configure statically for each subnet, and then plan the exclusion range you want to use on the DHCP server to ensure that the DHCP server does not lease the IP address of a statically configured device. An exclusion range is a limited sequence of IP addresses within a scope, excluded from DHCP service offerings. Exclusion ranges assure that any addresses in these ranges are not offered by the server to DHCP clients on your network.
- For example, if the IP address range for a subnet is 192.168.0.1 through 192.168.0.254 and you have ten devices that you want to configure with a static IP address, you can create an exclusion range for the 192.168.0._x_ scope that includes ten or more IP addresses: 192.168.0.1 through 192.168.0.15.
- In this example, you use ten of the excluded IP addresses to configure servers and other devices with static IP addresses and five additional IP addresses are left available for static configuration of new devices that you might want to add in the future. With this exclusion range, the DHCP server is left with an address pool of 192.168.0.16 through 192.168.0.254.
- Additional example configuration items for AD DS and DNS are provided in the following table.

| Configuration items | Example values |
| ------------------- | -------------- |
| Network Connect Bindings | Ethernet |
| DNS Server Settings | DC1.corp.contoso.com |
| Preferred DNS server IP address | 10.0.0.2 |
| Scope values <br> 1. Scope Name  <br> 2. Starting IP Address <br> 3. Ending IP Address  <br> 4. Subnet Mask  <br> 5. Default Gateway (optional) <br> 6. Lease duration | <br> 1. Primary Subnet <br> 2. 10.0.0.1 <br> 3. 10.0.0.254 <br> 4. 255.255.255.0 <br> 5. 10.0.0.1 <br> 6. 8 days |
| IPv6 DHCP Server Operation Mode | Not enabled

### Scope Options
%% #Options %%
- Default Gateway
- WINS Server (Deprecated)
	- Used for older Windows OS NetBIOS name resolution
- DNS Server
	- DHCP manager tool will validate the DNS servers you enter

### Scope Configuration w/ PowerShell
%% #PowerShell #Commands #PS-Commands %%

| Function | Command |
| --------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------ |
| Add the Exclusions                            | Add-DhcpServerv4ExclusionRange -ScopeID 10.0.0.0 -StartRange 10.0.0.1 -EndRange 10.0.0.15                                |
| Configure the default gateway                 | Set-DhcpServerv4OptionValue -OptionID 3 -Value 10.0.0.1 -ScopeID 10.0.0.0 -ComputerName DHCP1.SenecaID.com               |
| Configure DNS Server                          | Set-DhcpServerv4OptionValue -DnsDomain SenecaID.com -DnsServer 10.0.0.2                                                  || Create a scope and set the range of addresses | Add-DhcpServerv4Scope -name “TheScope" -StartRange 10.0.0.1 -EndRange 10.0.0.254 -SubnetMask 255.255.255.0 -State Active |

### Reservations
 Ensures DHCP clients always receive the same IP address from the scope
- Use the device’s MAC address to reserve an address in the scope for that device only. The address will never be given to another DHCP client.
- Find the client MAC address using ipconfig or arp commands.

### DHCP Failover
%% #Failover %%
- provides redundancy in case one DHCP server becomes unavailable
- Can also be used for load balancing
- Configure failover partners
	- Share scope information, including active leases

-------
## DNS
%% #DNS #Domain %%
###  What is DNS?
![[Pasted image 20211022135748.png]]
- TCP/IP application protocol
- converts alphanumeric domain name to IP address

### DNS & Active Directory
%% #AD #AD-DNS %%
- AD requires DNS and DNS is required for AD to work
- DNS is used because it's scalable and standard
- in a small org there should be 2 DNS server for redundancy

#### Installation Through PowerShell
%% #InstallationProcess %%
| Function | Command |
| ----------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------ |
| To install the DNS role (separate from ADDS) | `Install-WindowsFeature -Name DNS -IncludeAllSubFeature –IncludeManagementTools` |
| Run the following command to retrieve a list of all PowerShell DNS functions: | <p> `Get-Command -Module DNSServer | Select-Object -Property Name` </p> |
| Use Get-DNSServer to retrieve the local server's configuration data | `Get-DnsServer -CimSession 'server01’` |
| To restart the local DNS server we can run: | `Restart-Service -Name DNS -Force` |
| To define a new A record for a host named 'client1' and verify its existence  | `Add-DnsServerResourceRecordA -Name 'client1' -ZoneName ‘SenecaID.com' -IPv4Address 10.0.99.100` |
| To retrieve client1's A record: | `Get-DnsServerResourceRecord -ZoneName ‘SenecaID.com’ -Name 'client1' | Format-Table -AutoSize` |

### DNS Zones
- A DNS zone is **a portion of the DNS namespace that is managed by a specific organization or administrator**

#### AD Integrated Zones
- When you install DNS through the promotion of a domain controller, all zones and records are defined for you and they are integrated with Active Directory:
	- DNS zones are automatically replicated with Active Directory
	- Secure dynamic updates are supported which is more secure because unauthorized updates to DNS records are not allowed.

### DNS Record Types
![[DNS Record Types#^8a519f]]

### Troubleshooting DNS
%% #Troubleshooting %%
![[Troubleshooting DNS#^0e20c9]]