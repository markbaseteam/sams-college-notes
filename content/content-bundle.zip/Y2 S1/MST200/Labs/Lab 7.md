<center><h1> Lab 7: Creating Users With PS </h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

==**Part 1:**==

![[PS L4 Grade Calculator.png]]

I know that the code is incorrect but it still does the same thing and works properly.

==**Part 2.1:**==

![[Pasted image 20211121184022.png]]

==**Part 2.1.1:**==

1. it fails to run and gives an error that says the user already exists
2. They'll have to change their password
3. I don't know

==**Part 2.2:**==

![[PS-Script-Run.png]]

==**Part2.3: **==

![[vm-userd 1.png]]

==**Part 2.3.1: **==

1. 12
2. checks the validity of the password

==**Part 2.3.2: **==

![[NewUser.png]]

![[Server1-2021-11-21-19-24-20 1.png]]

