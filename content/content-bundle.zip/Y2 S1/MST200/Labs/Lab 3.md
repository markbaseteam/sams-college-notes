<center><h1>Lab 3</h1></center>         

**Name:** Sam Greenwood

**Student Number:** 102608195

Note: I took most of the screenshots a couple of days after completing the

--------- 
### ==**OUs**==
| ![[Server1-2021-10-02-16-19-11.png]]   | ![[Server1-2021-10-04-12-14-09.png]]    |
| --- | --- |
| ![[Server1-2021-10-04-12-14-16.png]]    | ![[Server1-2021-10-04-12-14-23.png]]    |


### ==**Mr Slate**==
test #bg-red
![[Server1-2021-10-04-12-20-10.png]]

### ==**SalesFiles_FC Domain Local Group**==
![[Admin-2021-10-04-12-30-22.png]]

### ==**PowerShell**==
![[Server1-2021-10-04-11-45-12 2.png]]
![[Server1-2021-10-02-18-17-49.png]]