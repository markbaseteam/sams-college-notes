<center><h1> Lab 4  </h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

==**File Server: **==

| ![[SC-Part1.png]] | ![[Drive-K.png]] |
| ----------------- | ---------------- |

==**OneDrive:**==

[OneDrive Folder Link](https://seneca-my.sharepoint.com/:f:/g/personal/sgreenwood3_myseneca_ca/Esqs3oeRx8lOttJL3YjL_pUBR17Dj8DtjbQ0MKgZcvbYgg?e=SI2buJ)

==**Server1 Print Management:**==

![[Print Managment.png]]

==**Client1 Printer Added:**==

![[C1 Printer.png]]