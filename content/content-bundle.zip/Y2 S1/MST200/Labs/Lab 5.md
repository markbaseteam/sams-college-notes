<center><h1> Lab 5: Configuring a DHCP Server  </h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

==**Part 2: **==

|     |     |
| --- | --- |
| DHCP manager | ![[Server1-2021-10-23-14-01-31.png]] |

==**Part 3: **==

|                       |     |
| --------------------- | --- |
| DHCP manager | ![[DHCP Scope AC.png]] |
| ipconfig /all command | ![[Client1-2021-10-23-14-24-54.png]] |

==**Part 4: **==

|                       |     |
| --------------------- | --- |
| DHCP manager | ![[Server1-2021-10-29-16-36-55.png]]    |
| ipconfig /all command | ![[Admin-2021-10-29-16-37-05.png]] |

==**Part 6: **==

|  | |
| ---- | --- |
| resource records | ![[Pasted image 20211029165147.png]] | 
