<center><h1> Lab 6: PowerShell Variables </h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

![[Pasted image 20211106170511.png]]


