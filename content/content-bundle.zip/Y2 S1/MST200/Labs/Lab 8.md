<center><h1> Lab 8 </h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

==**3.2:**==
1. mst200labtestlab3813823789000.eastus.cloudapp.azure.com
2. RDP / 64764
3. ![[Pasted image 20211129161500.png]]


