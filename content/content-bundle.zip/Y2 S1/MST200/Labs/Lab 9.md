<center><h1> Lab 9 </h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

==**3.1**==

| sgreenwood3AZ1   |             |
| ---------------- | ----------- |
| IP address: | 10.0.0.4 |
| Subnet Mask: | 255.255.240.0 |
| Default Gateway: | 10.0.0.1 |
| Preferred DNS: | 168.63.129.16 |

| sgreenwood3AZ2   |             |
| ---------------- | ----------- |
| IP address: | 10.0.0.5 |
| Subnet Mask: | 255.255.240.0 |
| Default Gateway: | 10.0.0.1 |
| Preferred DNS: | 168.63.129.29 |

| ==**4.2:**==                         | ==**5.1:**==                         |
| ------------------------------------ | ------------------------------------ |
| ![[Pasted image 20211215155014.png]] | ![[Pasted image 20211215154805.png]] |
