| Term      | Definitions                                                                                                                                                                     |
| --------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Tree      | could be deemed necessary to divide company resources and management by location or department if the company is large enough.                                                  |
| Forest    | a forest may happen because 2 related companies need to be managed together but need unique and separate identities. This could occur if one company purchases another company. |
| Namespace | A logical area on a network that contains directory services and named objects.                                                                                                 |
| DHCP Reservations | Ensures DHCP clients always receive the same IP address from the scope |
