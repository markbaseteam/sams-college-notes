<center><h1> Assignment 2 </h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

==**Part 1:**==
![[1 PW_History.png]]
![[2 PW_Age.png]]
![[3 PW_len.png]]
![[4 PW_Comp_req.png]]
![[5 PW_Enc.png]]

==**Part 2:**==
![[Update.png]]
![[2 Update_OMP.png]]
![[3 Update_hist.png]]
![[3 Update_hist.png]]
![[4 Sec.png]]
![[5 Sec_Scan.png]]
![[6 Sec_hist.png]]
![[7 Sec_uac.png]]

8. backup completed but the dialog box disappeared before I could get a screenshot