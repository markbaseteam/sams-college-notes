# Network Scanning
```toc
tocstyle: bullet | number (default: bullet)min_depth: number (default: 2)max_depth: number (default: 6)
```

## What Is Network Scanning
- tools used to examine a network and activity on it
- scanning can be used to:
	- troubleshoot issues with networks
	- check for vulnerabilities within a Network

## Types of Scans
| Name | Description                     |
| ---- | ------------------------------- |
| Ping | checks if the port is listening |
| TCP  | reliable communication, reliable delivery                                |
| UDP  |                                 |

![[Pasted image 20211008130711.png]]
   Flags are used in TCP protocol to describe the status of a packet and the communication that goes with it
   
## TCP
- SYN/ACK Start message
- FIN/RST abort connection

### Scan Techniques
| Scan                 | Description                                  |
| -------------------- | -------------------------------------------- |
|                      |                                              |
| Connect Scan |                                              |
| Sync Scan            | used to scan for vulnerabilities           |
| TCP FIN/URG/PSH Scan | FIN/URG/PSH packets sent together            |
| Null Scam            | sending a blank TCP packet that had no flags |
| XMAS Tree scan       | Sending all the flags at once                |

## Port Scanning Countermeasures
- proper design
- Deny All rule on firewall
- pen testing
- firewall testing
- port scanning
- security awareness

## UDP