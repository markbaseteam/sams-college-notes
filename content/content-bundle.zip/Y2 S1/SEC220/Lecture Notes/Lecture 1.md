```toc 
style: bullet | number (default: bullet)
min_depth: number (default: 2)
max_depth: number (default: 6)
```

## Security Goals
   
| Goal            | Description                                                                                                                                                                                                                                                                                   |
| --------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Confidentiality | - Confidentiality means that unauthorized people cannot read sensitive <br> information, either while it is on a computer or while it is travelling across a network. <br> - Only authorized users have access to data                                                                    |
| Integrity       | Integrity means that attackers cannot change or destroy <br> information, either while it is on a computer or while <br> it is travelling across a network. Or, at least, if information <br> is changed or destroyed, then the receiver can detect the change or restore destroyed data. |
| Availability    | Availability means that people who are authorized to use information are not prevented from doing so                                                                                                                                                                                     |

