```toc
tocstyle: bullet | number (default: bullet)min_depth: number (default: 2)max_depth: number (default: 6)
```

Network-Based Attacks
### Interception Attacks
| Type of Attack    | Description                                                                     | Diagram                              |
| ----------------- | ------------------------------------------------------------------------------- | ------------------------------------ |
| Man In The Middle | intercepting communications to redirect to a secondary node in the middle.      | ![[Pasted image 20211015125025.png]] |
| Replay Attack     | A type of MITM Attack where the attacker records a communication for later use. | ![[Pasted image 20211015125059.png]] |

### Poisoning Attacks
#### ARP Poisoning
- Attacker has to be in the network

##### Defending Against ARP Poisoning
- Preventing ARP Poisoning
	- Static ARP tables are manually set
		- Most organizations are too large, change too quickly, and lack the experience to effectively manage static IP and ARP tables
	- Limit Local Access
		- Foreign hosts must be kept off the LAN

#### DNS Poisoning
DNS poisoning is when the attacker injects a false DNS entry

## Server-Side Attacks
### DoS Attacks
- When the attacker floods the server with requests due to the volume
- #### DDoS
	- adding the extra D means that the origin attack 

#### Defending Against DoS Attacks
- Black holing
	- Drop all IP packets from an attacker
	- Not a good long-term strategy because attackers can quickly change source IP addresses
	- An attacker may knowingly try to get a trusted corporate partner black holed
- Validating the TCP handshake
	- Whenever a SYN segment arrives, the firewall itself sends back a SYN/ACK segment, without passing the SYN segment on to the target server (false opening)
	- When the firewall gets a legitimate ACK back, the firewall sends the original SYN segment on to the intended server
- Rate limiting
	- Used to reduce a certain type of traffic to a reasonable amount
	- Can frustrate attackers and legitimate users

### Smurf Attack
 Attacker sends request claiming to be another device so that the victim device is flooded with all the replies to the requests
![[Pasted image 20211015140205.png]]

### DNS Amplification Attacks
Like a Smurf Attack but instead of sending lots of small packets a few huge packets are sent.
![[Pasted image 20211015140353.png]]

### SYN Flood Attack
- attacker repeatedly send SYN requests and the recipient tries to respond to each and the server doen't respond because server is busy responding to the attacker.

| ![[dDOS.png]] | ![[Pasted image 20211015140627.png]] |
| ------------------------------------ | ------------------------------------ |