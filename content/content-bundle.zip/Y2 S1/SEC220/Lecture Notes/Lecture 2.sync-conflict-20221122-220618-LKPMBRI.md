```toc 
style: bullet | number (default: bullet)
min_depth: number (default: 2)
max_depth: number (default: 6)
```

## Comprehensive Security

- The defender must close all vulnerabilities 

> Security is a process, not a product

\- Bruce Schneier
- Redundancy, Redundancy, Redundancy
![[Pasted image 20210917130537.png]]
![[Pasted image 20210917130650.png]]
- keep your knowledge updated
- A Chain is As Strong As The Weakest Link

## Security as an Enabler
![[Pasted image 20210917131400.png]]
- Security is key
- Security is proactive

## Security Regulations
%% #Regs %%
- [Sarbanes-Oxley](https://www.mcafee.com/enterprise/en-ca/about/cloud-compliance/sarbanes-oxley-encryption-compliance-requirements.html#:~:text=The%20Sarbanes%2DOxley%20Act%20of,fraudulent%20accounting%20activities%20by%20corporations.&text=The%20law%20mandates%20strict%20reforms,corporations%20and%20prevent%20accounting%20fraud.)
- [General Data Protection Regulation (GDPR)](https://gdpr-info.eu/)
- [California Consumer Privacy Act (CCPA) | State of California](https://oag.ca.gov/privacy/ccpa)

## InfoSec Governance
![[Pasted image 20210917132922.png]]

### Governance Framework
![[Pasted image 20210917133137.png]]

```button
name Committee of Sponsoring Organizations of the Treadway Commission
type link
action coso.org
```
^button-bwkf
- COSO: General control at organization level. Internal Control – Internal Framework. The organization that created it: The committee of Sponsoring Organizations of the Treadway Commission (coso.org)
	- Objectives: Strategic, Operations, Reporting, Compliance
	-  Components: Internal environment, Objective Setting, Event Identification, Risk Assessment, Risk Response, Control Activities, Information and Communication, Monitoring
	-  CobiT: More specific framework focuses on IT functions, with guidance on how to implement it. Control Objective for Information and Related Technologies:
		-  Major Domains: Plan & Organize, Acquire and Implement, Deliver and Support, Monitor
		-  ISO/ IEC 27000: Related to IT security
	-  ITIL: (formerly Information Technology Infrastructure Library) is a set of detailed practices for IT activities such as IT service management (ITSM) and IT asset management (ITAM) that focus on aligning IT services with the needs of business.

## Ethics
%% #Ethics %%
![[Pasted image 20210924124558.png]]
- System of values

## Oversight
%% #Oversight %%
### Electronic Monitoring
- Electronically -collected information on behavior
- Widely done in firms and used to terminate employees
- Warn subjects and explain the reasons for monitoring

### Auditing
%% #Auditing %%
- Samples information to develop an opinion about the adequacy of controls
- Database information in log files and prose documentation
- Extensive recording is required in most performance regimes
- Avoidance of compliance is a particularly important finding
- Internal and external auditing may be done
- Periodic auditing gives trends
- Unscheduled audits trip up people who plan their actions around periodic audits
------ 
- behavioral awareness is important
- be aware of sanctions

