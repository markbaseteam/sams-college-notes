# Crypto Pt 2

   ```toc
style: bullet | number (default: bullet)
min_depth: number (default: 1)
max_depth: number (default: 6)
```

## Keys
%% #Keys %%
### Characteristics of Keys
- Public keys known to anyone, needs to be published
- Private key: Secret known by owner only

## Confidentiality
  ![[Asym Key Crypto.png]]
  ![[Asym Key Crypto 2.png]] 
  
## Asymmetric Key
%% #Asymmetric %%
![[Asym Key Crypto 3.png]]
  Used for:
	- Authentication
	- Integrity
	- Non-repudiation

### Digital Signatures
%% #Signatures %%
![[Pasted image 20211001130319.png]]
- Purpose: to digitally that it's from the sender
![[Pasted image 20211001130333.png]]

## Integrity?
![[PGP Signatures.png]]
## [Identity Validation](#Identity-Validation) Process
1. HTTPS request
2. server responds with public key and SSL cert
3. 