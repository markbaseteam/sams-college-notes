```toc
tocstyle: bullet | number (default: bullet)
min_depth: number (default: 2)
max_depth: number (default: 6)
```

## Proxies
A proxy server is an intermediary between the user and the internet

### Types of Proxies
| Type          | Description                                             | OSI Layer |
| ------------- | ------------------------------------------------------- | --------- |
| Forward proxy | intercepts user traffic and processes on behalf of user |           |
| Application   | knows what protocols it uses                            |           |
| Reverse       |                                                         | \         |
| Transparent Proxy | doesn't require user configuration |           |

### Benefits of Using Proxies
- security
- speed
	- because content is being pulled from an internal cache

## Firewalls
### Network-Based Firewalls
#### Types Of Firewalls
| Type      | Description                                                                  |
| --------- | ---------------------------------------------------------------------------- |
| Stateless | static mostly based on user configuration                                    |
| Stateful  | keeps records of past events and intelegently determines the action to take. |

### Rule-Based Firewalls
- strictly applies rules in order of user defined priority

### Application Based Firewalls
## Intrusion Detection
![[Interusion Detection#^b66442]]