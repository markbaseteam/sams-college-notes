```toc
tocstyle: bullet | number (default: bullet)
min_depth: number (default: 2)
max_depth: number (default: 6)
```

## Access Control
- Controlling who has access to what
- policy-driven

### The Core of Access Control

^5715db

![[Pasted image 20211206145539.png]]
-----

### Access Control Mechanisms
![[Y2 S1/SEC220/Glossary#^L8e1]]

