# Cryptography

```toc
style: bullet | number (default: bullet)
min_depth: number (default: 1)
max_depth: number (default: 6)
```

## Key Terms
%% #Key-Terms %%

| Term          | Definitions                                                   |
| ------------- | ------------------------------------------------------------- |
| Cipher        | a method /algorithm that encrypts or disguises “text”         |
| Key           | the set of parameter that guide a cipher                      | 
| Plaintext     | The undisguised text is called “plaintext”                    |
| ciphertext    | The disguised text is called “ciphertext”                     |
| Cryptanalysis | the process of deciphering ciphertext without knowing the key |

## Crypto
![[Pasted image 20210924130106.png]]

### Keys
%% #Keys %%

![[Pasted image 20210924130511.png]]

## Crypto Systems

### Types of Ciphers
%% #Ciphers %%

| Type          | Description              |
| ------------- | ------------------------ |
| Stream Cipher | takes one unit at a time |
| Block Cipher  |                          |
| Substitution Cipher | what it sounds like |

![[Kerckhoffs' Principle.png]]

## Hashes
%% #Hashes %%
- Hash function is a mathematical function that converts any input value into compressed numerical value
- one-way
- a small change of the input drastically  changes the output
- No two messages can have same hash value (unique)