# Lab 2 – Part 2

Sam Greenwood – 1026851935

## Received Public key

![](file:///C:/Users/jamme/AppData/Local/Temp/msohtmlclip1/01/clip_image002.png)

## Keys

![](file:///C:/Users/jamme/AppData/Local/Temp/msohtmlclip1/01/clip_image004.jpg)

  

## Signing

![](file:///C:/Users/jamme/AppData/Local/Temp/msohtmlclip1/01/clip_image006.jpg)

## Decrypted and Verified

![Graphical user interface, text, application, email
Description automatically generated](file:///C:/Users/jamme/AppData/Local/Temp/msohtmlclip1/01/clip_image008.jpg)

## SEC220-Lab 2-2 files

![Graphical user interface
Description automatically generated](file:///C:/Users/jamme/AppData/Local/Temp/msohtmlclip1/01/clip_image010.png)