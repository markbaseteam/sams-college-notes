## Lecture 1
| Term            | Definitions                                                                                |
| --------------- | ------------------------------------------------------------------------------------------ |
| Asset           | Item that has value                                                                        |
| Threat          | An action that has a potential to cause harm                                               |
| Thereat Actor   | A person or element with power to carry out a threat.                                      |
| Vulnerabilities | A weakness or fault in a system or protection mechanism that opens it to attack or damage. |
| Attacks | An act that takes advantage of a vulnerability to compromise a controlled system. | 
| Countermeasures | Tools used to thwart attacks, reduce risk.. <br> Also called safeguards, protections, and controls <br> Can be security mechanism, policies, or procedures |
| Exploits | A technique used to compromise a system |

## Lecture 3
| Term          | Definitions                                                   |
| ------------- | ------------------------------------------------------------- |
| Cipher        | a method /algorithm that encrypts or disguises “text”         |
| Key           | the set of parameter that guide a cipher                      |
| Plaintext     | The undisguised text is called “plaintext”                    |
| ciphertext    | The disguised text is called “ciphertext”                     |
| Cryptanalysis | the process of deciphering ciphertext without knowing the key |

## Lecture 8 Terms

### Access Control Mechanisms
| Term                          | Definition                                                                                                                                            |
| ----------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------- |
| Authentication                | the process or action of verifying the identity of a user or process.                                                                                 |
| Authorization                 | what permissions the authenticated user will have <br> - What resources he or she can get to at all <br> - What he or she can do with these resources |
| Accountability (Auditability) | recording what people do in log files <br> - Detecting attacks <br> - Identifying breakdowns in implementation                                        |
^L8e1