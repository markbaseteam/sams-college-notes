<center><h1> Assignment 3</h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195
==** Part 1: **==

<center> <h1> Step 4:</h1> </center>

![[A3 - Pings.png]]

==**Part 2: **==

<center> <h1> Step 1:</h1> </center>

R1: 
`interface g0/0`
`ip helper-address 192.168.7.254`
`exit`
`Interface g0/1`
`ip helper-address 192.168.7.254`

R2: 
`ip dhcp excluded-address 192.168.6.1 192.168.5.9`
`ip dhcp excluded-address 192.168.6.1 192.168.6.9`
`ip dhcp pool R1G1`
`network 192.168.6.0 255.255.255.0`
`default-router 192.168.6.1`
`dns-server 209.165.205.225`
`domain-name ccna-lab.com`
`lease 2`
`exit`
`ip dhcp pool R1G0`
`network 192.168.5.0 255.255.255.0`
`network 192.168.5.0 255.255.255.0`
`default-router 192.168.5.1`
`dns-server 209.165.205.225`
`domain-name ccna-lab.com`
`lease 2`

<center> <h1> Step 3:</h1> </center>

1. 
	
| PC-A             |                |
| ---------------- | -------------- |
| Physical Address | 00E0.A318.94BE |
| IPv4 Address     | 192.168.6.10   |

| PC-B             |                |
| ---------------- | -------------- |
| Physical Address | 0030.A348.A9B3 |
| IPv4 Address     | 192.168.6.11   |

2. 192.168.6.2

<center> <h1> Step 4: </h1> </center>

1. ![[R2 Route Binding.png]]
	Q: Client ID
2. command fails
3. ![[DHCP Pool.png]]
	Q: it's the connected client;s IP
4. ![[running-cfg DHCP.png]]

