| Acronym | What It Means            |
| ------- | ------------------------ |
| LAN     | Local Area Network       |
| SOHO    | Small Office Home Office |

| **Term**          | **Definitions**                                                                                             |
| ----------------- | ----------------------------------------------------------------------------------------------------------- |
| Unicast Address   | **an address that identifies a unique node on a network**                                                   |
| Multicast Address | **a logical identifier for a group of hosts in a computer network**                                         |
| Broadcast Address | **a network address used to transmit to all devices connected to a multiple-access communications network** |
| Active interface  | the interface that's checking for ongoing activities                                                        |
| Designated port   | The port which sends the best BPDU i.e ports on the root bridge will be in a forwarding state.              |
| Root port         | The port which receives the best BPDU on a non-root bridge. Criteria for selecting root port:               |
| EtherChannel      | Ethernet ports in parallel                                                                                  |
| Network Segment   | All the devices connected directly to each switch                                                           |

^a0a4da

