
```toc
    style: bullet | number (default: number)
    min_depth: number (default: 2)
    max_depth: number (default: 6)
```

## Single-Building Enterprise Wired and Wireless LAN
![[Pasted image 20210908123218.png]]
- SW1-3 are called access switches and SWD is a distribution switch
- there are dual connections between ASs and DSs for redundancy

## Types of Ethernet
%% #Ethernet %%

![[Types of Ethernet#^e61556]]

## Ethernet LAN Forwards 
%% #Ethernet #Forwards %%
![[Pasted image 20210908124823.png]]
Each Ethernet port has a #MAC-Address they allow the devices to be identified by something that's directly baked into the hardware

### Definitions
![[Y2 S1/CSN205/Glossary#^a0a4da]]

## Electrical Connection
%% #Connectors %%
![[Pasted image 20210908125712.png]]
- A port is an electrical or optical connection between nodes
- A link connects 2 nodes
![[Pasted image 20210908130217.png]]
- 4 circuits (1 send, 1 received, 2 either send / receive or control)

### RJ-45 Connector 
![RJ45 Wiring Diagram](https://iebmedia.com/wp-content/uploads/2012/12/ieb4637_3.gif)

## IEEE 802.3 Ethernet Header and Trailer Fields
   ![[IEEE 802.3 Ethernet Header and Trailer Fields#^60a4d8]] 
## Mac Address 
%% #MAC-Address %%

   ![[Pasted image 20210908131715.png]]
   ![[LAN MAC Address Terminology and Features#^915f03]]
 - 48 Bytes
