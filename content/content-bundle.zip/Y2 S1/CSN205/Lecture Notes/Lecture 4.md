```toc 
**style: bullet | number (default:bullet)
min_depth: number (default: 2)
max_depth: number (default: 6)
```

## Understanding RSTP Through Configuration
%% #RSTP #Configuration %%
### STP Standards & Configuration 
%% #Standards %%
![[STP Standards and Configs#^e61120]]
- PVST = Per VLAN STP
- CST = Common Spanning Tree

### STP/RSTP Configurable Priority Values
![[Pasted image 20211013124421.png]]
- command to set priority:
	- spanning-tree vlan n priority
- traffic can be controlled with EtherChannel

## Implementing EtherChannel
%% #EtherChannel %%
### What's EtherChannel
EtherChannel: multiple parallel links between two neighboring switches, working as a single link
- MAC learning, forwarding and STP logic are applied to all the links as one entity.
* Layer 3 core switches can create Layer 3 Ethechannels

### Steps To Configure EtherChannel
%% #Configuration-Steps%% 
![[Configuring a Manual EtherChannel]]

### Configuring Dynamic EtherChannel
- Two different protocols support switch negotiation of EtherChannel links:
	- PagP: Port Aggregation Protocol is enabled by using desirable and auto keywords
	- LACP: Link Aggregation Control Protocol is enabled by using active and passive keywords
- The switch can use the protocol to send messages to/from the neighboring switch and discover if their configuration settings pass all checks
- If a given physical link passes, the link is added to the EtherChannel and used

### EtherChannel Load Distribution
![[EtherChannel LD#^cb9200]] ![[EtherChannel LD#^56eca1]]

 