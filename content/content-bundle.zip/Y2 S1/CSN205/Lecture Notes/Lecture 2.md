```toc
breakstyle: bullet | number (default: bullet)
min_depth: number(default: 2)
max_depth: number (default: 6)
```

## Ethernet Addresses 
%% #Ethernet #Addresses %%

![[Pasted image 20210916132231.png]]
- Ethernet Frames have a variable data field between 461500 Bytes
- Trailer checks if the frame contains an error
- Frame contains both the source address and the destination address
	- Destination address is used to determine where the packet is going
	- Source address is used for the Switch to record the Source's MAC Address if it's not seen that device before.

### Switch Forwarding (Single Switch) 
%% #Switch #Forwards #Single-Switch %%

![[Pasted image 20210916132255.png]]
- When a device first connects to a switch it identifies 
- Switch reads the Mac address table to determine where the destination is
	- If the address isn't in the table the switch would go to the "L:Last"

### Switch Forwarding (Dual Switch)
%% #Switch #Forwards #Dual-Switch %%

![[Pasted image 20210916133430.png]]
- if a Switch gets a packet with a destination address of all ones it bypasses the address table and broadcasts to every device connected to the switch.
- after every device (other than the other switch) is determined that their Mac Addresses don't match it checks with the other switch.
![[Pasted image 20210916134418.png]]
- Then it checks the MAC Address table then sends it to the destination device

### Switch Learning
![[Pasted image 20211003134921.png]]

## Redundant Links Without STP 
%% #STP #Redundant-Links %%
- If a device is powered off it's MAC Address will be removed from the router's MAC Address table
	- when that happens the frame will get stuck in an infinite loop between all connected switches
- That is avoidable by setting an Aging Timer

## Relevant Commands 
%% #Commands %%

| Command                        | What It Does                                   |
| ------------------------------ | ---------------------------------------------- |
| show mac address-table dynamic | displays the MAC Address table                 |
| show interfaces static         | displays info about all the routers interfaces |
| show interfaces {interface}    | displays info on the given interface           |

## Password Security 
%% #Password %%

![[Pasted image 20211003161750.png]]