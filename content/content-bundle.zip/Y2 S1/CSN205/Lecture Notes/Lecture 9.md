```toc 
**style: bullet | number (default:bullet)
min_depth: number (default: 2)
max_depth: number (default: 6)
```

%%  # Vol 2 Ch 1: ACLs %%

## ACLs
- an ACL is a list of rules that govern a network
![[Pasted image 20211124124817.png]]
- rules permit or deny
- control traffic coning from a given interface
- if match found stops checking but if not moves on to next item on list
- first rule overwrites whatever after it