```toc 
**style: bullet | number (default:bullet)
min_depth: number (default: 2)
max_depth: number (default: 6)
```
%% 
# Chapter 19: Understanding OSPF %%
^44617f

## IGP
- 

## OSPF
%% #OSPF %%
- takes cost into effect
- link state based protocol

### Topology Information and LSAs
%% #Topology #LSAs %%
- organizes topology based on LSAs & link state database
- Each LSA is a data structure with some specific information about the network topology.
- The LSDB is a collection of all the LSAs known to a router.
- flooding process can prevent LSA loops
	- before LSA
- cost inversely proportionate to bandwidth
- What must be included for Identification:
	- Router ID
	- Interface IP
	- State
	- Cost

### Becoming OSPF Neighbors
- sends hello packet
	- Router ID (32-bit)
	- Multicast to 224.0.0.5
- if they have compatible OSPF parameters they form a relationship
- The OSPF neighbor relationship lets OSPF know when a neighbor might not be a good option for routing packets. 
- The OSPF neighbor model allows new routers to be dynamically discovered.

### Designated Routers on Ethernet Links
- On Ethernet links, OSPF elects one of the routers on the same subnet to act as the designated router (DR).
- The database exchange doesn't happen between every pair of routers on the same VLAN/subnet but between the DR and each of the other routers .
- The backup designated router (BDR) watches the status of the DR and takes over for the DR if it fails.

### Calculating the Best Routes with SPF
- Primary route is the shortest
- The sum of the #OSPF interface costs for all outgoing interfaces in the route.

### OSPF Areas
- layer based topology that requires memory on each router
- A single interface status change, anywhere in the internetwork (up to down, or down to up), forces every router to run #SPF again!

#### Parameters
- Area must be contiguous
- all interfaces on the same subnet must in the same area
- Some routers may be internal to an area, with all interfaces assigned to that single area.
- Some routers may be Area Border Routers (ABR), because some interfaces connect to the backbone area, and some connect to non-backbone areas.
- All non-backbone areas must connect to the backbone area (area 0) by having at least one ABR connected to both the backbone area and the non-backbone area.

![[OSPF Areas.png]]

### OSPF Design Terminology

![[OSPF Design Terminology#^c3e133]]

----------- 

%%
# Chapter 20: Implementing OSPF %%

^44597e
## Implementing Single-Area OSPF
%% #Single-Area-OSPF #OSPF %%
### Implementation Process
%% #Configuration-Steps %%
1. Use the router ospf process-id global command to enter OSPF configuration mode for a particular OSPF process.
2. (Optional) Configure the OSPF router ID by doing the following:
			a. Use the router-id id-value router subcommand to define the router ID.
			b. Use the interface loopback number global command, along with an ip address address mask command, to configure an IP address on a loopback interface (chooses the highest IP address of all working loopbacks).
			c. Rely on an interface IP address (chooses the highest IP address of all working nonloopbacks)
3. Use one or more network ip-address wildcard-mask area area-id router subcommands to enable OSPFv2 on any interfaces matched by the configured address and mask, enabling OSPF on the interface for the listed area.
4. (Optional) Use the passive-interface type number router subcommand to configure any OSPF interfaces as passive if no neighbors can or should be discovered on the interface.

--------------

- This process-id just needs to be unique on the local router and be between 1 and 65,535.

### OSPF Wildcards
![[OSPF Wildcards#^4d4113]]

### Matching OSPF **network** Commands

![[Pasted image 20211119142137.png]]

### Verifying Single Area OSPF
%% #Verification %%
- Interface: This is the local router’s interface connected to the neighbor. For example, the first neighbor in the list is reachable through R3’s S0/0/0 interface.
- Address: This is the neighbor’s IP address on that link. Again, for this first neighbor, the neighbor, which is R1, uses IP address 10.1.13.1.
- State: While many possible states exist, for the details discussed in this chapter, FULL is the correct and fully working state in this case.
- Neighbor ID: This is the router ID of the neighbor.

