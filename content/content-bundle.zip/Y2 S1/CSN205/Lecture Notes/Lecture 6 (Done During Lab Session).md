```toc 
**style: bullet | number (default:bullet)
min_depth: number (default: 2)
max_depth: number (default: 6)
```
%% 
# Chapter 14 %%
## Defining a Subnet
- An IP subnet is a subset of a classful network, created by choice of some network engineer. However, that engineer cannot pick just any arbitrary subset of addresses; instead, the engineer must follow certain rules, such as the following:
	- The subnet contains a set of consecutive numbers
	- The subnet holds 2H numbers, where H is the number of host bits defined by the subnet mask.
		- Two special numbers in the range cannot be used as IP addresses:
		- The first (lowest) number acts as an identifier for the subnet (subnet ID).
	- The remaining addresses, whose values sit between the subnet ID and subnet broadcast address, are used as unicast IP addresses.

## Dividing Subnets
### Formulas
| <p> 2 <sup>X</sup> = # of subnets (X = # of borrowed bits) </p> | <p> 2 <sup> n </sup> - 2 = # of hosts (n = # of host bits) </p> |
| --------------------------------------------------------- | ---------------------------------------------------------- |
- last octet always goes to 255
- adding a bit from the host portion to the net portion doubles the number of possible subnets.