 ```toc 
**style: bullet | number (default:bullet)
min_depth: number (default: 2)
max_depth: number (default: 6)
```

%%  # Vol 2 Ch  5: Securing Networks %%

