```toc 
**style: bullet | number (default:bullet)
min_depth: number (default: 2)
max_depth: number (default: 6)
```

%% 
# Chapter 17 %%
## VLANs
%% #VLANs %%
### VLANs Routing Using 802.1Q Trunks
%% #Routing #8021Q %%
- Use a router, with one router LAN interface and cable connected to the switch for each and every VLAN (typically not used)
- Use a router, with a VLAN trunk connecting to a LAN switch (known as router-on-a-stick, or ROAS)
- Use a Layer 3 switch with switched virtual interfaces (SVI)
- Use a Layer 3 switch with routed interfaces (which may or may not be Layer 3 EtherChannels)

![[Pasted image 20211103120000.png]]

--------
- layer 3 switches also have routing tables
- every VLAN is a different broadcast domain

### Router On A Stick
%% #ROAS %%
- router on a stick creates as many subniterfaces as there are VLANs

#### Configuring ROAS
%% #Configuration-Steps %%
1. Use the ***interface type number.subint*** command in global configuration mode to create a unique subinterface for each VLAN that needs to be routed.
2. Use the ***encapsulation dot1q vlan_id*** command in subinterface configuration mode to enable 802.1Q and associate one specific VLAN with the subinterface.
3. Use the ***ip address address mask*** command in subinterface configuration mode to configure IP settings (address and mask).

#### Verifying ROAS
%% #Verification %%
- Beyond using the show running-config command, ROAS configuration on a router can be best verified using either the show ip route [connected] or show vlans command.
- ROAS state depends on physical interface state; the subinterface state can't be better than the physical interfaces state.
- subinterface can be enabled or disabled indepenant of the physical interface state

#### Troubleshooting ROAS
%% #Troubleshooting %%
- To check ROAS on a router, start with the intended configuration and ask questions about the configuration as follows:
	1. Is each non-native VLAN configured on the router with an encapsulation dot1q vlan-id command on a subinterface?
	2. Do those same VLANs exist on the trunk on the neighboring switch (show interfaces trunk), and are they in the allowed list, not VTP pruned, and not STP blocked?
	3. Does each router ROAS subinterface have an IP address/mask configured per the planned configuration?
	4. If using the native VLAN, is it configured correctly on the router either on a subinterface (with an encapsulation dot1q vlan-id native command) or implied on the physical interface?
	5. Is the same native VLAN configured on the neighboring switch’s trunk?
	6. Are the router physical or ROAS subinterfaces configured with a shutdown command?

## Layer 3 Switch (L3S) SVIs 
### Configuring L3S SVIs 
- all virtual interfaces need to be physically connected
- an extra interface is needed to connect the routing feature of the L3S to the Router

#### L3S SVI Configuration Steps
%% #Configuration-Steps %%
1. Enable IP routing on the switch, as needed:
	1. Use the sdm prefer lanbase-routing command (or similar) in global configuration mode to change the switch forwarding ASIC settings to make space for IPv4 routes at the next reload of the switch.
	2. Use the reload EXEC command in enable mode to reload (reboot) the switch to pick up the new sdm prefer command setting.
	3. Once reloaded, use the ip routing command in global configuration mode to enable the IPv4 routing function in IOS software and to enable key commands like show ip route.
2. Configure each SVI interface, one per VLAN for which routing should be done by this Layer 3 switch:
	1. Use the interface vlan vlan_id command in global configuration mode to create a VLAN interface, and to give the switch’s routing logic a Layer 3 interface connected into the VLAN of the same number.
	2. Use the ip address address mask command in VLAN interface configuration mode to configure an IP address and mask on the VLAN interface, enabling IPv4 routing on that VLAN interface.
	3. (As needed) Use the no shutdown command in interface configuration mode to enable the VLAN interface (if it is currently in a shutdown state).