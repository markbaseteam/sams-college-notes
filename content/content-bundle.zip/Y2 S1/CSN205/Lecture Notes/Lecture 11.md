```toc 
**style: bullet | number (default:bullet)
min_depth: number (default: 2)
max_depth: number (default: 6)
```

%%  # Vol 2 Ch 9: Device Management Protocols %%

![[Pasted image 20211203105107.png]]

## NTP
- can be est individually or to inherit time form an NTP Server

## CDP & LLDP
- CDP is Cisco's proprietary network device discovery protocol
- LLDP is the non-proprietary version of CDP

%% # Vol 2 Ch 10: NAT %%

## NAT
NAT translates private IPs to public IPs
![[Pasted image 20211203111518.png]]
![[Pasted image 20211203111741.png]]

### How  NAT Works
- Changes private IP to public IP  (or vice versa depending on the direction)
![[NAT Addressing Terms]]

### PAT
- Port Address Translation
- Allows direction of multiple ports to a single IP
--------
- like DHCP, NAT supports pooling

%% # Vol 2 Ch 11: QoS %%

## New Terms
![[QoS Terms]]

------

## Round Robin Scheduling

- Allows assignment of a specific amount of bandwidth to a specific task
- 