## Analyze Requirements
**From the Slides**
 - Which hosts should be grouped together into a subnet?
 - How many subnets does this network require?
 - How many host IP addresses does each subnet require?
 - Will we use a single subnet size for simplicity, or not?
 --------
- Type of IP Address depends on type of network
- 

## Design
### IP Classes
| Class | Description                                                                                  | Number of Networks |
| ----- | -------------------------------------------------------------------------------------------- | ------------------ |
| A     | - first octet used as network ID and rest is the host ID <br> -   First octet between 0-127  | 1 |
| B     | - first 2 octets used as network ID and rest is the host ID <br> - First octet between 128-191 | 16 |
| C     | - only last octet is the host ID <br> - First octet between 192-223 | 256 |

![[Pasted image 20211013141321.png]]
- Subnetting = Borrowing bits
![[Pasted image 20211013141359.png]]

Example: 
![[Pasted image 20211013141446.png]]

## Plan Implementation 
- Start Assigning IPs
- 1st available address always is assigned to the gateway