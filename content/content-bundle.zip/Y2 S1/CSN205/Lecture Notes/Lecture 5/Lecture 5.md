
```toc 
**style: bullet | number (default: bullet)min_depth: number (default: 2
)max_depth: number (default: 6)
```

%%
 # Chapter 11 %%

^be8717

%% ## IP Addresses
 #IP-Addresses %%
^Ch11
 ## Subnet Planning
 ### Stages of Subnet Planning
- [[Stages of Subnet Planning#Analyze Requirements|Analyze Requirements]]
- [[Stages of Subnet Planning#Design|Design]]
- [[Stages of Subnet Planning#Plan Implementation|Plan Implementation]] 

%% # Chapter 12 %% 
^Ch12
## Classful Network Concepts
- 127 address is used for internal testing
![[First Octet Values#^f39504]]

### Key Facts - Classes A, B, C
![[Key Facts - Classes A, B, C#^18f6c7]]

### Calculating Subnets
#### Subnet Masks
![[Pasted image 20211015163936.png]]

#### Deriving Network IDs
| Class A | ![[Pasted image 20211015164315 (Cropped).png]] |
| ------- | ------------------------------------ |
| Class B | ![[Pasted image 20211015164655 (Cropped).png]] |
- Add 1 to the network address to get the 1<sup>st</sup> assignable address
- subtract 1 from the Subnet Mask to get the last assignable address

### Conversion from Decimal to Prefix
![[Subnet Mask Calculation.png]]
#### Steps to Calculate Subnets

![[Subnet Calculation Steps]]
%% # Chapter 13 %% ^Ch13
## Analyzing Subnet Masks
### Classless Interdomain Routing (CIDR)

![[CIDR Charts#^efd67d]]
![[CIDR Charts#^860dba]]
![[CIDR Table.png]]
 
 