```toc 
**style: bullet | number (default:bullet)
min_depth: number (default: 2)
max_depth: number (default: 6)
```

## VLANs
%% #VLANs %%
- Range:  1 - 4096 (but only up to  99 are typically used)
- default VLAN = 1

### Reasons for VLANs 
- redundancy
- isolation
- segmentation

### How VLANs Work
%% #HowItWorks #VLANs %%
- Ethernet frame would now include VLAN IDs
- .1Q is the standard for trunking
- 12 bits for the VLAN ID inserted into the Ethernet Frame
- typically only the 1st hundred IDs are used but there are up to 11
------
- Layer 2 doesn't route between VLANs

### Switch Port Modes
%% #Port-Modes %%

| Mode Name         | Description                                                                                                                                                                                                           |
| ----------------- | ----------------- |
| Access            | Always forces that port to be an access port with no VLAN tagging allowed EXCEPT for the voice vlan. DTP is not used and a trunk will never be formed.                                                                |
| Trunk             | This interface will always be a trunk no matter what happens on the other side. It will also use DTP to negotiate a neighboring interface that is set to **_dynamic desirable_** or **_dynamic auto_** into a trunk. |
| Dynamic Auto      | allows the port to negotiate DTP if the other side is set to **_trunk_** or **_desirable_**. Otherwise it will become an access port.                                                                                |
| Dynamic Desirable | pro-active DTP negotiation will begin and if the other-side is set to **_trunk_**, **_desirable_**, or **_auto_**. The interface will become a trunk. Otherwise the port will become an access port.                  |

- ports can belong to multiple VLANs at once

### IP Phones
%% #VOIP %%
- IP phones have a switch embedded into it.
- computers can be connected through the same cable as the phone since they're on different VLANs
- ports can belong to 2 VLANs at once

## Spanning Tree Protocol Concepts
%% #STP %% 

![[Three Classes of Problems Caused by Not Using STP in Redundant LANs#^f2cda2]] 

| STP prevents loops like this from happening | ![[Pasted image 20211003165851.png]] |
| ------------------------------------------- | ------------------------------------ |

### What's STP?
- controls flow of traffic between devices
	- directional
- organizes the "streets" of the switch

#### STP/RSTP: Reasons for Forwarding or Blocking
![[STP RSTP Reasons for Forwarding or Blocking#^c75f18]]
- A tree is a logical designation of nodes with a root
- in the example switch 3 is the root

![[Pasted image 20210922125050.png]]

![[Pasted image 20210922125158.png]]


### STP Fields
![[Pasted image 20211004160125.png]]
- priority 1 = most Important
- ID is always unique

### Root Selection
%% #Root %%
![[Pasted image 20211003174326.png]]
- Criteria for selecting root port: 
	1.  Lowest path cost to reach the root bridge
	2.  Lowest sender bridge I’d
	3.  Lowest sender port I’d
-  STP cost is equal to Port priority + Port number

### Port States
%% #States %%

| State         | Description                                                                                                                                       |
| ------------- | ------------------------------------------------------------------------------------------------------------------------------------------------- |
| Listening     | the interface does not forward frames; the switch removes unused MAC table entries                                                                |
| Learning      | the interface does not forward frames; the switch begins learning MAC addresses from the received frames                                          |
| RSTP PortFast | allows the switch to go from blocking to forwarding without listening and learning. It is only recommended on ports connected to end-user devices |

### Default Port Costs According to IEEE
<table border="1" cellspacing="2" cellpadding="4" width="35%">
<tbody><tr><th align="left">Link Speed</th><th align="left">Recommended<br>Value</th><th align="left">Recommended<br>Range</th><th align="left">Range  </th></tr>
<tr><td align="right">    4 Mbps</td><td align="right">                 250</td><td align="right">            100-1000</td><td align="right">1-65535</td></tr>
<tr><td align="right">   10 Mbps</td><td align="right">                 100</td><td align="right">              50-600</td><td align="right">1-65535</td></tr>
<tr><td align="right">   16 Mbps</td><td align="right">                  62</td><td align="right">              40-400</td><td align="right">1-65535</td></tr>
<tr><td align="right">  100 Mbps</td><td align="right">                  19</td><td align="right">               10-60</td><td align="right">1-65535</td></tr>
<tr><td align="right">    1 Gbps</td><td align="right">                   4</td><td align="right">                3-10</td><td align="right">1-65535</td></tr>
<tr><td align="right">   10 Gbps</td><td align="right">                   2</td><td align="right">                 1-5</td><td align="right">1-65535</td></tr>
</tbody></table>

### STP Timers
![[STP Timers#^93a20d]]
![[Pasted image 20211004164820.png]]
![[Pasted image 20211004164900.png]]

| Backup Port Example | ![[Pasted image 20211004165029.png]] |
| ------------------- | ------------------------------------ |