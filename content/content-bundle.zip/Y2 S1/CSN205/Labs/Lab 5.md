<center><h1> Lab 5  </h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

==**Part 2:* *==
<center> <bold> Step 4: </bold> </center> 

![[Pasted image 20211126162527.png]]
![[Pasted image 20211126162425.png]]
![[Pasted image 20211126162608.png]]

<center> <bold> Step 5: </bold> </center> 
           

You want to ensure that your network is properly functioning before you start to filter traffic.

a. From PC-A, ping PC-C and the loopback interface on R3. Were your pings successful?  <ins> no </ins>

b. From R1, ping PC-C and the loopback interface on R3. Were your pings successful? <ins> no </ins>

c. From PC-C, ping PC-A and the loopback interface on R1. Were your pings successful? <ins> no </ins>

d. From R3, ping PC-A and the loopback interface on R1. Were your pings successful? <ins> no </ins>

![[Pasted image 20211126170720.png]]

==**Part 3:**==

<center> <bold> Step 1: </bold> </center> 

q1. 0.0.0.255

c. 
q1. show access-lists 1
q2. 

1. ![[Pasted image 20211130145035.png]]
2. No the ping timed out
3. no
	![[Pasted image 20211130145837.png]]

d.  ![[Pasted image 20211130150003.png]]

1. It's still not working, I thought that it was due to a misconfiguration but I fixed that and it's still not working. I think the problem could be that that ACL is set to accept traffic from PC-As IP but not from the router. 

<center> <bold> Step 2: </bold> </center> 

1. on the serial port facing in
	a.  permit 192.168.40.0 0.0.0.255
	c. The difference is that R1's list is configured to only let traffic out whereas R3's configured to allow traffic both directions.
3. no
	![[Pasted image 20211130163512.png]]
4. Still not working
	![[Pasted image 20211130164044.png]]
5. no (the terminal wouldn't even accept G0/1 as the source interface/)
6. Success rate is 0 percent (0/5)

==**Part 4: **==

c. 
1. ![[Pasted image 20211130165917.png]]
	no
2. no
	
==**Reflection:**==

1. You'd use an Extended ACL if you need to do something ,ore precise