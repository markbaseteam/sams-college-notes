<center><h1> Lab 4 </h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

==**Part 1: **==
<center> <bold> Step 5: </bold> </center> 

![[Pasted image 20211111174637.png]]

![[Pasted image 20211111175920.png]]

==**Part 2:**==

<center> <bold> Step 2 </bold> </center>

b.           

From PC-A, is it possible to ping PC-B? <ins>no</ins> Why? <ins> the routers aren't being advertised to each other properly </ins>

From PC-A, is it possible to ping PC-C? <ins> no </ins> Why? <ins> the routers aren't being advertised to each other properly </ins>

From PC-C, is it possible to ping PC-B? <ins> no </ins> Why? <ins> the routers aren't being advertised to each other properly </ins>

From PC-C, is it possible to ping PC-A? <ins> no </ins> Why? <ins> the routers aren't being advertised to each other properly </ins>

### R1 *ip protocols* command

![[Pasted image 20211120143057.png]]

c. 
	          

When issuing the **debug ip rip** command on R2, what information is provided that confirms RIPv2 is running?

<ins> RIP protocol debugging is on </ins>

When issuing the **show run** command on R3, what information is provided that confirms RIPv2 is running? 

<ins> 

d.
	![[Pasted image 20211120145225.png]]
	![[Pasted image 20211120145131.png]]
	![[Pasted image 20211120145315.png]]

<center> <bold> Step 2 </bold> </center>

c. 
	![[Pasted image 20211120150009.png]]
	![[Pasted image 20211120150055.png]]
	![[Pasted image 20211120150135.png]]

d.

          

What routes are in the RIP updates that are received from R3?

<ins>   

10.1.1.0/30 via 0.0.0.0, metric 1, tag 0 <br> 172.30.0.0/16 via 0.0.0.0, metric 2, tag 0
	
Are the subnet masks now included in the routing updates?

<center> <bold> Step 6 </bold> </center>

a. <ins> for some reason only PC-A can ping R2 when PC-C attempts there's a connection unreachable error</ins>
b. <ins> I have the same problem as last step </ins>


