## Lec 2
| Command                        | What It Does                                   |
| ------------------------------ | ---------------------------------------------- |
| show mac address-table dynamic | displays the MAC Address table                 |
| show interfaces static         | displays info about all the routers interfaces |
| show interfaces {interface}    | displays info on the given interface           |

## Lab 4
| Command                                    | What it Does                           |
| ------------------------------------------ | -------------------------------------- |
| copy running-config startup-config         | saves running-config to startup-config |
| line vty 0 15 <br> password (x) <br> login | set vty password                       |
| enable  password (x)                       | set EXEC Password                      |
| no ip domain-lookup | disable DNS Lookup |
