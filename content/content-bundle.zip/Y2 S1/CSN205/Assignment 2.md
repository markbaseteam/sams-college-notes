<center><h1> Assignment 2 </h1></center>

**Name:** Sam Greenwood

**Student Number:** 102608195

==**Part 1 Step 4: **==

|     |     |  |
| --- | --- |
| ![[Pasted image 20211120172443.png]] | ![[Pasted image 20211120172507.png]] |
| ![[Pasted image 20211120172517.png]] | |

<br> ==**Part 2: **==

<center> <h1> Step 1:</h1> </center>

Identify the Backbone router(s): <ins> None </ins>

Identify the Autonomous System Boundary Router(s) (ASBR): <ins>  </ins>

Identify the Area Border Router(s) (ABR): <ins> R1 & R2 </ins>

Identify the Internal router(s): <ins> R3 </ins>

<center> <h1> Step 1:</h1> </center>

R1(config-router)# **network 192.168.5.1 0.0.0.255 area 1**

R1(config-router)# **network 192.168.6.1 0.0.0.255 area 1**

R1(config-router)# **network 192.168.16.1 0.0.0.3 area 0**

<center> <h1> Step 3: </h1> </center>

R2(config-router)# <ins> network 192.168.10.1 0.0.0.255 area 3 </ins>

R2(config-router)# <ins> network 192.168.16.2 0.0.0.3 area 0 </ins> 

R2(config-router)# <ins>network 192.168.27.1  0.0.0.3 area 3 </ins>

<center> <h1> Step 4: </h1> </center>

R3(config-router)# <ins> network 192.168.8.1 0.0.0.255 area 3 </ins>

R3(config-router)# <ins> network 192.168.9.1 0.0.0.255 area 3 </ins>

R3(config-router)# <ins> network 192.168.27.2 0.0.0.3 area 3 </ins>

<center> <h1> Step 5:</h1> </center>

| a.  |     |
| --- | --- |
| ![[Pasted image 20211129151014.png]] | ![[Pasted image 20211129151047.png]] |
| ![[Pasted image 20211129151108.png]] | |

| b.  |     |
| --- | --- |
| ![[Show OSPF Neighbour R1.png]] | ![[Show OSPF Neighbour R2.png]] |
| ![[Show OSPF Neighbour R3.png]] | |

| c.  |     |
| --- | --- |
| ![[Show OSPF Interface R1.png]] | ![[Show OSPF Interface R2.png]] |
| ![[Show OSPF Interface R3.png]] | |